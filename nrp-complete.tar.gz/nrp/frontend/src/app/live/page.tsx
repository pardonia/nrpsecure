"use client";
import { useState, useEffect } from "react";
import { Radio, Play, X } from "lucide-react";
import { AppShell, Avatar } from "@/components/layout/AppShell";
import { useAuthStore } from "@/store/authStore";
import { timeAgo } from "@/lib/utils";
import api from "@/lib/api";

function LiveBroadcast({ room, token, livekitUrl, onEnd }: { room: any; token: string; livekitUrl: string; onEnd: () => void }) {
  return (
    <div style={{ position:"fixed", inset:0, background:"#000", zIndex:300, display:"flex", flexDirection:"column" }}>
      <div style={{ padding:"14px 20px", display:"flex", justifyContent:"space-between", alignItems:"center", borderBottom:"1px solid #2F3336" }}>
        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          <span className="live-dot"/>
          <span style={{ color:"#fff", fontWeight:800, fontSize:18 }}>LIVE — {room.title}</span>
        </div>
        <button onClick={onEnd} style={{ background:"#E0245E", color:"#fff", border:"none", padding:"8px 16px", borderRadius:9999, fontWeight:700, cursor:"pointer", fontFamily:"inherit" }}>
          End stream
        </button>
      </div>
      {/* LiveKit iframe embed — works without SDK */}
      {livekitUrl ? (
        <iframe
          src={`https://meet.livekit.io/rooms/${room.roomName}?token=${token}`}
          allow="camera; microphone; fullscreen; display-capture; autoplay"
          style={{ flex:1, border:"none" }}
          title="NRP Live Broadcast"/>
      ) : (
        <div style={{ flex:1, display:"flex", alignItems:"center", justifyContent:"center", flexDirection:"column", gap:12, color:"#fff" }}>
          <div style={{ fontSize:64 }}>📡</div>
          <div style={{ fontSize:22, fontWeight:800 }}>Stream started</div>
          <div style={{ color:"#71767B", fontSize:15 }}>Add LIVEKIT_URL to .env to enable full WebRTC streaming.</div>
          <div style={{ color:"#71767B", fontSize:13 }}>Room: {room.roomName}</div>
        </div>
      )}
    </div>
  );
}

function LiveViewer({ room, token, livekitUrl, onClose }: { room: any; token: string; livekitUrl: string; onClose: () => void }) {
  return (
    <div style={{ position:"fixed", inset:0, background:"#000", zIndex:300, display:"flex", flexDirection:"column" }}>
      <div style={{ padding:"14px 20px", display:"flex", justifyContent:"space-between", alignItems:"center", borderBottom:"1px solid #2F3336" }}>
        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          <span className="live-dot"/>
          <span style={{ color:"#fff", fontWeight:700, fontSize:16 }}>{room.host?.name} — {room.title}</span>
        </div>
        <button onClick={onClose} style={{ background:"none", border:"none", color:"#fff", cursor:"pointer", display:"flex" }}><X size={22}/></button>
      </div>
      {livekitUrl ? (
        <iframe
          src={`https://meet.livekit.io/rooms/${room.roomName}?token=${token}`}
          allow="camera; microphone; fullscreen; autoplay"
          style={{ flex:1, border:"none" }}
          title="NRP Live Stream"/>
      ) : (
        <div style={{ flex:1, display:"flex", alignItems:"center", justifyContent:"center", flexDirection:"column", gap:12, color:"#fff" }}>
          <div style={{ fontSize:64 }}>📺</div>
          <div style={{ fontSize:22, fontWeight:800 }}>Watching: {room.title}</div>
          <div style={{ color:"#71767B", fontSize:15 }}>Configure LiveKit to enable real video streaming.</div>
        </div>
      )}
    </div>
  );
}

export default function LivePage() {
  const { user }  = useAuthStore();
  const [rooms,   setRooms]   = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [title,   setTitle]   = useState("");
  const [starting,setStarting]= useState(false);
  const [broadcast, setBroadcast] = useState<{ room: any; token: string; livekitUrl: string } | null>(null);
  const [viewing,   setViewing]   = useState<{ room: any; token: string; livekitUrl: string } | null>(null);

  const loadRooms = () => api.get("/live").then(r => setRooms(r.data.rooms || [])).finally(() => setLoading(false));

  useEffect(() => { loadRooms(); const t = setInterval(loadRooms, 15000); return () => clearInterval(t); }, []);

  const goLive = async () => {
    if (!title.trim() || starting) return;
    setStarting(true);
    try {
      const { data } = await api.post("/live", { title: title.trim() });
      setBroadcast({ room: data.room, token: data.token || "", livekitUrl: data.livekitUrl || "" });
      loadRooms();
    } catch (err: any) { alert(err.response?.data?.error || "Failed to start stream"); }
    setStarting(false);
  };

  const joinRoom = async (room: any) => {
    try {
      const { data } = await api.post(`/live/${room._id}/join`);
      setViewing({ room: data.room, token: data.token || "", livekitUrl: data.livekitUrl || "" });
    } catch {}
  };

  const endStream = async () => {
    if (!broadcast) return;
    try { await api.post(`/live/${broadcast.room._id}/end`); } catch {}
    setBroadcast(null);
    loadRooms();
  };

  return (
    <AppShell>
      <div style={{ padding:"12px 16px", borderBottom:"1px solid var(--nrp-border)", position:"sticky", top:0, background:"var(--nrp-bg)", backdropFilter:"blur(12px)", zIndex:20, fontWeight:800, fontSize:20, display:"flex", alignItems:"center", gap:10 }}>
        <span className="live-dot"/> NRP Live
      </div>

      {/* Go live */}
      {user && (
        <div style={{ padding:"16px", borderBottom:"1px solid var(--nrp-border)" }}>
          <div style={{ fontWeight:700, fontSize:16, marginBottom:12 }}>Start broadcasting</div>
          <div style={{ display:"flex", gap:10 }}>
            <input value={title} onChange={e => setTitle(e.target.value)}
              placeholder="What are you streaming today?"
              onKeyDown={e => e.key === "Enter" && goLive()}
              style={{ flex:1, background:"var(--nrp-subtle)", border:"1px solid var(--nrp-border)", borderRadius:9999, padding:"10px 16px", color:"var(--nrp-fg)", fontSize:15, outline:"none", fontFamily:"inherit" }}
              onFocus={e => (e.target.style.borderColor="var(--nrp-fg)")}
              onBlur={e => (e.target.style.borderColor="var(--nrp-border)")}/>
            <button onClick={goLive} disabled={!title.trim() || starting}
              style={{ background:"var(--nrp-fg)", color:"var(--nrp-bg)", border:"none", padding:"10px 20px", borderRadius:9999, fontWeight:700, fontSize:15, cursor:"pointer", display:"flex", alignItems:"center", gap:8, fontFamily:"inherit", opacity:!title.trim()||starting?0.5:1 }}>
              <Radio size={18}/>{starting ? "Starting…" : "Go Live"}
            </button>
          </div>
        </div>
      )}

      {/* Live rooms */}
      <div style={{ padding:"14px 16px 8px", fontWeight:800, fontSize:17 }}>
        Live now {rooms.length > 0 && <span style={{ fontWeight:400, color:"var(--nrp-muted)", fontSize:14 }}>({rooms.length})</span>}
      </div>

      {loading ? (
        Array.from({length:3}).map((_,i) => (
          <div key={i} style={{ display:"flex", gap:12, padding:"14px 16px", borderBottom:"1px solid var(--nrp-border)" }}>
            <div className="skeleton" style={{ width:46, height:46, borderRadius:"50%", flexShrink:0 }}/>
            <div style={{ flex:1 }}><div className="skeleton" style={{ height:14, width:"50%", borderRadius:4, marginBottom:6 }}/><div className="skeleton" style={{ height:13, width:"30%", borderRadius:4 }}/></div>
          </div>
        ))
      ) : rooms.length === 0 ? (
        <div style={{ padding:48, textAlign:"center", color:"var(--nrp-muted)" }}>
          <div style={{ fontSize:48, marginBottom:12 }}>📡</div>
          <div style={{ fontSize:20, fontWeight:800, marginBottom:8 }}>Nobody is live right now</div>
          <div style={{ fontSize:15 }}>Be the first to start broadcasting.</div>
        </div>
      ) : (
        rooms.map(r => (
          <div key={r._id} style={{ display:"flex", alignItems:"center", gap:14, padding:"14px 16px", borderBottom:"1px solid var(--nrp-border)", cursor:"pointer", transition:"background 0.1s" }}
            onMouseEnter={e => (e.currentTarget.style.background = "var(--nrp-hover)")}
            onMouseLeave={e => (e.currentTarget.style.background = "")}
            onClick={() => joinRoom(r)}>
            <div style={{ position:"relative" }}>
              <Avatar name={r.host?.name || "?"} url={r.host?.avatarUrl} size={46}/>
              <span style={{ position:"absolute", bottom:0, right:0 }} className="live-dot"/>
            </div>
            <div style={{ flex:1 }}>
              <div style={{ fontWeight:700, fontSize:15 }}>{r.title}</div>
              <div style={{ color:"var(--nrp-muted)", fontSize:13 }}>{r.host?.name} · {timeAgo(r.startedAt)} ago</div>
              <div style={{ fontSize:13, color:"var(--nrp-muted)", marginTop:2 }}>{r.viewerCount} watching</div>
            </div>
            <button style={{ background:"var(--nrp-fg)", color:"var(--nrp-bg)", border:"none", padding:"7px 16px", borderRadius:9999, fontWeight:700, fontSize:13, cursor:"pointer", display:"flex", alignItems:"center", gap:6, fontFamily:"inherit" }}>
              <Play size={14}/> Watch
            </button>
          </div>
        ))
      )}

      {broadcast && <LiveBroadcast room={broadcast.room} token={broadcast.token} livekitUrl={broadcast.livekitUrl} onEnd={endStream}/>}
      {viewing   && <LiveViewer   room={viewing.room}   token={viewing.token}   livekitUrl={viewing.livekitUrl}   onClose={() => setViewing(null)}/>}
    </AppShell>
  );
}
