"use client";
import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuthStore } from "@/store/authStore";

export default function Root() {
  const { user, loading } = useAuthStore();
  const router = useRouter();
  useEffect(() => {
    if (!loading) router.replace(user ? "/feed" : "/auth");
  }, [user, loading, router]);
  return (
    <div style={{ minHeight:"100vh", background:"#000", display:"flex", alignItems:"center", justifyContent:"center" }}>
      <div style={{ fontFamily:"'Courier New',monospace", fontWeight:900, fontSize:40, color:"#fff", letterSpacing:-2 }}>NRP</div>
    </div>
  );
}
