"use client";
import { useState } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import api from "@/lib/api";

export default function ResetPasswordPage() {
  const params = useSearchParams();
  const router = useRouter();
  const token  = params.get("token") || "";
  const [password, setPassword] = useState("");
  const [confirm,  setConfirm]  = useState("");
  const [msg,  setMsg]  = useState("");
  const [err,  setErr]  = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirm) { setErr("Passwords don't match"); return; }
    if (password.length < 8)  { setErr("Minimum 8 characters"); return; }
    setErr(""); setLoading(true);
    try {
      await api.post("/auth/reset-password", { token, password });
      setMsg("Password reset! Redirecting to login…");
      setTimeout(() => router.push("/auth"), 2000);
    } catch (e: any) { setErr(e.response?.data?.error || "Reset failed"); }
    setLoading(false);
  };

  const inp: React.CSSProperties = { display:"block", width:"100%", padding:"12px 14px", marginBottom:10, background:"#16181C", border:"1px solid #2F3336", borderRadius:8, color:"#fff", fontSize:15, outline:"none", fontFamily:"inherit" };

  return (
    <div style={{ minHeight:"100vh", background:"#000", display:"flex", alignItems:"center", justifyContent:"center", padding:16 }}>
      <div style={{ background:"#000", border:"1px solid #2F3336", borderRadius:16, padding:40, width:"100%", maxWidth:400, color:"#fff" }}>
        <div style={{ textAlign:"center", marginBottom:32 }}>
          <div style={{ fontFamily:"'Courier New',monospace", fontWeight:900, fontSize:36, letterSpacing:-2 }}>NRP</div>
          <div style={{ color:"#71767B", fontSize:14, marginTop:4 }}>Reset your password</div>
        </div>
        {!token ? (
          <div style={{ color:"#E0245E", textAlign:"center" }}>Invalid or missing reset token. <a href="/auth" style={{ color:"#fff" }}>Go to login</a></div>
        ) : (
          <form onSubmit={submit}>
            <input type="password" placeholder="New password" value={password} onChange={e => setPassword(e.target.value)} required minLength={8} style={inp}/>
            <input type="password" placeholder="Confirm password" value={confirm} onChange={e => setConfirm(e.target.value)} required minLength={8} style={inp}/>
            {err && <div style={{ color:"#E0245E", fontSize:14, marginBottom:12 }}>{err}</div>}
            {msg && <div style={{ color:"#22C55E", fontSize:14, marginBottom:12 }}>{msg}</div>}
            <button type="submit" disabled={loading} style={{ width:"100%", padding:13, background:"#fff", color:"#000", border:"none", borderRadius:9999, fontWeight:700, fontSize:16, cursor:"pointer", fontFamily:"inherit", opacity:loading?0.7:1 }}>
              {loading ? "Resetting…" : "Reset password"}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
