"use client";
import { useState, useEffect } from "react";
import { useParams, useRouter } from "next/navigation";
import { AppShell } from "@/components/layout/AppShell";
import { PostCard, type Post } from "@/components/feed/PostCard";
import { Composer } from "@/components/composer/Composer";
import { useAuthStore } from "@/store/authStore";
import api from "@/lib/api";

function Skeleton() {
  return (
    <div style={{ padding:"16px", borderBottom:"1px solid var(--nrp-border)", display:"flex", gap:12 }}>
      <div className="skeleton" style={{ width:44, height:44, borderRadius:"50%", flexShrink:0 }}/>
      <div style={{ flex:1 }}>
        <div className="skeleton" style={{ height:14, width:"40%", borderRadius:4, marginBottom:10 }}/>
        <div className="skeleton" style={{ height:14, width:"100%", borderRadius:4, marginBottom:6 }}/>
        <div className="skeleton" style={{ height:14, width:"80%", borderRadius:4 }}/>
      </div>
    </div>
  );
}

export default function PostPage() {
  const { id }   = useParams<{ id: string }>();
  const router   = useRouter();
  const { user } = useAuthStore();
  const [post,    setPost]    = useState<Post | null>(null);
  const [replies, setReplies] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [notFound,setNotFound]= useState(false);

  const load = async () => {
    try {
      const { data } = await api.get(`/posts/${id}`);
      setPost(data.post);
      setReplies(data.replies || []);
    } catch { setNotFound(true); }
    setLoading(false);
  };

  useEffect(() => { load(); }, [id]);

  if (loading) return (
    <AppShell>
      <div style={{ padding:"12px 16px", fontWeight:800, fontSize:20, borderBottom:"1px solid var(--nrp-border)", display:"flex", gap:14, alignItems:"center" }}>
        <button onClick={() => router.back()} style={{ background:"none", border:"none", cursor:"pointer", color:"var(--nrp-fg)", display:"flex", padding:4 }}>←</button>
        Post
      </div>
      <Skeleton/>
    </AppShell>
  );

  if (notFound || !post) return (
    <AppShell>
      <div style={{ padding:"12px 16px", fontWeight:800, fontSize:20, borderBottom:"1px solid var(--nrp-border)", display:"flex", gap:14, alignItems:"center" }}>
        <button onClick={() => router.back()} style={{ background:"none", border:"none", cursor:"pointer", color:"var(--nrp-fg)", display:"flex", padding:4 }}>←</button>
        Post
      </div>
      <div style={{ padding:48, textAlign:"center", color:"var(--nrp-muted)" }}>
        <div style={{ fontSize:24, fontWeight:800, marginBottom:8 }}>Post not found</div>
        <div style={{ fontSize:15 }}>This post may have been deleted.</div>
      </div>
    </AppShell>
  );

  return (
    <AppShell>
      <div style={{ padding:"12px 16px", borderBottom:"1px solid var(--nrp-border)", position:"sticky", top:0, background:"var(--nrp-bg)", backdropFilter:"blur(12px)", zIndex:20, display:"flex", gap:14, alignItems:"center", fontWeight:800, fontSize:20 }}>
        <button onClick={() => router.back()} style={{ background:"none", border:"none", cursor:"pointer", color:"var(--nrp-fg)", display:"flex", padding:4 }}>←</button>
        Post
      </div>

      {/* The post itself */}
      <PostCard post={post} queryKey={["post", id]}/>

      {/* Reply composer */}
      {user && (
        <Composer replyTo={post} placeholder={`Reply to @${post.author.handle}…`}
          onSuccess={newReply => setReplies(p => [newReply, ...p])}/>
      )}

      {/* Replies */}
      {replies.length > 0 && (
        <div style={{ borderTop:"1px solid var(--nrp-border)" }}>
          {replies.map(r => (
            <div key={r._id} style={{ paddingLeft:12 }}>
              <PostCard post={r} queryKey={["post", id]}/>
            </div>
          ))}
        </div>
      )}
    </AppShell>
  );
}
