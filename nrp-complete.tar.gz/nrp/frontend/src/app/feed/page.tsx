"use client";
import { useState, useEffect, useCallback, useRef } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { PostCard, type Post } from "@/components/feed/PostCard";
import { Composer } from "@/components/composer/Composer";
import { useAuthStore } from "@/store/authStore";
import { getSocket } from "@/lib/socket";
import api from "@/lib/api";

function Skeleton() {
  return (
    <div style={{ padding:"12px 16px", borderBottom:"1px solid var(--nrp-border)", display:"flex", gap:12 }}>
      <div className="skeleton" style={{ width:44, height:44, borderRadius:"50%", flexShrink:0 }}/>
      <div style={{ flex:1 }}>
        <div className="skeleton" style={{ height:14, width:"40%", borderRadius:4, marginBottom:8 }}/>
        <div className="skeleton" style={{ height:14, width:"100%", borderRadius:4, marginBottom:6 }}/>
        <div className="skeleton" style={{ height:14, width:"75%", borderRadius:4 }}/>
      </div>
    </div>
  );
}

function ReplyModal({ post, onClose, onDone }: { post: Post; onClose: ()=>void; onDone: ()=>void }) {
  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.75)", zIndex:300, display:"flex", alignItems:"flex-start", justifyContent:"center", paddingTop:60 }} onClick={onClose}>
      <div style={{ background:"var(--nrp-bg)", border:"1px solid var(--nrp-border)", borderRadius:16, width:"100%", maxWidth:560, animation:"fadeIn 0.15s" }} onClick={e=>e.stopPropagation()}>
        <div style={{ padding:"14px 16px", borderBottom:"1px solid var(--nrp-border)", display:"flex", justifyContent:"flex-end" }}>
          <button onClick={onClose} style={{ background:"none", border:"none", color:"var(--nrp-muted)", cursor:"pointer", fontSize:20 }}>✕</button>
        </div>
        <div style={{ padding:"10px 16px", borderBottom:"1px solid var(--nrp-border)", opacity:0.65 }}>
          <div style={{ fontSize:15, color:"var(--nrp-muted)" }}>
            <strong style={{ color:"var(--nrp-fg)" }}>{post.author.name}</strong>: {post.content.slice(0,120)}{post.content.length>120?"…":""}
          </div>
        </div>
        <Composer replyTo={post} placeholder={`Reply to @${post.author.handle}…`} onSuccess={()=>{ onDone(); onClose(); }}/>
      </div>
    </div>
  );
}

export default function FeedPage() {
  const { user } = useAuthStore();
  const [tab, setTab]         = useState<"foryou"|"following">("foryou");
  const [posts, setPosts]     = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [cursor, setCursor]   = useState<string|null>(null);
  const [hasMore, setHasMore] = useState(true);
  const [replyTo, setReplyTo] = useState<Post|null>(null);
  const [newCount, setNewCount] = useState(0);
  const loaderRef = useRef<HTMLDivElement>(null);
  const fetchingRef = useRef(false);

  const loadPosts = useCallback(async (reset=false, overrideCursor?: string|null) => {
    if (fetchingRef.current) return;
    fetchingRef.current = true;
    setLoading(true);
    try {
      const useCursor = reset ? null : (overrideCursor !== undefined ? overrideCursor : cursor);
      const params = new URLSearchParams({ tab, limit:"20" });
      if (useCursor) params.set("cursor", useCursor);
      const { data } = await api.get(`/posts/feed?${params}`);
      const newPosts: Post[] = data.posts || [];
      setPosts(prev => reset ? newPosts : [...prev, ...newPosts]);
      setCursor(data.nextCursor || null);
      setHasMore(!!data.nextCursor);
    } catch {}
    setLoading(false);
    fetchingRef.current = false;
  }, [tab, cursor]);

  // Tab change → full reset
  useEffect(() => {
    setPosts([]); setCursor(null); setHasMore(true); setNewCount(0);
    (async () => {
      fetchingRef.current = false;
      await loadPosts(true, null);
    })();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab]);

  // Infinite scroll
  useEffect(() => {
    const obs = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting && hasMore && !loading) loadPosts(false);
    }, { threshold: 0.1 });
    if (loaderRef.current) obs.observe(loaderRef.current);
    return () => obs.disconnect();
  }, [hasMore, loading, loadPosts]);

  // Real-time socket
  useEffect(() => {
    if (!user) return;
    const socket = getSocket();
    const onNew = (post: Post) => {
      if (tab === "following" && !user.following?.includes(post.author._id as any)) return;
      setNewCount(n => n+1);
    };
    const onDel = ({ id }: { id: string }) => setPosts(p => p.filter(x => x._id !== id));
    socket.on("post:new", onNew);
    socket.on("post:delete", onDel);
    return () => { socket.off("post:new", onNew); socket.off("post:delete", onDel); };
  }, [user, tab]);

  // Compose event from AppShell Post button
  useEffect(() => {
    const handler = () => { setNewCount(0); loadPosts(true, null); };
    window.addEventListener("nrp:newpost", handler);
    return () => window.removeEventListener("nrp:newpost", handler);
  }, [loadPosts]);

  const showNewBanner = async () => {
    setNewCount(0);
    await loadPosts(true, null);
  };

  const tabBtn = (t: "foryou"|"following", label: string) => (
    <button key={t} onClick={() => setTab(t)}
      style={{ flex:1, padding:16, textAlign:"center" as const, cursor:"pointer", fontWeight:tab===t?700:500, fontSize:15, color:tab===t?"var(--nrp-fg)":"var(--nrp-muted)", background:"none", border:"none", borderBottom:tab===t?"2px solid var(--nrp-fg)":"2px solid transparent", fontFamily:"inherit", transition:"all 0.12s" }}
      onMouseEnter={e=>(e.currentTarget.style.background="var(--nrp-hover)")}
      onMouseLeave={e=>(e.currentTarget.style.background="")}>
      {label}
    </button>
  );

  return (
    <AppShell>
      <div style={{ padding:"12px 16px", borderBottom:"1px solid var(--nrp-border)", position:"sticky", top:0, background:"var(--nrp-bg)", backdropFilter:"blur(12px)", zIndex:20, fontWeight:800, fontSize:20 }}>
        NRP
      </div>

      <div style={{ display:"flex", borderBottom:"1px solid var(--nrp-border)" }}>
        {tabBtn("foryou", "For you")}
        {tabBtn("following", "Following")}
      </div>

      {user && <Composer onSuccess={p => { setPosts(prev => [p, ...prev]); setNewCount(0); }}/>}

      {newCount > 0 && (
        <div onClick={showNewBanner}
          style={{ padding:"12px 16px", textAlign:"center", borderBottom:"1px solid var(--nrp-border)", cursor:"pointer", fontWeight:600, fontSize:14, background:"var(--nrp-subtle)" }}
          onMouseEnter={e=>(e.currentTarget.style.background="var(--nrp-hover)")}
          onMouseLeave={e=>(e.currentTarget.style.background="var(--nrp-subtle)")}>
          ↑ Show {newCount} new post{newCount>1?"s":""}
        </div>
      )}

      {loading && posts.length===0
        ? Array.from({length:5}).map((_,i)=><Skeleton key={i}/>)
        : posts.length===0
        ? (
          <div style={{ padding:48, textAlign:"center", color:"var(--nrp-muted)" }}>
            <div style={{ fontSize:24, fontWeight:800, marginBottom:8 }}>
              {tab==="following" ? "Follow people to see their posts" : "No posts yet"}
            </div>
            <div style={{ fontSize:15 }}>Be the first to post something.</div>
          </div>
        ) : (
          <>
            {posts.map(p => <PostCard key={p._id} post={p} onReply={setReplyTo} queryKey={["feed",tab]}/>)}
            <div ref={loaderRef} style={{ padding:16, textAlign:"center", color:"var(--nrp-muted)", fontSize:14 }}>
              {loading
                ? <div style={{ width:20, height:20, border:"2px solid var(--nrp-border)", borderTopColor:"var(--nrp-fg)", borderRadius:"50%", margin:"0 auto", animation:"spin 0.8s linear infinite" }}/>
                : hasMore ? "" : "✓ All caught up"}
            </div>
          </>
        )
      }

      {replyTo && <ReplyModal post={replyTo} onClose={()=>setReplyTo(null)} onDone={()=>loadPosts(true,null)}/>}
    </AppShell>
  );
}
