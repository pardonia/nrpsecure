"use client";
import { useState, useEffect, useRef } from "react";
import { useParams, useRouter } from "next/navigation";
import { CalendarDays, MapPin, Link as LinkIcon, Mail, X, Camera } from "lucide-react";
import { AppShell, Avatar } from "@/components/layout/AppShell";
import { PostCard, type Post } from "@/components/feed/PostCard";
import { useAuthStore } from "@/store/authStore";
import { fmtCount, timeAgo } from "@/lib/utils";
import api from "@/lib/api";

type Tab = "posts" | "replies" | "media" | "likes";

function EditProfileModal({ profile, onClose, onSave }: { profile: any; onClose: () => void; onSave: (p: any) => void }) {
  const [form, setForm] = useState({ name: profile.name || "", bio: profile.bio || "", location: profile.location || "", website: profile.website || "", handle: profile.handle || "" });
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [coverFile,  setCoverFile]  = useState<File | null>(null);
  const [avatarPrev, setAvatarPrev] = useState<string>(profile.avatarUrl || "");
  const [coverPrev,  setCoverPrev]  = useState<string>(profile.coverUrl  || "");
  const [loading,    setLoading]    = useState(false);
  const [error,      setError]      = useState("");
  const avatarRef = useRef<HTMLInputElement>(null);
  const coverRef  = useRef<HTMLInputElement>(null);
  const { updateUser } = useAuthStore();

  const pickFile = (file: File, field: "avatar" | "cover") => {
    const url = URL.createObjectURL(file);
    if (field === "avatar") { setAvatarFile(file); setAvatarPrev(url); }
    else                    { setCoverFile(file);  setCoverPrev(url); }
  };

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(""); setLoading(true);
    try {
      const fd = new FormData();
      Object.entries(form).forEach(([k, v]) => fd.append(k, v));
      if (avatarFile) fd.append("avatar", avatarFile);
      if (coverFile)  fd.append("cover",  coverFile);
      const { data } = await api.patch("/users/me", fd, { headers: { "Content-Type": "multipart/form-data" } });
      updateUser(data.user);
      onSave(data.user);
      onClose();
    } catch (err: any) { setError(err.response?.data?.error || "Update failed"); }
    setLoading(false);
  };

  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.75)", zIndex:300, display:"flex", alignItems:"flex-start", justifyContent:"center", paddingTop:40, overflow:"auto" }}>
      <div style={{ background:"var(--nrp-bg)", border:"1px solid var(--nrp-border)", borderRadius:16, width:"100%", maxWidth:560, animation:"fadeIn 0.15s" }} onClick={e => e.stopPropagation()}>
        <div style={{ padding:"14px 16px", borderBottom:"1px solid var(--nrp-border)", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
          <button onClick={onClose} style={{ background:"none", border:"none", color:"var(--nrp-fg)", cursor:"pointer", display:"flex" }}><X size={20}/></button>
          <span style={{ fontWeight:800, fontSize:17 }}>Edit profile</span>
          <button onClick={save} disabled={loading} style={{ background:"var(--nrp-fg)", color:"var(--nrp-bg)", border:"none", padding:"7px 18px", borderRadius:9999, fontWeight:700, fontSize:14, cursor:"pointer", fontFamily:"inherit", opacity:loading?0.7:1 }}>
            {loading ? "Saving…" : "Save"}
          </button>
        </div>

        {/* Cover */}
        <div style={{ position:"relative", height:150, background:"var(--nrp-subtle)", cursor:"pointer" }} onClick={() => coverRef.current?.click()}>
          {coverPrev && <img src={coverPrev} alt="" style={{ width:"100%", height:"100%", objectFit:"cover" }}/>}
          <div style={{ position:"absolute", inset:0, display:"flex", alignItems:"center", justifyContent:"center", background:"rgba(0,0,0,0.35)" }}>
            <Camera size={28} color="#fff"/>
          </div>
          <input ref={coverRef} type="file" accept="image/*" style={{ display:"none" }} onChange={e => e.target.files?.[0] && pickFile(e.target.files[0], "cover")}/>
        </div>

        {/* Avatar */}
        <div style={{ padding:"0 16px", position:"relative", marginTop:-32, marginBottom:16 }}>
          <div style={{ position:"relative", width:64, display:"inline-block", cursor:"pointer" }} onClick={() => avatarRef.current?.click()}>
            <div style={{ border:"4px solid var(--nrp-bg)", borderRadius:"50%" }}>
              <Avatar name={form.name || "?"} url={avatarPrev} size={64}/>
            </div>
            <div style={{ position:"absolute", inset:0, display:"flex", alignItems:"center", justifyContent:"center", background:"rgba(0,0,0,0.4)", borderRadius:"50%" }}>
              <Camera size={18} color="#fff"/>
            </div>
          </div>
          <input ref={avatarRef} type="file" accept="image/*" style={{ display:"none" }} onChange={e => e.target.files?.[0] && pickFile(e.target.files[0], "avatar")}/>
        </div>

        <form onSubmit={save} style={{ padding:"0 16px 20px" }}>
          {[
            { label:"Name", key:"name", max:50 },
            { label:"Handle", key:"handle", max:20 },
            { label:"Bio", key:"bio", max:160, multiline:true },
            { label:"Location", key:"location", max:60 },
            { label:"Website", key:"website", max:100 },
          ].map(f => (
            <div key={f.key} style={{ marginBottom:14, position:"relative" }}>
              <label style={{ fontSize:12, color:"var(--nrp-muted)", display:"block", marginBottom:4 }}>{f.label}</label>
              {f.multiline ? (
                <textarea value={(form as any)[f.key]} onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
                  maxLength={f.max} rows={3}
                  style={{ width:"100%", background:"none", border:"1px solid var(--nrp-border)", borderRadius:8, padding:"10px 12px", color:"var(--nrp-fg)", fontSize:15, outline:"none", resize:"none", fontFamily:"inherit" }}
                  onFocus={e => (e.target.style.borderColor="var(--nrp-fg)")} onBlur={e => (e.target.style.borderColor="var(--nrp-border)")}/>
              ) : (
                <input value={(form as any)[f.key]} onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
                  maxLength={f.max}
                  style={{ width:"100%", background:"none", border:"1px solid var(--nrp-border)", borderRadius:8, padding:"10px 12px", color:"var(--nrp-fg)", fontSize:15, outline:"none", fontFamily:"inherit" }}
                  onFocus={e => (e.target.style.borderColor="var(--nrp-fg)")} onBlur={e => (e.target.style.borderColor="var(--nrp-border)")}/>
              )}
              <span style={{ position:"absolute", right:8, bottom:8, fontSize:11, color:"var(--nrp-muted)" }}>{(form as any)[f.key].length}/{f.max}</span>
            </div>
          ))}
          {error && <div style={{ color:"#E0245E", fontSize:14, padding:"8px 12px", background:"rgba(224,36,94,0.1)", borderRadius:8 }}>{error}</div>}
        </form>
      </div>
    </div>
  );
}

export default function ProfilePage() {
  const { handle }   = useParams<{ handle: string }>();
  const { user: me, updateUser } = useAuthStore();
  const router       = useRouter();
  const [profile,    setProfile]    = useState<any>(null);
  const [posts,      setPosts]      = useState<Post[]>([]);
  const [tab,        setTab]        = useState<Tab>("posts");
  const [following,  setFollowing]  = useState(false);
  const [editing,    setEditing]    = useState(false);
  const [loading,    setLoading]    = useState(true);
  const isMe = me?.handle === handle;

  useEffect(() => {
    setLoading(true);
    Promise.all([
      api.get(`/users/${handle}`),
      api.get(`/users/${handle}/posts?tab=posts&limit=20`),
    ]).then(([u, p]) => {
      setProfile(u.data.user);
      setFollowing(u.data.user.isFollowing || false);
      setPosts(p.data.posts || []);
    }).catch(() => setProfile(null))
      .finally(() => setLoading(false));
  }, [handle]);

  useEffect(() => {
    if (!profile) return;
    api.get(`/users/${handle}/posts?tab=${tab}&limit=20`).then(r => setPosts(r.data.posts || []));
  }, [tab, handle, profile]);

  const toggleFollow = async () => {
    if (!me) return;
    const next = !following;
    setFollowing(next);
    setProfile((p: any) => p ? { ...p, followersCount: p.followersCount + (next ? 1 : -1) } : p);
    try { await api.post(`/users/${profile._id}/follow`); } catch { setFollowing(!next); }
  };

  const startDM = async () => {
    if (!me) return;
    try {
      const { data } = await api.post("/messages/conversation", { targetId: profile._id });
      router.push(`/messages?c=${data.conversation._id}`);
    } catch {}
  };

  if (loading) return (
    <AppShell>
      <div style={{ padding:"12px 16px", fontWeight:800, fontSize:20, borderBottom:"1px solid var(--nrp-border)" }}>Profile</div>
      <div style={{ height:180, background:"var(--nrp-subtle)" }} className="skeleton"/>
      <div style={{ padding:"0 16px", marginTop:"-32px" }}>
        <div className="skeleton" style={{ width:72, height:72, borderRadius:"50%", border:"4px solid var(--nrp-bg)" }}/>
        <div className="skeleton" style={{ height:18, width:"30%", marginTop:16, borderRadius:4 }}/>
        <div className="skeleton" style={{ height:14, width:"20%", marginTop:8, borderRadius:4 }}/>
      </div>
    </AppShell>
  );

  if (!profile) return (
    <AppShell>
      <div style={{ padding:48, textAlign:"center", color:"var(--nrp-muted)" }}>
        <div style={{ fontSize:24, fontWeight:800, marginBottom:8 }}>User not found</div>
        <div style={{ fontSize:15 }}>This account doesn't exist.</div>
      </div>
    </AppShell>
  );

  return (
    <AppShell>
      {/* Header */}
      <div style={{ padding:"12px 16px", borderBottom:"1px solid var(--nrp-border)", position:"sticky", top:0, background:"var(--nrp-bg)", backdropFilter:"blur(12px)", zIndex:20, display:"flex", gap:14, alignItems:"center", fontWeight:800, fontSize:20 }}>
        <button onClick={() => router.back()} style={{ background:"none", border:"none", cursor:"pointer", color:"var(--nrp-fg)", display:"flex", padding:4 }}>←</button>
        <div>
          <div>{profile.name}</div>
          <div style={{ fontSize:13, color:"var(--nrp-muted)", fontWeight:400 }}>{fmtCount(profile.postsCount)} posts</div>
        </div>
      </div>

      {/* Cover */}
      <div style={{ height:180, background:"var(--nrp-subtle)", position:"relative", overflow:"hidden" }}>
        {profile.coverUrl && <img src={profile.coverUrl} alt="" style={{ width:"100%", height:"100%", objectFit:"cover" }}/>}
      </div>

      {/* Profile info */}
      <div style={{ padding:"0 16px 16px" }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-end", marginTop:-28, marginBottom:12 }}>
          <div style={{ border:"4px solid var(--nrp-bg)", borderRadius:"50%" }}>
            <Avatar name={profile.name} url={profile.avatarUrl} size={72}/>
          </div>
          <div style={{ display:"flex", gap:8, marginBottom:4 }}>
            {isMe ? (
              <button onClick={() => setEditing(true)}
                style={{ border:"1px solid var(--nrp-border)", background:"none", color:"var(--nrp-fg)", padding:"7px 16px", borderRadius:9999, fontWeight:700, fontSize:14, cursor:"pointer", fontFamily:"inherit" }}>
                Edit profile
              </button>
            ) : (
              <>
                {me && (
                  <button onClick={startDM}
                    style={{ border:"1px solid var(--nrp-border)", background:"none", color:"var(--nrp-fg)", padding:"7px 10px", borderRadius:9999, cursor:"pointer", display:"flex", alignItems:"center" }}>
                    <Mail size={16}/>
                  </button>
                )}
                <button onClick={toggleFollow}
                  style={{ border:"1px solid var(--nrp-fg)", background:following?"transparent":"var(--nrp-fg)", color:following?"var(--nrp-fg)":"var(--nrp-bg)", padding:"7px 18px", borderRadius:9999, fontWeight:700, fontSize:14, cursor:"pointer", fontFamily:"inherit", transition:"all 0.15s" }}
                  onMouseEnter={e => { if (following) { e.currentTarget.style.borderColor="#E0245E"; e.currentTarget.style.color="#E0245E"; } }}
                  onMouseLeave={e => { e.currentTarget.style.borderColor="var(--nrp-fg)"; e.currentTarget.style.color=following?"var(--nrp-fg)":"var(--nrp-bg)"; }}>
                  {following ? "Following" : "Follow"}
                </button>
              </>
            )}
          </div>
        </div>

        <div style={{ display:"flex", alignItems:"center", gap:6, marginBottom:4 }}>
          <div style={{ fontWeight:800, fontSize:20 }}>{profile.name}</div>
          {profile.verified && (
            <svg width={18} height={18} viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.09 6.26L21 9l-5.14 4.74 1.04 6.28L12 18l-4.9 2.02 1.04-6.28L3 9l6.91-.74z"/><path d="M9 12l2 2 4-4" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" fill="none"/></svg>
          )}
        </div>
        <div style={{ color:"var(--nrp-muted)", fontSize:15, marginBottom:10 }}>@{profile.handle}</div>

        {profile.bio && <div style={{ fontSize:15, lineHeight:1.5, marginBottom:10 }}>{profile.bio}</div>}

        <div style={{ display:"flex", flexWrap:"wrap", gap:12, color:"var(--nrp-muted)", fontSize:14, marginBottom:12 }}>
          {profile.location && <span style={{ display:"flex", alignItems:"center", gap:4 }}><MapPin size={14}/>{profile.location}</span>}
          {profile.website  && <a href={profile.website} target="_blank" rel="noopener noreferrer" style={{ display:"flex", alignItems:"center", gap:4, color:"var(--nrp-fg)", textDecoration:"none" }}><LinkIcon size={14}/>{profile.website.replace(/^https?:\/\//, "")}</a>}
          <span style={{ display:"flex", alignItems:"center", gap:4 }}><CalendarDays size={14}/>Joined {new Date(profile.joinedAt).toLocaleDateString("en-US", { month:"long", year:"numeric" })}</span>
        </div>

        <div style={{ display:"flex", gap:20, fontSize:15 }}>
          <span style={{ cursor:"pointer" }} onClick={() => router.push(`/profile/${handle}/following`)}><strong>{fmtCount(profile.followingCount)}</strong> <span style={{ color:"var(--nrp-muted)" }}>Following</span></span>
          <span style={{ cursor:"pointer" }} onClick={() => router.push(`/profile/${handle}/followers`)}><strong>{fmtCount(profile.followersCount)}</strong> <span style={{ color:"var(--nrp-muted)" }}>Followers</span></span>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display:"flex", borderBottom:"1px solid var(--nrp-border)" }}>
        {(["posts","replies","media","likes"] as Tab[]).map(t => (
          <button key={t} onClick={() => setTab(t)}
            style={{ flex:1, padding:"13px", textAlign:"center", cursor:"pointer", fontWeight:tab===t?700:500, fontSize:14, color:tab===t?"var(--nrp-fg)":"var(--nrp-muted)", background:"none", border:"none", borderBottom:tab===t?"2px solid var(--nrp-fg)":"2px solid transparent", fontFamily:"inherit", textTransform:"capitalize" }}
            onMouseEnter={e => (e.currentTarget.style.background = "var(--nrp-hover)")}
            onMouseLeave={e => (e.currentTarget.style.background = "")}>
            {t}
          </button>
        ))}
      </div>

      {/* Posts */}
      {posts.length === 0 ? (
        <div style={{ padding:40, textAlign:"center", color:"var(--nrp-muted)" }}>
          <div style={{ fontSize:20, fontWeight:800, marginBottom:6 }}>No {tab} yet</div>
        </div>
      ) : posts.map(p => <PostCard key={p._id} post={p} queryKey={["profile", handle, tab]}/>)}

      {editing && <EditProfileModal profile={profile} onClose={() => setEditing(false)} onSave={p => { setProfile(p); updateUser(p); }}/>}
    </AppShell>
  );
}
