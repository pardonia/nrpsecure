"use client";
import Link from "next/link";
export default function NotFound() {
  return (
    <div style={{ minHeight:"100vh", background:"var(--nrp-bg)", display:"flex", alignItems:"center", justifyContent:"center", flexDirection:"column", gap:16, color:"var(--nrp-fg)" }}>
      <div style={{ fontFamily:"'Courier New',monospace", fontWeight:900, fontSize:36, letterSpacing:-2 }}>NRP</div>
      <div style={{ fontSize:80, fontWeight:900 }}>404</div>
      <div style={{ fontSize:22, fontWeight:700 }}>This page doesn't exist.</div>
      <Link href="/feed" style={{ marginTop:8, background:"var(--nrp-fg)", color:"var(--nrp-bg)", padding:"12px 28px", borderRadius:9999, fontWeight:700, fontSize:16, textDecoration:"none" }}>Go home</Link>
    </div>
  );
}
