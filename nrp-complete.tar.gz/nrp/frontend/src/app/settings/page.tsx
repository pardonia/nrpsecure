"use client";
import { useState } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { useAuthStore } from "@/store/authStore";
import { useRouter } from "next/navigation";
import api from "@/lib/api";

type Section = "account" | "appearance" | "privacy" | "notifications";

export default function SettingsPage() {
  const { user, clearAuth } = useAuthStore();
  const router = useRouter();
  const [section, setSection] = useState<Section>("account");
  const [pwForm, setPwForm] = useState({ current:"", next:"", confirm:"" });
  const [pwMsg, setPwMsg]   = useState("");
  const [pwErr, setPwErr]   = useState("");
  const [dark, setDarkLocal]= useState(() => typeof window !== "undefined" ? localStorage.getItem("nrp_theme") !== "light" : true);

  const changePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPwMsg(""); setPwErr("");
    if (pwForm.next !== pwForm.confirm) { setPwErr("Passwords don't match"); return; }
    if (pwForm.next.length < 8) { setPwErr("Password must be at least 8 characters"); return; }
    try {
      await api.post("/auth/forgot-password", { email: user?.email });
      setPwMsg("Password reset email sent. Check your inbox.");
      setPwForm({ current:"", next:"", confirm:"" });
    } catch (err: any) { setPwErr(err.response?.data?.error || "Failed"); }
  };

  const toggleTheme = () => {
    const next = !dark;
    setDarkLocal(next);
    localStorage.setItem("nrp_theme", next ? "dark" : "light");
    document.documentElement.classList.toggle("dark", next);
  };

  const deactivate = async () => {
    if (!confirm("Are you sure? This will permanently delete your account.")) return;
    try {
      clearAuth();
      router.push("/auth");
    } catch {}
  };

  const sections: { id: Section; label: string }[] = [
    { id:"account",      label:"Account" },
    { id:"appearance",   label:"Appearance" },
    { id:"privacy",      label:"Privacy & Safety" },
    { id:"notifications",label:"Notifications" },
  ];

  const inputStyle: React.CSSProperties = { display:"block", width:"100%", background:"var(--nrp-subtle)", border:"1px solid var(--nrp-border)", borderRadius:8, padding:"10px 14px", color:"var(--nrp-fg)", fontSize:15, outline:"none", fontFamily:"inherit", marginBottom:10 };

  return (
    <AppShell>
      <div style={{ padding:"12px 16px", borderBottom:"1px solid var(--nrp-border)", position:"sticky", top:0, background:"var(--nrp-bg)", backdropFilter:"blur(12px)", zIndex:20, fontWeight:800, fontSize:20 }}>
        Settings
      </div>

      <div style={{ display:"flex" }}>
        {/* Sections nav */}
        <div style={{ width:220, borderRight:"1px solid var(--nrp-border)", padding:"8px 0", flexShrink:0 }}>
          {sections.map(s => (
            <button key={s.id} onClick={() => setSection(s.id)}
              style={{ display:"block", width:"100%", padding:"12px 16px", textAlign:"left", background:section===s.id?"var(--nrp-subtle)":"none", border:"none", color:"var(--nrp-fg)", fontSize:15, fontWeight:section===s.id?700:400, cursor:"pointer", fontFamily:"inherit", borderRight:section===s.id?"2px solid var(--nrp-fg)":"none", transition:"background 0.1s" }}
              onMouseEnter={e => { if (section !== s.id) e.currentTarget.style.background="var(--nrp-hover)"; }}
              onMouseLeave={e => { if (section !== s.id) e.currentTarget.style.background="none"; }}>
              {s.label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div style={{ flex:1, padding:"20px 24px", maxWidth:560 }}>
          {section === "account" && (
            <>
              <div style={{ fontWeight:800, fontSize:18, marginBottom:20 }}>Account information</div>
              <div style={{ marginBottom:20, padding:"14px 16px", background:"var(--nrp-subtle)", borderRadius:12, border:"1px solid var(--nrp-border)" }}>
                <div style={{ fontSize:13, color:"var(--nrp-muted)", marginBottom:4 }}>Email</div>
                <div style={{ fontSize:15 }}>{user?.email}</div>
              </div>
              <div style={{ marginBottom:20, padding:"14px 16px", background:"var(--nrp-subtle)", borderRadius:12, border:"1px solid var(--nrp-border)" }}>
                <div style={{ fontSize:13, color:"var(--nrp-muted)", marginBottom:4 }}>Handle</div>
                <div style={{ fontSize:15 }}>@{user?.handle}</div>
              </div>

              <div style={{ fontWeight:700, fontSize:16, marginBottom:12 }}>Change password</div>
              <form onSubmit={changePassword}>
                <input type="password" placeholder="Current password" value={pwForm.current} onChange={e => setPwForm(p => ({ ...p, current:e.target.value }))} style={inputStyle}/>
                <input type="password" placeholder="New password (min 8 chars)" value={pwForm.next} onChange={e => setPwForm(p => ({ ...p, next:e.target.value }))} style={inputStyle}/>
                <input type="password" placeholder="Confirm new password" value={pwForm.confirm} onChange={e => setPwForm(p => ({ ...p, confirm:e.target.value }))} style={inputStyle}/>
                {pwErr && <div style={{ color:"#E0245E", fontSize:14, marginBottom:10 }}>{pwErr}</div>}
                {pwMsg && <div style={{ color:"#22C55E", fontSize:14, marginBottom:10 }}>{pwMsg}</div>}
                <button type="submit" style={{ background:"var(--nrp-fg)", color:"var(--nrp-bg)", border:"none", padding:"10px 22px", borderRadius:9999, fontWeight:700, fontSize:14, cursor:"pointer", fontFamily:"inherit" }}>
                  Send reset email
                </button>
              </form>

              <div style={{ marginTop:36, paddingTop:20, borderTop:"1px solid var(--nrp-border)" }}>
                <div style={{ fontWeight:700, fontSize:16, color:"#E0245E", marginBottom:8 }}>Danger zone</div>
                <button onClick={deactivate} style={{ background:"none", border:"1px solid #E0245E", color:"#E0245E", padding:"10px 22px", borderRadius:9999, fontWeight:700, fontSize:14, cursor:"pointer", fontFamily:"inherit" }}>
                  Deactivate account
                </button>
              </div>
            </>
          )}

          {section === "appearance" && (
            <>
              <div style={{ fontWeight:800, fontSize:18, marginBottom:20 }}>Appearance</div>
              <div style={{ marginBottom:16 }}>
                <div style={{ fontWeight:600, fontSize:15, marginBottom:12 }}>Theme</div>
                <div style={{ display:"flex", gap:12 }}>
                  {[{ label:"Light", value:false },{ label:"Dark (Lights Out)", value:true }].map(t => (
                    <div key={String(t.value)} onClick={() => { if (t.value !== dark) toggleTheme(); }}
                      style={{ flex:1, padding:20, borderRadius:12, border:`2px solid ${dark===t.value?"var(--nrp-fg)":"var(--nrp-border)"}`, cursor:"pointer", textAlign:"center", background:t.value?"#000":"#fff", transition:"border 0.15s" }}>
                      <div style={{ color:t.value?"#fff":"#000", fontWeight:700, fontSize:15 }}>{t.label}</div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

          {section === "privacy" && (
            <>
              <div style={{ fontWeight:800, fontSize:18, marginBottom:20 }}>Privacy & Safety</div>
              {[
                { label:"Protected posts", desc:"Only approved followers can see your posts" },
                { label:"Hide profile from search", desc:"Your account won't appear in search results" },
                { label:"Allow DMs from everyone", desc:"Anyone can send you a direct message" },
              ].map((item, i) => (
                <div key={i} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"14px 0", borderBottom:"1px solid var(--nrp-border)" }}>
                  <div>
                    <div style={{ fontWeight:600, fontSize:15 }}>{item.label}</div>
                    <div style={{ color:"var(--nrp-muted)", fontSize:13, marginTop:2 }}>{item.desc}</div>
                  </div>
                  <div style={{ width:44, height:24, borderRadius:9999, background:"var(--nrp-border)", cursor:"pointer", position:"relative", flexShrink:0 }}>
                    <div style={{ width:18, height:18, borderRadius:"50%", background:"var(--nrp-muted)", position:"absolute", top:3, left:3, transition:"transform 0.2s" }}/>
                  </div>
                </div>
              ))}
            </>
          )}

          {section === "notifications" && (
            <>
              <div style={{ fontWeight:800, fontSize:18, marginBottom:20 }}>Notification preferences</div>
              {[
                { label:"Likes", desc:"When someone likes your post" },
                { label:"Reposts", desc:"When someone reposts your post" },
                { label:"New followers", desc:"When someone follows you" },
                { label:"Mentions", desc:"When someone @mentions you" },
                { label:"Replies", desc:"When someone replies to your post" },
                { label:"Direct messages", desc:"When you receive a new message" },
              ].map((item, i) => (
                <div key={i} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"14px 0", borderBottom:"1px solid var(--nrp-border)" }}>
                  <div>
                    <div style={{ fontWeight:600, fontSize:15 }}>{item.label}</div>
                    <div style={{ color:"var(--nrp-muted)", fontSize:13, marginTop:2 }}>{item.desc}</div>
                  </div>
                  <div style={{ width:44, height:24, borderRadius:9999, background:"var(--nrp-fg)", cursor:"pointer", position:"relative", flexShrink:0 }}>
                    <div style={{ width:18, height:18, borderRadius:"50%", background:"var(--nrp-bg)", position:"absolute", top:3, right:3, transition:"transform 0.2s" }}/>
                  </div>
                </div>
              ))}
            </>
          )}
        </div>
      </div>
    </AppShell>
  );
}
