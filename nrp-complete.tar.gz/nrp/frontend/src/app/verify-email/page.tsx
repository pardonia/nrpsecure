"use client";
import { useEffect, useState } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import api from "@/lib/api";

export default function VerifyEmailPage() {
  const params = useSearchParams();
  const router = useRouter();
  const token  = params.get("token") || "";
  const [status, setStatus] = useState<"loading"|"ok"|"err">("loading");

  useEffect(() => {
    if (!token) { setStatus("err"); return; }
    api.get(`/auth/verify-email?token=${token}`)
      .then(() => { setStatus("ok"); setTimeout(() => router.push("/feed"), 2500); })
      .catch(() => setStatus("err"));
  }, [token]);

  return (
    <div style={{ minHeight:"100vh", background:"#000", display:"flex", alignItems:"center", justifyContent:"center" }}>
      <div style={{ textAlign:"center", color:"#fff" }}>
        <div style={{ fontFamily:"'Courier New',monospace", fontWeight:900, fontSize:36, letterSpacing:-2, marginBottom:24 }}>NRP</div>
        {status === "loading" && <div style={{ color:"#71767B" }}>Verifying your email…</div>}
        {status === "ok"      && <div style={{ color:"#22C55E", fontSize:18, fontWeight:700 }}>✓ Email verified! Redirecting…</div>}
        {status === "err"     && <div style={{ color:"#E0245E" }}>Invalid or expired link. <a href="/auth" style={{ color:"#fff" }}>Return to login</a></div>}
      </div>
    </div>
  );
}
