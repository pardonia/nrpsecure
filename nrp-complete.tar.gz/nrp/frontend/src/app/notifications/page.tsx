"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import { Heart, Repeat2, UserPlus, AtSign, MessageCircle, Quote } from "lucide-react";
import { AppShell, Avatar } from "@/components/layout/AppShell";
import { timeAgo } from "@/lib/utils";
import { getSocket } from "@/lib/socket";
import { useAuthStore } from "@/store/authStore";
import api from "@/lib/api";

type Filter = "all" | "mentions" | "verified";

const TYPE_ICON: Record<string, React.ReactNode> = {
  like:    <Heart size={20} fill="currentColor" color="#E0245E"/>,
  repost:  <Repeat2 size={20} color="#00BA7C"/>,
  follow:  <UserPlus size={20}/>,
  mention: <AtSign size={20} color="#1D9BF0"/>,
  reply:   <MessageCircle size={20} color="#1D9BF0"/>,
  quote:   <Quote size={20}/>,
};

const TYPE_TEXT: Record<string, string> = {
  like:    "liked your post",
  repost:  "reposted your post",
  follow:  "followed you",
  mention: "mentioned you",
  reply:   "replied to your post",
  quote:   "quoted your post",
};

function Skeleton() {
  return (
    <div style={{ display:"flex", gap:12, padding:"14px 16px", borderBottom:"1px solid var(--nrp-border)" }}>
      <div className="skeleton" style={{ width:36, height:36, borderRadius:"50%", flexShrink:0 }}/>
      <div style={{ flex:1 }}>
        <div className="skeleton" style={{ height:13, width:"60%", borderRadius:4, marginBottom:6 }}/>
        <div className="skeleton" style={{ height:13, width:"35%", borderRadius:4 }}/>
      </div>
    </div>
  );
}

export default function NotificationsPage() {
  const { user } = useAuthStore();
  const [filter, setFilter] = useState<Filter>("all");
  const [notifs, setNotifs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async (f: Filter) => {
    setLoading(true);
    try {
      const { data } = await api.get(`/notifications?filter=${f}&limit=50`);
      setNotifs(data.notifications || []);
      await api.post("/notifications/read-all");
    } catch {}
    setLoading(false);
  };

  useEffect(() => { load(filter); }, [filter]);

  useEffect(() => {
    if (!user) return;
    const socket = getSocket();
    const handler = (n: any) => setNotifs(prev => [n, ...prev]);
    socket.on("notification", handler);
    return () => { socket.off("notification", handler); };
  }, [user]);

  return (
    <AppShell>
      <div style={{ padding:"12px 16px", borderBottom:"1px solid var(--nrp-border)", position:"sticky", top:0, background:"var(--nrp-bg)", backdropFilter:"blur(12px)", zIndex:20, fontWeight:800, fontSize:20 }}>
        Notifications
      </div>

      {/* Filter tabs */}
      <div style={{ display:"flex", borderBottom:"1px solid var(--nrp-border)" }}>
        {(["all","mentions","verified"] as Filter[]).map(f => (
          <button key={f} onClick={() => setFilter(f)}
            style={{ flex:1, padding:"13px", textAlign:"center", cursor:"pointer", fontWeight:filter===f?700:500, fontSize:14, color:filter===f?"var(--nrp-fg)":"var(--nrp-muted)", background:"none", border:"none", borderBottom:filter===f?"2px solid var(--nrp-fg)":"2px solid transparent", fontFamily:"inherit", textTransform:"capitalize" }}
            onMouseEnter={e => (e.currentTarget.style.background = "var(--nrp-hover)")}
            onMouseLeave={e => (e.currentTarget.style.background = "")}>
            {f}
          </button>
        ))}
      </div>

      {loading ? (
        Array.from({ length: 6 }).map((_, i) => <Skeleton key={i}/>)
      ) : notifs.length === 0 ? (
        <div style={{ padding:48, textAlign:"center", color:"var(--nrp-muted)" }}>
          <div style={{ fontSize:22, fontWeight:800, marginBottom:8 }}>Nothing here yet</div>
          <div style={{ fontSize:15 }}>When someone likes or replies to a post, you'll see it here.</div>
        </div>
      ) : (
        notifs.map(n => (
          <div key={n._id} style={{ display:"flex", gap:14, padding:"14px 16px", borderBottom:"1px solid var(--nrp-border)", cursor:"pointer", background:n.read ? "transparent" : "var(--nrp-subtle)", transition:"background 0.1s" }}
            onMouseEnter={e => (e.currentTarget.style.background = "var(--nrp-hover)")}
            onMouseLeave={e => (e.currentTarget.style.background = n.read ? "transparent" : "var(--nrp-subtle)")}>
            {/* Type icon */}
            <div style={{ width:36, display:"flex", justifyContent:"center", paddingTop:2, color:"var(--nrp-fg)", flexShrink:0 }}>
              {TYPE_ICON[n.type] || <AtSign size={20}/>}
            </div>
            <div style={{ flex:1, minWidth:0 }}>
              {n.actor && (
                <Link href={`/profile/${n.actor.handle}`} onClick={e => e.stopPropagation()}>
                  <Avatar name={n.actor.name} url={n.actor.avatarUrl} size={32}/>
                </Link>
              )}
              <div style={{ marginTop:6, fontSize:15 }}>
                {n.actor && (
                  <Link href={`/profile/${n.actor.handle}`} style={{ fontWeight:700, textDecoration:"none", color:"var(--nrp-fg)" }}>
                    {n.actor.name}
                  </Link>
                )}{" "}
                <span style={{ color:"var(--nrp-muted)" }}>{TYPE_TEXT[n.type] || n.type}</span>
              </div>
              {n.post?.content && (
                <Link href={`/post/${n.post._id}`} style={{ display:"block", color:"var(--nrp-muted)", fontSize:14, marginTop:4, textDecoration:"none" }}>
                  {n.post.content.slice(0, 80)}{n.post.content.length > 80 ? "…" : ""}
                </Link>
              )}
              <div style={{ fontSize:13, color:"var(--nrp-muted)", marginTop:4 }}>{timeAgo(n.createdAt)}</div>
            </div>
          </div>
        ))
      )}
    </AppShell>
  );
}
