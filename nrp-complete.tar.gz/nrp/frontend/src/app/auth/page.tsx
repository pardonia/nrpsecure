"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuthStore } from "@/store/authStore";
import api from "@/lib/api";

type Mode = "login" | "register" | "forgot";

export default function AuthPage() {
  const router = useRouter();
  const setAuth = useAuthStore(s => s.setAuth);
  const [mode, setMode]   = useState<Mode>("login");
  const [form, setForm]   = useState({ name:"", handle:"", email:"", password:"", confirm:"" });
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [loading, setLoading] = useState(false);

  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(""); setSuccess(""); setLoading(true);
    try {
      if (mode === "login") {
        const { data } = await api.post("/auth/login", { email: form.email, password: form.password });
        setAuth(data.user, data.access, data.refresh);
        router.push("/feed");
      } else if (mode === "register") {
        if (form.password !== form.confirm) { setError("Passwords don't match"); setLoading(false); return; }
        const { data } = await api.post("/auth/register", { name: form.name, handle: form.handle, email: form.email, password: form.password });
        setAuth(data.user, data.access, data.refresh);
        router.push("/feed");
      } else {
        await api.post("/auth/forgot-password", { email: form.email });
        setSuccess("If that email exists, a reset link has been sent.");
      }
    } catch (err: any) {
      setError(err.response?.data?.error || "Something went wrong");
    }
    setLoading(false);
  };

  const inp = (style?: object) => ({
    display:"block", width:"100%", padding:"12px 14px",
    background:"#16181C", border:"1px solid #2F3336",
    borderRadius:8, color:"#fff", fontSize:15, outline:"none",
    fontFamily:"inherit", marginBottom:10, ...style,
  } as React.CSSProperties);

  return (
    <div style={{ minHeight:"100vh", background:"#000", display:"flex", alignItems:"center", justifyContent:"center", padding:16 }}>
      <div style={{ background:"#000", border:"1px solid #2F3336", borderRadius:16, padding:40, width:"100%", maxWidth:400, color:"#fff" }}>
        {/* Logo */}
        <div style={{ textAlign:"center", marginBottom:32 }}>
          <div style={{ fontFamily:"'Courier New',monospace", fontWeight:900, fontSize:38, letterSpacing:-2 }}>NRP</div>
          <div style={{ color:"#71767B", fontSize:14, marginTop:4 }}>Network Relay Platform</div>
        </div>

        {mode !== "forgot" && (
          <div style={{ display:"flex", gap:8, marginBottom:24 }}>
            {(["login","register"] as Mode[]).map(m => (
              <button key={m} onClick={() => { setMode(m); setError(""); }}
                style={{ flex:1, padding:10, borderRadius:9999, border:"1px solid #2F3336", background:mode===m?"#fff":"transparent", color:mode===m?"#000":"#fff", fontWeight:700, cursor:"pointer", fontSize:14, fontFamily:"inherit" }}>
                {m === "login" ? "Sign in" : "Sign up"}
              </button>
            ))}
          </div>
        )}

        <form onSubmit={submit}>
          {mode === "register" && (
            <>
              <input value={form.name} onChange={e=>set("name",e.target.value)} placeholder="Display name" required style={inp()} />
              <input value={form.handle} onChange={e=>set("handle",e.target.value.toLowerCase().replace(/[^a-z0-9_]/g,""))} placeholder="@handle (letters, numbers, _)" required minLength={2} maxLength={20} style={inp()} />
            </>
          )}
          <input type="email" value={form.email} onChange={e=>set("email",e.target.value)} placeholder="Email address" required style={inp()} />
          {mode !== "forgot" && (
            <input type="password" value={form.password} onChange={e=>set("password",e.target.value)} placeholder="Password (min 8 chars)" required minLength={8} style={inp()} />
          )}
          {mode === "register" && (
            <input type="password" value={form.confirm} onChange={e=>set("confirm",e.target.value)} placeholder="Confirm password" required minLength={8} style={inp()} />
          )}

          {error   && <div style={{ color:"#E0245E", fontSize:14, marginBottom:12, padding:"8px 12px", background:"rgba(224,36,94,0.1)", borderRadius:8 }}>{error}</div>}
          {success && <div style={{ color:"#00BA7C", fontSize:14, marginBottom:12, padding:"8px 12px", background:"rgba(0,186,124,0.1)", borderRadius:8 }}>{success}</div>}

          <button type="submit" disabled={loading}
            style={{ width:"100%", padding:13, background:"#fff", color:"#000", border:"none", borderRadius:9999, fontWeight:700, fontSize:16, cursor:loading?"not-allowed":"pointer", opacity:loading?0.7:1, fontFamily:"inherit" }}>
            {loading ? "…" : mode === "login" ? "Sign in" : mode === "register" ? "Create account" : "Send reset link"}
          </button>
        </form>

        <div style={{ textAlign:"center", marginTop:16, fontSize:14, color:"#71767B" }}>
          {mode !== "forgot"
            ? <button onClick={()=>{setMode("forgot");setError("");}} style={{ background:"none",border:"none",color:"#71767B",cursor:"pointer",fontSize:14,fontFamily:"inherit",textDecoration:"underline" }}>Forgot password?</button>
            : <button onClick={()=>{setMode("login");setError("");}} style={{ background:"none",border:"none",color:"#71767B",cursor:"pointer",fontSize:14,fontFamily:"inherit",textDecoration:"underline" }}>Back to sign in</button>
          }
        </div>
      </div>
    </div>
  );
}
