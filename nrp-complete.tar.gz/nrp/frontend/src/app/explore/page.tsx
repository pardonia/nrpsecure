"use client";
import { useState, useEffect, useRef } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import Link from "next/link";
import { Search, X } from "lucide-react";
import { AppShell, Avatar } from "@/components/layout/AppShell";
import { PostCard, type Post } from "@/components/feed/PostCard";
import { fmtCount } from "@/lib/utils";
import api from "@/lib/api";

type SearchType = "posts" | "users" | "hashtags";

function Skeleton() {
  return (
    <div style={{ padding:"12px 16px", borderBottom:"1px solid var(--nrp-border)", display:"flex", gap:12 }}>
      <div className="skeleton" style={{ width:44, height:44, borderRadius:"50%", flexShrink:0 }}/>
      <div style={{ flex:1 }}>
        <div className="skeleton" style={{ height:13, width:"40%", borderRadius:4, marginBottom:8 }}/>
        <div className="skeleton" style={{ height:13, width:"80%", borderRadius:4 }}/>
      </div>
    </div>
  );
}

export default function ExplorePage() {
  const searchParams  = useSearchParams();
  const router        = useRouter();
  const [q, setQ]     = useState(searchParams.get("q") || searchParams.get("tag") ? `#${searchParams.get("tag")}` : "");
  const [type, setType] = useState<SearchType>("posts");
  const [results, setResults] = useState<any[]>([]);
  const [trends, setTrends]   = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const debounce = useRef<ReturnType<typeof setTimeout>>();

  useEffect(() => {
    api.get("/trends").then(r => setTrends(r.data.trends || []));
  }, []);

  useEffect(() => {
    const tag = searchParams.get("tag");
    if (tag) { setQ(`#${tag}`); doSearch(`#${tag}`, "posts"); }
    const sq = searchParams.get("q");
    if (sq) { setQ(sq); doSearch(sq, type); }
  }, [searchParams]);

  const doSearch = async (query: string, t: SearchType) => {
    if (!query.trim()) { setResults([]); return; }
    setLoading(true);
    try {
      const cleanQ = query.startsWith("#") ? query.slice(1) : query;
      const endpoint = query.startsWith("#") ? `/trends/${cleanQ}` : `/search?q=${encodeURIComponent(query)}&type=${t}`;
      const { data } = await api.get(endpoint);
      setResults(query.startsWith("#") ? (data.posts || []) : (data.results || []));
    } catch {}
    setLoading(false);
  };

  const handleInput = (val: string) => {
    setQ(val);
    clearTimeout(debounce.current);
    debounce.current = setTimeout(() => doSearch(val, type), 350);
  };

  const handleTypeChange = (t: SearchType) => {
    setType(t);
    if (q.trim()) doSearch(q, t);
  };

  return (
    <AppShell>
      <div style={{ padding:"12px 16px", borderBottom:"1px solid var(--nrp-border)", position:"sticky", top:0, background:"var(--nrp-bg)", backdropFilter:"blur(12px)", zIndex:20, fontWeight:800, fontSize:20 }}>
        Explore
      </div>

      {/* Search bar */}
      <div style={{ padding:"10px 16px", borderBottom:"1px solid var(--nrp-border)" }}>
        <div style={{ background:"var(--nrp-subtle)", borderRadius:9999, padding:"9px 16px", display:"flex", alignItems:"center", gap:10, border:"1px solid transparent", transition:"border 0.12s" }}
          onFocusCapture={e => (e.currentTarget.style.borderColor = "var(--nrp-fg)")}
          onBlurCapture={e => (e.currentTarget.style.borderColor = "transparent")}>
          <Search size={17} color="var(--nrp-muted)"/>
          <input value={q} onChange={e => handleInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && router.push(`/explore?q=${encodeURIComponent(q)}`)}
            placeholder="Search posts, people, tags…"
            style={{ flex:1, background:"none", border:"none", outline:"none", color:"var(--nrp-fg)", fontSize:15, fontFamily:"inherit" }}
            autoFocus={!!searchParams.get("q")}/>
          {q && <button onClick={() => { setQ(""); setResults([]); }} style={{ background:"none", border:"none", color:"var(--nrp-muted)", cursor:"pointer", display:"flex" }}><X size={16}/></button>}
        </div>
      </div>

      {/* Type tabs (only when searching) */}
      {q && !q.startsWith("#") && (
        <div style={{ display:"flex", borderBottom:"1px solid var(--nrp-border)" }}>
          {(["posts","users","hashtags"] as SearchType[]).map(t => (
            <button key={t} onClick={() => handleTypeChange(t)}
              style={{ flex:1, padding:"13px", textAlign:"center", cursor:"pointer", fontWeight:type===t?700:500, fontSize:14, color:type===t?"var(--nrp-fg)":"var(--nrp-muted)", background:"none", border:"none", borderBottom:type===t?"2px solid var(--nrp-fg)":"2px solid transparent", fontFamily:"inherit", textTransform:"capitalize" }}
              onMouseEnter={e => (e.currentTarget.style.background = "var(--nrp-hover)")}
              onMouseLeave={e => (e.currentTarget.style.background = "")}>
              {t}
            </button>
          ))}
        </div>
      )}

      {/* Results */}
      {loading ? (
        Array.from({ length: 4 }).map((_, i) => <Skeleton key={i}/>)
      ) : q ? (
        results.length === 0 ? (
          <div style={{ padding:48, textAlign:"center", color:"var(--nrp-muted)" }}>
            <div style={{ fontSize:22, fontWeight:800, marginBottom:8 }}>No results for "{q}"</div>
            <div style={{ fontSize:15 }}>Try different keywords.</div>
          </div>
        ) : type === "users" && !q.startsWith("#") ? (
          results.map((u: any) => (
            <Link key={u._id} href={`/profile/${u.handle}`} style={{ textDecoration:"none", color:"inherit", display:"block" }}>
              <div style={{ display:"flex", alignItems:"flex-start", gap:12, padding:"12px 16px", borderBottom:"1px solid var(--nrp-border)", transition:"background 0.1s" }}
                onMouseEnter={e => (e.currentTarget.style.background = "var(--nrp-hover)")}
                onMouseLeave={e => (e.currentTarget.style.background = "")}>
                <Avatar name={u.name} url={u.avatarUrl} size={46}/>
                <div>
                  <div style={{ fontWeight:700, fontSize:15 }}>{u.name}</div>
                  <div style={{ color:"var(--nrp-muted)", fontSize:14 }}>@{u.handle}</div>
                  {u.bio && <div style={{ fontSize:14, marginTop:4 }}>{u.bio}</div>}
                  <div style={{ fontSize:13, color:"var(--nrp-muted)", marginTop:4 }}>{fmtCount(u.followersCount)} followers</div>
                </div>
              </div>
            </Link>
          ))
        ) : type === "hashtags" && !q.startsWith("#") ? (
          results.map((t: any) => (
            <div key={t._id} onClick={() => router.push(`/explore?tag=${t.tag}`)}
              style={{ padding:"12px 16px", borderBottom:"1px solid var(--nrp-border)", cursor:"pointer", transition:"background 0.1s" }}
              onMouseEnter={e => (e.currentTarget.style.background = "var(--nrp-hover)")}
              onMouseLeave={e => (e.currentTarget.style.background = "")}>
              <div style={{ fontWeight:700, fontSize:16 }}>#{t.tag}</div>
              <div style={{ color:"var(--nrp-muted)", fontSize:13, marginTop:2 }}>{fmtCount(t.postCount)} posts</div>
            </div>
          ))
        ) : (
          results.map((p: Post) => <PostCard key={p._id} post={p} queryKey={["explore"]}/>)
        )
      ) : (
        /* Trending */
        <>
          <div style={{ padding:"14px 16px 6px", fontWeight:800, fontSize:19 }}>Trending on NRP</div>
          {trends.map((t, i) => (
            <div key={i} onClick={() => router.push(`/explore?tag=${t.tag}`)}
              style={{ padding:"12px 16px", borderBottom:"1px solid var(--nrp-border)", cursor:"pointer", transition:"background 0.1s" }}
              onMouseEnter={e => (e.currentTarget.style.background = "var(--nrp-hover)")}
              onMouseLeave={e => (e.currentTarget.style.background = "")}>
              <div style={{ fontSize:12, color:"var(--nrp-muted)", marginBottom:2 }}>Trending · {i + 1}</div>
              <div style={{ fontWeight:700, fontSize:16 }}>#{t.tag}</div>
              <div style={{ fontSize:13, color:"var(--nrp-muted)", marginTop:2 }}>{fmtCount(t.postCount)} posts</div>
            </div>
          ))}
        </>
      )}
    </AppShell>
  );
}
