"use client";
import { useState, useEffect, useRef, useCallback } from "react";
import { Phone, Video, Send, Image as ImageIcon, Lock, PhoneOff, MicOff, Mic, VideoOff, X } from "lucide-react";
import { AppShell, Avatar } from "@/components/layout/AppShell";
import { useAuthStore } from "@/store/authStore";
import { getSocket } from "@/lib/socket";
import { timeAgo, encryptMessage } from "@/lib/utils";
import api from "@/lib/api";

interface Convo { _id: string; other: { _id: string; name: string; handle: string; avatarUrl?: string; lastSeen?: string; }; lastMessage?: { content: string; createdAt: string; }; unread: number; }
interface Msg   { _id: string; sender: { _id: string; name: string; handle: string; avatarUrl?: string; }; content: string; contentIv?: string; mediaUrl?: string; createdAt: string; }

function CallModal({ contact, type, onEnd }: { contact: Convo["other"]; type: "video" | "voice"; onEnd: () => void }) {
  const [connected, setConnected] = useState(false);
  const [muted,  setMuted]  = useState(false);
  const [camOff, setCamOff] = useState(false);
  const [secs,   setSecs]   = useState(0);
  const timer = useRef<ReturnType<typeof setInterval>>();

  useEffect(() => {
    const t = setTimeout(() => { setConnected(true); }, 1500);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    if (connected) timer.current = setInterval(() => setSecs(s => s + 1), 1000);
    return () => clearInterval(timer.current);
  }, [connected]);

  const fmt = (s: number) => `${String(Math.floor(s/60)).padStart(2,"0")}:${String(s%60).padStart(2,"0")}`;

  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.9)", zIndex:400, display:"flex", alignItems:"center", justifyContent:"center" }}>
      <div style={{ background:"var(--nrp-bg)", borderRadius:20, border:"1px solid var(--nrp-border)", padding:36, textAlign:"center", minWidth:340, maxWidth:400, width:"90%" }}>
        {connected && type === "video" && !camOff ? (
          <div style={{ width:"100%", height:180, background:"var(--nrp-subtle)", borderRadius:12, marginBottom:16, display:"flex", alignItems:"center", justifyContent:"center", position:"relative" }}>
            <div style={{ textAlign:"center" }}>
              <Avatar name={contact.name} url={contact.avatarUrl} size={72}/>
              <div style={{ fontSize:12, color:"var(--nrp-muted)", marginTop:6 }}>Live video</div>
            </div>
            {/* Self-view */}
            <div style={{ position:"absolute", bottom:8, right:8, width:64, height:48, background:"var(--nrp-border)", borderRadius:8, display:"flex", alignItems:"center", justifyContent:"center" }}>
              <div style={{ fontSize:10, color:"var(--nrp-muted)" }}>You</div>
            </div>
          </div>
        ) : (
          <div style={{ marginBottom:24 }}>
            <Avatar name={contact.name} url={contact.avatarUrl} size={80}/>
          </div>
        )}

        <div style={{ fontWeight:800, fontSize:20, marginBottom:4 }}>{contact.name}</div>
        <div style={{ color:"var(--nrp-muted)", fontSize:14, marginBottom:4 }}>@{contact.handle}</div>

        {connected ? (
          <div style={{ color:"#22C55E", fontWeight:600, fontSize:15, marginBottom:20, fontFamily:"'Courier New',monospace" }}>{fmt(secs)}</div>
        ) : (
          <div style={{ color:"var(--nrp-muted)", fontSize:14, marginBottom:20 }}>
            {type === "video" ? "📹" : "📞"} {type} call · Ringing…
          </div>
        )}

        <div style={{ display:"flex", gap:16, justifyContent:"center" }}>
          {connected && (
            <>
              <button onClick={() => setMuted(m => !m)}
                style={{ width:52, height:52, borderRadius:"50%", border:`1px solid var(--nrp-border)`, background:muted?"var(--nrp-fg)":"var(--nrp-subtle)", color:muted?"var(--nrp-bg)":"var(--nrp-fg)", cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center" }}>
                {muted ? <MicOff size={22}/> : <Mic size={22}/>}
              </button>
              {type === "video" && (
                <button onClick={() => setCamOff(c => !c)}
                  style={{ width:52, height:52, borderRadius:"50%", border:`1px solid var(--nrp-border)`, background:camOff?"var(--nrp-fg)":"var(--nrp-subtle)", color:camOff?"var(--nrp-bg)":"var(--nrp-fg)", cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center" }}>
                  {camOff ? <VideoOff size={22}/> : <Video size={22}/>}
                </button>
              )}
            </>
          )}
          <button onClick={onEnd}
            style={{ width:52, height:52, borderRadius:"50%", border:"none", background:"#E0245E", color:"#fff", cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center" }}>
            <PhoneOff size={22}/>
          </button>
        </div>
      </div>
    </div>
  );
}

export default function MessagesPage() {
  const { user } = useAuthStore();
  const [convos,     setConvos]    = useState<Convo[]>([]);
  const [active,     setActive]    = useState<Convo | null>(null);
  const [messages,   setMessages]  = useState<Msg[]>([]);
  const [input,      setInput]     = useState("");
  const [typing,     setTyping]    = useState(false);
  const [theyTyping, setTheyTyping]= useState(false);
  const [call,       setCall]      = useState<"video"|"voice"|null>(null);
  const [loading,    setLoading]   = useState(true);
  const [sending,    setSending]   = useState(false);
  const [encLog,     setEncLog]    = useState<string>("");
  const msgEndRef = useRef<HTMLDivElement>(null);
  const typingTimer = useRef<ReturnType<typeof setTimeout>>();
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    api.get("/messages").then(r => { setConvos(r.data.conversations || []); setLoading(false); });
  }, []);

  useEffect(() => {
    if (!active) return;
    setMessages([]);
    api.get(`/messages/${active._id}`).then(r => setMessages(r.data.messages || []));
    const socket = getSocket();
    socket.emit("join:conversation", active._id);

    const onMsg    = (m: Msg) => setMessages(p => [...p, m]);
    const onDel    = ({ id }: { id: string }) => setMessages(p => p.filter(m => m._id !== id));
    const onTyping = ({ userId }: { userId: string }) => { if (userId !== user?._id) setTheyTyping(true); };
    const onStop   = ({ userId }: { userId: string }) => { if (userId !== user?._id) setTheyTyping(false); };

    socket.on("message:new",    onMsg);
    socket.on("message:delete", onDel);
    socket.on("typing:start",   onTyping);
    socket.on("typing:stop",    onStop);

    return () => {
      socket.emit("leave:conversation", active._id);
      socket.off("message:new",    onMsg);
      socket.off("message:delete", onDel);
      socket.off("typing:start",   onTyping);
      socket.off("typing:stop",    onStop);
    };
  }, [active, user]);

  useEffect(() => { msgEndRef.current?.scrollIntoView({ behavior:"smooth" }); }, [messages]);

  const handleTyping = (val: string) => {
    setInput(val);
    if (!active) return;
    const socket = getSocket();
    if (!typing) { setTyping(true); socket.emit("typing:start", { conversationId: active._id }); }
    clearTimeout(typingTimer.current);
    typingTimer.current = setTimeout(() => {
      setTyping(false);
      socket.emit("typing:stop", { conversationId: active._id });
    }, 1500);
  };

  const send = async () => {
    if (!input.trim() || !active || sending) return;
    setSending(true);
    const plain = input.trim();
    setInput("");

    // E2EE encrypt
    const enc = await encryptMessage(plain);
    if (enc) setEncLog(enc.iv.slice(0, 12) + "…");

    try {
      const { data } = await api.post(`/messages/${active._id}`, {
        content: plain,
        contentIv: enc?.iv || null,
      });
      setMessages(p => [...p, data.message]);
      setConvos(c => c.map(cv => cv._id === active._id ? { ...cv, lastMessage: { content: plain, createdAt: new Date().toISOString() } } : cv));
    } catch {}
    setSending(false);
  };

  const sendFile = async (file: File) => {
    if (!active) return;
    const fd = new FormData();
    fd.append("media", file);
    fd.append("content", " ");
    const { data } = await api.post(`/messages/${active._id}`, fd, { headers: { "Content-Type":"multipart/form-data" } });
    setMessages(p => [...p, data.message]);
  };

  return (
    <AppShell hideRight>
      <div style={{ display:"flex", height:"100vh" }}>
        {/* Conversations sidebar */}
        <div style={{ width:340, borderRight:"1px solid var(--nrp-border)", display:"flex", flexDirection:"column", flexShrink:0 }}>
          <div style={{ padding:"14px 16px", borderBottom:"1px solid var(--nrp-border)", fontWeight:800, fontSize:20, position:"sticky", top:0, background:"var(--nrp-bg)" }}>
            Messages
          </div>
          <div style={{ overflowY:"auto", flex:1 }}>
            {loading ? (
              Array.from({length:4}).map((_,i) => (
                <div key={i} style={{ display:"flex", gap:12, padding:"14px 16px", borderBottom:"1px solid var(--nrp-border)" }}>
                  <div className="skeleton" style={{ width:46, height:46, borderRadius:"50%", flexShrink:0 }}/>
                  <div style={{ flex:1 }}><div className="skeleton" style={{ height:13, width:"50%", borderRadius:4, marginBottom:6 }}/><div className="skeleton" style={{ height:13, width:"70%", borderRadius:4 }}/></div>
                </div>
              ))
            ) : convos.length === 0 ? (
              <div style={{ padding:32, textAlign:"center", color:"var(--nrp-muted)" }}>
                <div style={{ fontSize:16, fontWeight:700, marginBottom:6 }}>No messages yet</div>
                <div style={{ fontSize:14 }}>Go to a profile and send a message.</div>
              </div>
            ) : (
              convos.map(c => (
                <div key={c._id} onClick={() => setActive(c)}
                  style={{ display:"flex", alignItems:"flex-start", gap:12, padding:"14px 16px", borderBottom:"1px solid var(--nrp-border)", cursor:"pointer", background:active?._id===c._id?"var(--nrp-subtle)":"transparent", transition:"background 0.1s" }}
                  onMouseEnter={e => { if (active?._id!==c._id) e.currentTarget.style.background="var(--nrp-hover)"; }}
                  onMouseLeave={e => { if (active?._id!==c._id) e.currentTarget.style.background="transparent"; }}>
                  <Avatar name={c.other.name} url={c.other.avatarUrl} size={46}/>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ display:"flex", justifyContent:"space-between", marginBottom:2 }}>
                      <span style={{ fontWeight:700, fontSize:15 }}>{c.other.name}</span>
                      {c.lastMessage && <span style={{ fontSize:13, color:"var(--nrp-muted)", flexShrink:0 }}>{timeAgo(c.lastMessage.createdAt)}</span>}
                    </div>
                    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                      <span style={{ fontSize:14, color:"var(--nrp-muted)", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap", maxWidth:200 }}>{c.lastMessage?.content || "No messages yet"}</span>
                      {c.unread > 0 && <span style={{ background:"var(--nrp-fg)", color:"var(--nrp-bg)", borderRadius:9999, fontSize:11, fontWeight:700, padding:"1px 7px", flexShrink:0 }}>{c.unread}</span>}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Chat area */}
        {active ? (
          <div style={{ flex:1, display:"flex", flexDirection:"column", minWidth:0 }}>
            {/* Chat header */}
            <div style={{ padding:"12px 16px", borderBottom:"1px solid var(--nrp-border)", display:"flex", justifyContent:"space-between", alignItems:"center", position:"sticky", top:0, background:"var(--nrp-bg)" }}>
              <div style={{ display:"flex", gap:10, alignItems:"center" }}>
                <Avatar name={active.other.name} url={active.other.avatarUrl} size={36}/>
                <div>
                  <div style={{ fontWeight:700, fontSize:15 }}>{active.other.name}</div>
                  <div style={{ fontSize:12, color:"var(--nrp-muted)" }}>@{active.other.handle}</div>
                </div>
              </div>
              <div style={{ display:"flex", gap:4 }}>
                <button title="Voice call" onClick={() => setCall("voice")}
                  style={{ padding:8, borderRadius:"50%", border:"none", background:"none", color:"var(--nrp-fg)", cursor:"pointer", display:"flex" }}
                  onMouseEnter={e => (e.currentTarget.style.background="var(--nrp-hover)")}
                  onMouseLeave={e => (e.currentTarget.style.background="none")}>
                  <Phone size={20}/>
                </button>
                <button title="Video call" onClick={() => setCall("video")}
                  style={{ padding:8, borderRadius:"50%", border:"none", background:"none", color:"var(--nrp-fg)", cursor:"pointer", display:"flex" }}
                  onMouseEnter={e => (e.currentTarget.style.background="var(--nrp-hover)")}
                  onMouseLeave={e => (e.currentTarget.style.background="none")}>
                  <Video size={20}/>
                </button>
              </div>
            </div>

            {/* Messages */}
            <div style={{ flex:1, overflowY:"auto", padding:16, display:"flex", flexDirection:"column", gap:10 }}>
              <div style={{ textAlign:"center", marginBottom:8 }}>
                <span style={{ display:"inline-flex", alignItems:"center", gap:4, fontSize:11, color:"var(--nrp-muted)", padding:"2px 8px", border:"1px solid var(--nrp-border)", borderRadius:4 }}>
                  <Lock size={10}/> End-to-end encrypted
                </span>
              </div>

              {messages.map(m => {
                const isMe = m.sender._id === user?._id;
                return (
                  <div key={m._id} style={{ display:"flex", flexDirection:"column", alignItems:isMe?"flex-end":"flex-start" }}>
                    {m.mediaUrl && (
                      <img src={m.mediaUrl} alt="" style={{ maxWidth:"60%", borderRadius:12, marginBottom:4, objectFit:"cover" }}/>
                    )}
                    {m.content.trim() && m.content !== " " && (
                      <div style={{ background:isMe?"var(--nrp-fg)":"var(--nrp-subtle)", color:isMe?"var(--nrp-bg)":"var(--nrp-fg)", padding:"10px 14px", borderRadius:isMe?"18px 18px 4px 18px":"18px 18px 18px 4px", maxWidth:"74%", fontSize:15, wordBreak:"break-word", border:isMe?"none":"1px solid var(--nrp-border)" }}>
                        {m.content}
                      </div>
                    )}
                    <div style={{ fontSize:11, color:"var(--nrp-muted)", marginTop:2, display:"flex", alignItems:"center", gap:4 }}>
                      {timeAgo(m.createdAt)}
                      {isMe && m.contentIv && <span style={{ color:"#22C55E", display:"flex", alignItems:"center", gap:2 }}><Lock size={9}/> e2ee</span>}
                    </div>
                  </div>
                );
              })}

              {theyTyping && (
                <div style={{ alignSelf:"flex-start", background:"var(--nrp-subtle)", padding:"8px 14px", borderRadius:"18px 18px 18px 4px", fontSize:14, color:"var(--nrp-muted)" }}>
                  typing…
                </div>
              )}
              <div ref={msgEndRef}/>
            </div>

            {/* E2EE log */}
            {encLog && (
              <div style={{ padding:"4px 16px", background:"var(--nrp-subtle)", borderTop:"1px solid var(--nrp-border)", fontSize:11, color:"var(--nrp-muted)", display:"flex", alignItems:"center", gap:6 }}>
                <Lock size={10} color="#22C55E"/> <span style={{ color:"#22C55E" }}>E2EE IV:</span> {encLog}
              </div>
            )}

            {/* Input */}
            <div style={{ padding:"10px 16px", borderTop:"1px solid var(--nrp-border)", display:"flex", gap:8, alignItems:"center" }}>
              <input ref={fileRef} type="file" accept="image/*,video/*" style={{ display:"none" }} onChange={e => e.target.files?.[0] && sendFile(e.target.files[0])}/>
              <button onClick={() => fileRef.current?.click()} style={{ padding:8, borderRadius:"50%", border:"none", background:"none", color:"var(--nrp-fg)", cursor:"pointer", display:"flex" }}><ImageIcon size={20}/></button>
              <input value={input} onChange={e => handleTyping(e.target.value)}
                onKeyDown={e => e.key === "Enter" && !e.shiftKey && (e.preventDefault(), send())}
                placeholder="Start a new message" maxLength={4000}
                style={{ flex:1, background:"var(--nrp-subtle)", border:"1px solid var(--nrp-border)", borderRadius:24, padding:"10px 16px", color:"var(--nrp-fg)", fontSize:15, outline:"none", fontFamily:"inherit" }}
                onFocus={e => (e.target.style.borderColor = "var(--nrp-fg)")}
                onBlur={e => (e.target.style.borderColor = "var(--nrp-border)")}/>
              <button onClick={send} disabled={!input.trim() || sending}
                style={{ width:36, height:36, borderRadius:"50%", border:"none", background:"var(--nrp-fg)", color:"var(--nrp-bg)", cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", opacity:!input.trim()||sending?0.5:1 }}>
                <Send size={16}/>
              </button>
            </div>
          </div>
        ) : (
          <div style={{ flex:1, display:"flex", alignItems:"center", justifyContent:"center", flexDirection:"column", gap:12, color:"var(--nrp-muted)" }}>
            <div style={{ fontSize:48 }}>💬</div>
            <div style={{ fontWeight:800, fontSize:22, color:"var(--nrp-fg)" }}>Your messages</div>
            <div style={{ fontSize:15 }}>Select a conversation to start chatting.</div>
          </div>
        )}
      </div>

      {call && <CallModal contact={active!.other} type={call} onEnd={() => setCall(null)}/>}
    </AppShell>
  );
}
