"use client";
import { useState, useEffect } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { PostCard, type Post } from "@/components/feed/PostCard";
import api from "@/lib/api";

export default function BookmarksPage() {
  const [posts,   setPosts]   = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get("/posts/bookmarks").then(r => setPosts(r.data.posts || [])).finally(() => setLoading(false));
  }, []);

  return (
    <AppShell>
      <div style={{ padding:"12px 16px", borderBottom:"1px solid var(--nrp-border)", position:"sticky", top:0, background:"var(--nrp-bg)", backdropFilter:"blur(12px)", zIndex:20, fontWeight:800, fontSize:20 }}>
        Bookmarks
      </div>
      {loading ? (
        Array.from({length:4}).map((_,i) => (
          <div key={i} style={{ padding:"12px 16px", borderBottom:"1px solid var(--nrp-border)", display:"flex", gap:12 }}>
            <div className="skeleton" style={{ width:44, height:44, borderRadius:"50%", flexShrink:0 }}/>
            <div style={{ flex:1 }}><div className="skeleton" style={{ height:13, width:"40%", borderRadius:4, marginBottom:8 }}/><div className="skeleton" style={{ height:13, width:"80%", borderRadius:4 }}/></div>
          </div>
        ))
      ) : posts.length === 0 ? (
        <div style={{ padding:48, textAlign:"center", color:"var(--nrp-muted)" }}>
          <div style={{ fontSize:24, fontWeight:800, marginBottom:8 }}>Nothing saved yet</div>
          <div style={{ fontSize:15 }}>Bookmark any post to find it here.</div>
        </div>
      ) : posts.map(p => <PostCard key={p._id} post={p} queryKey={["bookmarks"]}/>)}
    </AppShell>
  );
}
