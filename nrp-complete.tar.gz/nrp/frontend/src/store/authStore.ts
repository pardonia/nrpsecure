import { create } from "zustand";
import api from "@/lib/api";

export interface User {
  _id: string; name: string; handle: string; email: string;
  bio: string; location: string; website: string;
  avatarUrl: string; coverUrl: string;
  verified: boolean; nrpPro: boolean;
  following: string[];
  followingCount: number; followersCount: number; postsCount: number;
  joinedAt: string; emailVerified: boolean;
  isFollowing?: boolean;
}

interface AuthState {
  user: User | null;
  accessToken: string | null;
  loading: boolean;
  setAuth: (user: User, access: string, refresh: string) => void;
  clearAuth: () => void;
  fetchMe: () => Promise<void>;
  updateUser: (u: Partial<User>) => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  accessToken: typeof window !== "undefined" ? localStorage.getItem("nrp_access") : null,
  loading: true,

  setAuth: (user, access, refresh) => {
    if (typeof window !== "undefined") {
      localStorage.setItem("nrp_access",  access);
      localStorage.setItem("nrp_refresh", refresh);
    }
    set({ user, accessToken: access, loading: false });
  },

  clearAuth: () => {
    if (typeof window !== "undefined") {
      localStorage.removeItem("nrp_access");
      localStorage.removeItem("nrp_refresh");
    }
    set({ user: null, accessToken: null, loading: false });
  },

  fetchMe: async () => {
    const token = typeof window !== "undefined" ? localStorage.getItem("nrp_access") : null;
    if (!token) { set({ loading: false }); return; }
    try {
      const { data } = await api.get("/auth/me");
      set({ user: data.user, loading: false });
    } catch {
      set({ loading: false });
    }
  },

  updateUser: (updates) =>
    set((s) => ({ user: s.user ? { ...s.user, ...updates } : null })),
}));
