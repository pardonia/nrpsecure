"use client";
import { useState, useRef } from "react";
import { Image, BarChart2, Smile, X, Plus } from "lucide-react";
import { useAuthStore } from "@/store/authStore";
import { Avatar } from "@/components/layout/AppShell";
import api from "@/lib/api";
import type { Post } from "@/components/feed/PostCard";

const EMOJIS = ["😀","😂","🔥","❤️","👏","🚀","💡","🎉","✨","🙌","💪","🎯","👀","🤔","💬","📡","🔐","⚡","🌐","🎙","📺","🔴","⭕","🌟","💎"];

interface Props {
  placeholder?: string;
  replyTo?: Post;
  quoteOf?: Post;
  onSuccess?: (post: any) => void;
  compact?: boolean;
}

export function Composer({ placeholder = "What's relaying?", replyTo, quoteOf, onSuccess, compact }: Props) {
  const { user } = useAuthStore();
  const [text, setText]         = useState("");
  const [showPoll, setShowPoll] = useState(false);
  const [showEmoji, setShowEmoji] = useState(false);
  const [pollOpts, setPollOpts] = useState(["", ""]);
  const [pollDays, setPollDays] = useState(1);
  const [files, setFiles]       = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [loading, setLoading]   = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const chars = 280 - text.length;

  if (!user) return null;

  const addFiles = (newFiles: FileList | null) => {
    if (!newFiles) return;
    const arr = Array.from(newFiles).slice(0, 4 - files.length);
    setFiles(prev => [...prev, ...arr].slice(0, 4));
    arr.forEach(f => {
      const url = URL.createObjectURL(f);
      setPreviews(p => [...p, url].slice(0, 4));
    });
  };

  const removeFile = (i: number) => {
    setFiles(f => f.filter((_, j) => j !== i));
    setPreviews(p => p.filter((_, j) => j !== i));
  };

  const submit = async () => {
    if ((!text.trim() && files.length === 0) || chars < 0 || loading) return;
    setLoading(true);
    try {
      const fd = new FormData();
      fd.append("content", text.trim() || " ");
      if (replyTo) fd.append("replyTo", replyTo._id);
      if (quoteOf) fd.append("quoteOf", quoteOf._id);
      files.forEach(f => fd.append("media", f));
      if (showPoll && pollOpts.filter(Boolean).length >= 2) {
        fd.append("poll", JSON.stringify({ options: pollOpts.filter(Boolean).map(l => ({ label: l })), duration: pollDays }));
      }
      const { data } = await api.post("/posts", fd, { headers: { "Content-Type": "multipart/form-data" } });
      setText(""); setFiles([]); setPreviews([]); setShowPoll(false); setPollOpts(["", ""]);
      onSuccess?.(data);
    } catch (err: any) {
      alert(err.response?.data?.error || "Post failed");
    }
    setLoading(false);
  };

  return (
    <div style={{ padding:"14px 16px", borderBottom:"1px solid var(--nrp-border)" }}>
      {replyTo && (
        <div style={{ marginBottom:8, paddingLeft:56, color:"var(--nrp-muted)", fontSize:14 }}>
          Replying to <span style={{ fontWeight:700, color:"var(--nrp-fg)" }}>@{replyTo.author.handle}</span>
        </div>
      )}
      <div style={{ display:"flex", gap:12 }}>
        <Avatar name={user.name} url={user.avatarUrl} size={44}/>
        <div style={{ flex:1 }}>
          <textarea value={text} onChange={e => setText(e.target.value)}
            placeholder={placeholder}
            style={{ width:"100%", minHeight:compact ? 60 : 80, background:"none", border:"none", outline:"none", color:"var(--nrp-fg)", fontSize:20, resize:"none", fontFamily:"inherit", lineHeight:1.4 }}
            onKeyDown={e => { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); submit(); } }}/>

          {/* Quote preview */}
          {quoteOf && (
            <div style={{ border:"1px solid var(--nrp-border)", borderRadius:12, padding:"10px 12px", marginBottom:8 }}>
              <div style={{ display:"flex", gap:6, marginBottom:3, alignItems:"center" }}>
                <Avatar name={quoteOf.author.name} url={quoteOf.author.avatarUrl} size={18}/>
                <span style={{ fontWeight:700, fontSize:13 }}>{quoteOf.author.name}</span>
                <span style={{ color:"var(--nrp-muted)", fontSize:13 }}>@{quoteOf.author.handle}</span>
              </div>
              <div style={{ fontSize:14, color:"var(--nrp-muted)" }}>{quoteOf.content.slice(0, 100)}…</div>
            </div>
          )}

          {/* Media previews */}
          {previews.length > 0 && (
            <div style={{ display:"grid", gridTemplateColumns:previews.length === 1 ? "1fr" : "1fr 1fr", gap:4, marginBottom:8 }}>
              {previews.map((url, i) => (
                <div key={i} style={{ position:"relative" }}>
                  {files[i]?.type.startsWith("video")
                    ? <video src={url} style={{ width:"100%", maxHeight:200, objectFit:"cover", borderRadius:8 }}/>
                    : <img src={url} alt="" style={{ width:"100%", objectFit:"cover", maxHeight:200, borderRadius:8 }}/>}
                  <button onClick={() => removeFile(i)}
                    style={{ position:"absolute", top:4, right:4, background:"rgba(0,0,0,0.75)", color:"#fff", border:"none", borderRadius:"50%", width:24, height:24, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center" }}>
                    <X size={12}/>
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Poll builder */}
          {showPoll && (
            <div style={{ border:"1px solid var(--nrp-border)", borderRadius:12, padding:12, marginBottom:8 }}>
              {pollOpts.map((opt, i) => (
                <input key={i} value={opt} onChange={e => { const a = [...pollOpts]; a[i] = e.target.value; setPollOpts(a); }}
                  placeholder={`Option ${i + 1}`}
                  style={{ display:"block", width:"100%", background:"var(--nrp-subtle)", border:"1px solid var(--nrp-border)", borderRadius:9999, padding:"8px 14px", color:"var(--nrp-fg)", fontSize:14, marginBottom:6, outline:"none", fontFamily:"inherit" }}/>
              ))}
              {pollOpts.length < 4 && (
                <button onClick={() => setPollOpts(p => [...p, ""])}
                  style={{ display:"flex", alignItems:"center", gap:4, fontSize:13, color:"var(--nrp-muted)", background:"none", border:"none", cursor:"pointer" }}>
                  <Plus size={14}/> Add option
                </button>
              )}
              <div style={{ marginTop:10, display:"flex", alignItems:"center", gap:6, fontSize:13, color:"var(--nrp-muted)" }}>
                Duration:
                {[1, 3, 7].map(d => (
                  <button key={d} onClick={() => setPollDays(d)}
                    style={{ padding:"3px 10px", borderRadius:9999, border:"1px solid var(--nrp-border)", background:pollDays===d?"var(--nrp-fg)":"none", color:pollDays===d?"var(--nrp-bg)":"var(--nrp-fg)", cursor:"pointer", fontSize:12, fontFamily:"inherit" }}>
                    {d}d
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Emoji picker */}
          {showEmoji && (
            <div style={{ position:"relative", zIndex:50 }}>
              <div style={{ position:"absolute", bottom:"100%", left:0, background:"var(--nrp-bg)", border:"1px solid var(--nrp-border)", borderRadius:12, padding:10, display:"grid", gridTemplateColumns:"repeat(10,1fr)", gap:3, width:250, boxShadow:"0 4px 20px rgba(0,0,0,0.3)" }}>
                {EMOJIS.map(e => (
                  <button key={e} onClick={() => { setText(t => t + e); setShowEmoji(false); }}
                    style={{ background:"none", border:"none", fontSize:19, cursor:"pointer", padding:3, borderRadius:6 }}
                    onMouseEnter={ev => (ev.currentTarget.style.background = "var(--nrp-hover)")}
                    onMouseLeave={ev => (ev.currentTarget.style.background = "")}>
                    {e}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Toolbar */}
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", borderTop:"1px solid var(--nrp-border)", paddingTop:10, marginTop:6 }}>
            <div style={{ display:"flex", gap:2 }}>
              <input ref={fileRef} type="file" multiple accept="image/*,video/*" style={{ display:"none" }} onChange={e => addFiles(e.target.files)}/>
              {[
                { icon: <Image size={20}/>,    action: () => fileRef.current?.click(), title: "Add media" },
                { icon: <BarChart2 size={20}/>, action: () => { setShowPoll(v => !v); setShowEmoji(false); }, title: "Create poll" },
                { icon: <Smile size={20}/>,     action: () => { setShowEmoji(v => !v); setShowPoll(false); }, title: "Emoji" },
              ].map((b, i) => (
                <button key={i} onClick={b.action} title={b.title}
                  style={{ padding:8, borderRadius:9999, cursor:"pointer", color:"var(--nrp-fg)", border:"none", background:"none", display:"flex", alignItems:"center" }}
                  onMouseEnter={e => (e.currentTarget.style.background = "var(--nrp-hover)")}
                  onMouseLeave={e => (e.currentTarget.style.background = "")}>
                  {b.icon}
                </button>
              ))}
            </div>
            <div style={{ display:"flex", alignItems:"center", gap:10 }}>
              {chars <= 40 && <span style={{ fontSize:13, color:chars < 0 ? "#E0245E" : "var(--nrp-muted)" }}>{chars}</span>}
              <button onClick={submit} disabled={(!text.trim() && files.length === 0) || chars < 0 || loading}
                style={{ background:"var(--nrp-fg)", color:"var(--nrp-bg)", border:"none", padding:"8px 22px", borderRadius:9999, fontWeight:700, fontSize:15, cursor:"pointer", opacity:(!text.trim()&&files.length===0)||chars<0||loading?0.5:1, fontFamily:"inherit" }}>
                {loading ? "Posting…" : replyTo ? "Reply" : "Post"}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
