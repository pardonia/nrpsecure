"use client";
import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useAuthStore } from "@/store/authStore";
import { getSocket, disconnectSocket } from "@/lib/socket";
import api from "@/lib/api";
import { fmtCount } from "@/lib/utils";
import {
  Home, Search, Bell, Mail, Bookmark, User, Settings,
  Radio, Moon, Sun, LogOut, PenSquare, X,
} from "lucide-react";

interface NavItem { href: string; label: string; icon: React.ReactNode; badge?: number; }

function Avatar({ name, url, size=40 }: { name: string; url?: string; size?: number }) {
  if (url) return <img src={url} alt={name} style={{ width:size, height:size, borderRadius:"50%", objectFit:"cover", flexShrink:0 }} />;
  return (
    <div style={{ width:size, height:size, borderRadius:"50%", background:"var(--nrp-fg)", color:"var(--nrp-bg)", display:"flex", alignItems:"center", justifyContent:"center", fontWeight:800, fontFamily:"monospace", fontSize:size*0.35, flexShrink:0 }}>
      {name?.slice(0,2).toUpperCase() || "??"}
    </div>
  );
}

function ComposeModal({ onClose }: { onClose: () => void }) {
  const { user } = useAuthStore();
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  const chars = 280 - text.length;

  const submit = async () => {
    if (!text.trim() || chars < 0 || loading) return;
    setLoading(true);
    try {
      await api.post("/posts", { content: text });
      onClose();
      window.dispatchEvent(new CustomEvent("nrp:newpost"));
    } catch {}
    setLoading(false);
  };

  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.75)", zIndex:300, display:"flex", alignItems:"flex-start", justifyContent:"center", paddingTop:60 }} onClick={onClose}>
      <div style={{ background:"var(--nrp-bg)", border:"1px solid var(--nrp-border)", borderRadius:16, padding:20, width:"100%", maxWidth:560, animation:"fadeIn 0.15s" }} onClick={e=>e.stopPropagation()}>
        <div style={{ display:"flex", justifyContent:"flex-end", marginBottom:8 }}>
          <button onClick={onClose} style={{ background:"none", border:"none", color:"var(--nrp-muted)", cursor:"pointer", padding:4 }}><X size={20}/></button>
        </div>
        <div style={{ display:"flex", gap:12 }}>
          <Avatar name={user?.name||""} url={user?.avatarUrl} size={44}/>
          <div style={{ flex:1 }}>
            <textarea value={text} onChange={e=>setText(e.target.value)} placeholder="What's relaying?"
              style={{ width:"100%", minHeight:100, background:"none", border:"none", outline:"none", color:"var(--nrp-fg)", fontSize:20, resize:"none", fontFamily:"inherit" }}
              autoFocus onKeyDown={e=>{ if(e.key==="Enter"&&(e.ctrlKey||e.metaKey)){e.preventDefault();submit();} }}/>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", borderTop:"1px solid var(--nrp-border)", paddingTop:10 }}>
              <span style={{ fontSize:13, color:chars<20?"#E0245E":"var(--nrp-muted)" }}>{chars}</span>
              <button onClick={submit} disabled={!text.trim()||chars<0||loading}
                style={{ background:"var(--nrp-fg)", color:"var(--nrp-bg)", border:"none", padding:"9px 22px", borderRadius:9999, fontWeight:700, fontSize:15, cursor:"pointer", opacity:(!text.trim()||chars<0||loading)?0.5:1, fontFamily:"inherit" }}>
                {loading ? "Posting…" : "Post"}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function RightSidebar() {
  const [trends, setTrends] = useState<any[]>([]);
  const [suggestions, setSuggestions] = useState<any[]>([]);
  const [search, setSearch] = useState("");
  const router = useRouter();

  useEffect(() => {
    api.get("/trends").then(r => setTrends(r.data.trends || []));
    api.get("/users/suggestions").then(r => setSuggestions(r.data.users || []));
  }, []);

  const { user } = useAuthStore();

  const follow = async (id: string) => {
    await api.post(`/users/${id}/follow`);
    setSuggestions(s => s.filter(u => u._id !== id));
  };

  return (
    <div style={{ padding:"12px 0" }}>
      {/* Search */}
      <div style={{ background:"var(--nrp-subtle)", border:"1px solid transparent", borderRadius:9999, padding:"9px 16px", display:"flex", alignItems:"center", gap:10, marginBottom:16, transition:"border 0.12s" }}
        onFocus={e=>(e.currentTarget.style.border="1px solid var(--nrp-fg)")} onBlur={e=>(e.currentTarget.style.border="1px solid transparent")}>
        <Search size={17} color="var(--nrp-muted)"/>
        <input value={search} onChange={e=>setSearch(e.target.value)}
          onKeyDown={e=>{ if(e.key==="Enter"&&search.trim()) router.push(`/explore?q=${encodeURIComponent(search)}`); }}
          placeholder="Search NRP"
          style={{ background:"none", border:"none", outline:"none", color:"var(--nrp-fg)", fontSize:15, flex:1, fontFamily:"inherit" }}/>
      </div>

      {/* Trending */}
      {trends.length > 0 && (
        <div style={{ background:"var(--nrp-subtle)", border:"1px solid var(--nrp-border)", borderRadius:16, marginBottom:16, overflow:"hidden" }}>
          <div style={{ padding:"14px 16px 8px", fontWeight:800, fontSize:18 }}>What's happening</div>
          {trends.slice(0,5).map((t,i) => (
            <div key={i} style={{ padding:"10px 16px", cursor:"pointer", borderTop:"1px solid var(--nrp-border)", transition:"background 0.1s" }}
              onMouseEnter={e=>(e.currentTarget.style.background="var(--nrp-hover)")}
              onMouseLeave={e=>(e.currentTarget.style.background="")}
              onClick={() => router.push(`/explore?tag=${t.tag}`)}>
              <div style={{ fontSize:11, color:"var(--nrp-muted)" }}>Trending</div>
              <div style={{ fontWeight:700, fontSize:15 }}>#{t.tag}</div>
              <div style={{ fontSize:12, color:"var(--nrp-muted)" }}>{fmtCount(t.postCount)} posts</div>
            </div>
          ))}
        </div>
      )}

      {/* Who to follow */}
      {suggestions.length > 0 && (
        <div style={{ background:"var(--nrp-subtle)", border:"1px solid var(--nrp-border)", borderRadius:16, overflow:"hidden" }}>
          <div style={{ padding:"14px 16px 8px", fontWeight:800, fontSize:18 }}>Who to follow</div>
          {suggestions.map(u => (
            <div key={u._id} style={{ display:"flex", alignItems:"center", gap:10, padding:"10px 16px", borderTop:"1px solid var(--nrp-border)" }}>
              <Link href={`/profile/${u.handle}`}><Avatar name={u.name} url={u.avatarUrl} size={40}/></Link>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontWeight:700, fontSize:14, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{u.name}</div>
                <div style={{ color:"var(--nrp-muted)", fontSize:13 }}>@{u.handle}</div>
              </div>
              {user && user._id !== u._id && (
                <button onClick={() => follow(u._id)}
                  style={{ border:"1px solid var(--nrp-fg)", background:"none", color:"var(--nrp-fg)", padding:"5px 14px", borderRadius:9999, fontSize:13, fontWeight:700, cursor:"pointer", fontFamily:"inherit", whiteSpace:"nowrap" }}>
                  Follow
                </button>
              )}
            </div>
          ))}
        </div>
      )}

      <div style={{ padding:"12px 4px", color:"var(--nrp-muted)", fontSize:12 }}>
        © 2025 Network Relay Platform
      </div>
    </div>
  );
}

export function AppShell({ children, hideRight }: { children: React.ReactNode; hideRight?: boolean }) {
  const { user, clearAuth, loading } = useAuthStore();
  const [dark, setDark] = useState(true);
  const [unread, setUnread] = useState(0);
  const [compose, setCompose] = useState(false);
  const pathname = usePathname();
  const router = useRouter();

  // Theme
  useEffect(() => {
    const saved = localStorage.getItem("nrp_theme") || "dark";
    setDark(saved === "dark");
    document.documentElement.classList.toggle("dark", saved === "dark");
  }, []);

  const toggleTheme = () => {
    const next = !dark;
    setDark(next);
    localStorage.setItem("nrp_theme", next ? "dark" : "light");
    document.documentElement.classList.toggle("dark", next);
  };

  // Socket & notifications
  useEffect(() => {
    if (!user) return;
    const socket = getSocket();
    socket.on("notification", () => setUnread(n => n + 1));
    api.get("/notifications/unread").then(r => setUnread(r.data.count || 0)).catch(() => {});
    return () => { socket.off("notification"); };
  }, [user]);

  const signOut = async () => {
    const refresh = localStorage.getItem("nrp_refresh");
    try { await api.post("/auth/logout", { refreshToken: refresh }); } catch {}
    clearAuth();
    disconnectSocket();
    router.push("/auth");
  };

  if (loading) return (
    <div style={{ minHeight:"100vh", background:"#000", display:"flex", alignItems:"center", justifyContent:"center" }}>
      <div style={{ fontFamily:"'Courier New',monospace", fontWeight:900, fontSize:36, color:"#fff", letterSpacing:-2, animation:"pulse 1.4s infinite" }}>NRP</div>
    </div>
  );

  if (!user) { if (typeof window !== "undefined") router.replace("/auth"); return null; }

  const navItems: NavItem[] = [
    { href:"/feed",                    label:"Home",          icon:<Home size={24}/> },
    { href:"/explore",                 label:"Explore",       icon:<Search size={24}/> },
    { href:"/notifications",           label:"Notifications", icon:<Bell size={24}/>,    badge: unread > 0 ? unread : undefined },
    { href:"/messages",                label:"Messages",      icon:<Mail size={24}/> },
    { href:"/bookmarks",               label:"Bookmarks",     icon:<Bookmark size={24}/> },
    { href:`/profile/${user.handle}`,  label:"Profile",       icon:<User size={24}/> },
    { href:"/settings",                label:"Settings",      icon:<Settings size={24}/> },
  ];

  return (
    <div style={{ display:"flex", minHeight:"100vh", background:"var(--nrp-bg)", color:"var(--nrp-fg)" }}>
      {/* LEFT NAV */}
      <nav style={{ width:270, position:"sticky", top:0, height:"100vh", display:"flex", flexDirection:"column", padding:"4px 8px 12px", borderRight:"1px solid var(--nrp-border)", overflowY:"auto", flexShrink:0 }}>
        <Link href="/feed" style={{ padding:"12px 16px 8px", display:"block", textDecoration:"none" }}>
          <div style={{ fontFamily:"'Courier New',monospace", fontWeight:900, fontSize:28, letterSpacing:-1, color:"var(--nrp-fg)" }}>NRP</div>
        </Link>

        {navItems.map(item => {
          const active = pathname.startsWith(item.href) && (item.href !== "/feed" || pathname === "/feed");
          return (
            <Link key={item.href} href={item.href} style={{ textDecoration:"none" }}
              onClick={item.href === "/notifications" ? () => setUnread(0) : undefined}>
              <div style={{ display:"flex", alignItems:"center", gap:18, padding:"11px 14px", borderRadius:9999, cursor:"pointer", fontWeight:active?700:400, fontSize:19, color:"var(--nrp-fg)", transition:"background 0.12s", position:"relative" }}
                onMouseEnter={e=>(e.currentTarget.style.background="var(--nrp-hover)")}
                onMouseLeave={e=>(e.currentTarget.style.background="")}>
                {item.icon}
                <span>{item.label}</span>
                {item.badge && <span style={{ marginLeft:"auto", background:"var(--nrp-fg)", color:"var(--nrp-bg)", borderRadius:9999, fontSize:11, fontWeight:700, padding:"1px 7px", minWidth:20, textAlign:"center" }}>{item.badge > 99 ? "99+" : item.badge}</span>}
              </div>
            </Link>
          );
        })}

        <Link href="/live" style={{ textDecoration:"none" }}>
          <div style={{ display:"flex", alignItems:"center", gap:14, padding:"11px 14px", borderRadius:9999, cursor:"pointer", fontSize:19, color:"var(--nrp-fg)", fontWeight:pathname==="/live"?700:400 }}
            onMouseEnter={e=>(e.currentTarget.style.background="var(--nrp-hover)")}
            onMouseLeave={e=>(e.currentTarget.style.background="")}>
            <span className="live-dot"/><Radio size={22}/><span>NRP Live</span>
          </div>
        </Link>

        <button onClick={() => setCompose(true)}
          style={{ background:"var(--nrp-fg)", color:"var(--nrp-bg)", border:"none", padding:"14px", borderRadius:9999, fontSize:17, fontWeight:700, cursor:"pointer", width:"100%", marginTop:6, display:"flex", alignItems:"center", justifyContent:"center", gap:8, fontFamily:"inherit" }}>
          <PenSquare size={20}/> Post
        </button>

        <div style={{ flex:1 }}/>

        {/* User row */}
        <div style={{ borderTop:"1px solid var(--nrp-border)", paddingTop:10, display:"flex", flexDirection:"column", gap:4 }}>
          <Link href={`/profile/${user.handle}`} style={{ textDecoration:"none" }}>
            <div style={{ display:"flex", alignItems:"center", gap:10, padding:"8px 10px", borderRadius:9999 }}
              onMouseEnter={e=>(e.currentTarget.style.background="var(--nrp-hover)")}
              onMouseLeave={e=>(e.currentTarget.style.background="")}>
              <Avatar name={user.name} url={user.avatarUrl} size={38}/>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontWeight:700, fontSize:14, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap", color:"var(--nrp-fg)" }}>{user.name}</div>
                <div style={{ color:"var(--nrp-muted)", fontSize:13 }}>@{user.handle}</div>
              </div>
            </div>
          </Link>
          <div style={{ display:"flex", gap:4, paddingLeft:4 }}>
            <button onClick={toggleTheme} title="Toggle theme"
              style={{ background:"none", border:"none", color:"var(--nrp-muted)", cursor:"pointer", padding:8, borderRadius:"50%", display:"flex" }}>
              {dark ? <Sun size={18}/> : <Moon size={18}/>}
            </button>
            <button onClick={signOut} title="Sign out"
              style={{ background:"none", border:"none", color:"var(--nrp-muted)", cursor:"pointer", padding:8, borderRadius:"50%", display:"flex" }}>
              <LogOut size={18}/>
            </button>
          </div>
        </div>
      </nav>

      {/* MAIN */}
      <main style={{ flex:1, maxWidth:600, borderRight:"1px solid var(--nrp-border)", minHeight:"100vh", overflowY:"auto" }}>
        {children}
      </main>

      {/* RIGHT */}
      {!hideRight && (
        <aside style={{ width:350, position:"sticky", top:0, height:"100vh", overflowY:"auto", padding:"0 16px" }}>
          <RightSidebar/>
        </aside>
      )}

      {compose && <ComposeModal onClose={() => setCompose(false)}/>}
    </div>
  );
}

export { Avatar };
