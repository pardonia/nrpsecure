"use client";
import { useState } from "react";
import Link from "next/link";
import { Heart, Repeat2, MessageCircle, Bookmark, Share, MoreHorizontal, Trash2 } from "lucide-react";
import { useAuthStore } from "@/store/authStore";
import { timeAgo, fmtCount, richText } from "@/lib/utils";
import api from "@/lib/api";
import { Avatar } from "@/components/layout/AppShell";
import { useQueryClient } from "@tanstack/react-query";

interface Post {
  _id: string; content: string; createdAt: string;
  author: { _id: string; name: string; handle: string; avatarUrl?: string; verified?: boolean; nrpPro?: boolean; };
  likeCount: number; repostCount: number; replyCount: number; bookmarkCount: number;
  mediaUrls?: string[]; mediaTypes?: string[];
  liked?: boolean; reposted?: boolean; bookmarked?: boolean;
  replyTo?: { author: { name: string; handle: string }; content: string } | null;
  quoteOf?: Post | null;
  poll?: { options: { label: string; votes: number }[]; totalVotes: number; endsAt?: string; voters?: string[] } | null;
}

function RichContent({ text }: { text: string }) {
  return (
    <span>
      {richText(text).map((p, i) => {
        if (p.type === "tag")     return <Link key={i} href={`/explore?tag=${p.value.slice(1)}`} style={{ fontWeight:700, textDecoration:"none", color:"var(--nrp-fg)" }} onClick={e=>e.stopPropagation()}>{p.value}</Link>;
        if (p.type === "mention") return <Link key={i} href={`/profile/${p.value.slice(1)}`}    style={{ fontWeight:700, textDecoration:"none", color:"var(--nrp-fg)" }} onClick={e=>e.stopPropagation()}>{p.value}</Link>;
        if (p.type === "link")    return <a   key={i} href={p.value} target="_blank" rel="noopener noreferrer" style={{ textDecoration:"underline", color:"var(--nrp-fg)" }} onClick={e=>e.stopPropagation()}>{p.value}</a>;
        return <span key={i}>{p.value}</span>;
      })}
    </span>
  );
}

function Poll({ poll, postId, voted }: { poll: NonNullable<Post["poll"]>; postId: string; voted?: boolean }) {
  const [localPoll, setLocalPoll] = useState(poll);
  const [hasVoted, setHasVoted] = useState(voted || false);
  const { user } = useAuthStore();
  const ended = localPoll.endsAt ? new Date(localPoll.endsAt) < new Date() : false;

  const vote = async (idx: number) => {
    if (hasVoted || !user || ended) return;
    try {
      const { data } = await api.post(`/posts/${postId}/vote`, { optionIndex: idx });
      setLocalPoll(data.poll);
      setHasVoted(true);
    } catch {}
  };

  const total = localPoll.totalVotes || 1;
  return (
    <div style={{ margin:"8px 0" }} onClick={e=>e.stopPropagation()}>
      {localPoll.options.map((opt, i) => {
        const pct = hasVoted ? Math.round((opt.votes / total) * 100) : 0;
        return (
          <div key={i} onClick={() => vote(i)}
            style={{ marginBottom:8, padding:"10px 14px", border:"1px solid var(--nrp-border)", borderRadius:9999, cursor:hasVoted||ended?"default":"pointer", transition:"all 0.15s", position:"relative", overflow:"hidden" }}>
            {hasVoted && <div style={{ position:"absolute", inset:0, background:"var(--nrp-subtle)", width:`${pct}%`, borderRadius:9999, zIndex:0 }}/>}
            <div style={{ position:"relative", zIndex:1, display:"flex", justifyContent:"space-between", fontSize:14 }}>
              <span style={{ fontWeight:500 }}>{opt.label}</span>
              {hasVoted && <span style={{ color:"var(--nrp-muted)" }}>{pct}%</span>}
            </div>
          </div>
        );
      })}
      <div style={{ fontSize:13, color:"var(--nrp-muted)" }}>{fmtCount(localPoll.totalVotes)} votes{ended ? " · Ended" : ""}</div>
    </div>
  );
}

export function PostCard({ post, onReply, queryKey }: { post: Post; onReply?: (p: Post) => void; queryKey?: string[] }) {
  const { user } = useAuthStore();
  const qc = useQueryClient();
  const [optimistic, setOptimistic] = useState({ liked: post.liked, likeCount: post.likeCount, reposted: post.reposted, repostCount: post.repostCount, bookmarked: post.bookmarked });
  const [repostMenu, setRepostMenu] = useState(false);
  const [deleted, setDeleted] = useState(false);

  if (deleted) return null;

  const refetch = () => { if (queryKey) qc.invalidateQueries({ queryKey }); };

  const toggleLike = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!user) return;
    const next = !optimistic.liked;
    setOptimistic(o => ({ ...o, liked: next, likeCount: o.likeCount + (next ? 1 : -1) }));
    try { await api.post(`/posts/${post._id}/like`); refetch(); } catch { setOptimistic(o => ({ ...o, liked: !next, likeCount: o.likeCount + (next ? -1 : 1) })); }
  };

  const toggleRepost = async (e: React.MouseEvent) => {
    e.stopPropagation(); setRepostMenu(false);
    if (!user) return;
    const next = !optimistic.reposted;
    setOptimistic(o => ({ ...o, reposted: next, repostCount: o.repostCount + (next ? 1 : -1) }));
    try { await api.post(`/posts/${post._id}/repost`); refetch(); } catch { setOptimistic(o => ({ ...o, reposted: !next, repostCount: o.repostCount + (next ? -1 : 1) })); }
  };

  const toggleBookmark = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!user) return;
    setOptimistic(o => ({ ...o, bookmarked: !o.bookmarked }));
    try { await api.post(`/posts/${post._id}/bookmark`); refetch(); } catch { setOptimistic(o => ({ ...o, bookmarked: !o.bookmarked })); }
  };

  const deletePost = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm("Delete this post?")) return;
    try { await api.delete(`/posts/${post._id}`); setDeleted(true); refetch(); } catch {}
  };

  const share = async (e: React.MouseEvent) => {
    e.stopPropagation();
    const url = `${window.location.origin}/post/${post._id}`;
    if (navigator.share) navigator.share({ url });
    else navigator.clipboard.writeText(url);
  };

  return (
    <Link href={`/post/${post._id}`} style={{ textDecoration:"none", color:"inherit", display:"block" }}>
      <article style={{ padding:"12px 16px", borderBottom:"1px solid var(--nrp-border)", display:"flex", gap:12, transition:"background 0.1s" }}
        onMouseEnter={e=>(e.currentTarget.style.background="var(--nrp-hover)")}
        onMouseLeave={e=>(e.currentTarget.style.background="")}>

        <Link href={`/profile/${post.author.handle}`} onClick={e=>e.stopPropagation()}>
          <Avatar name={post.author.name} url={post.author.avatarUrl} size={44}/>
        </Link>

        <div style={{ flex:1, minWidth:0 }}>
          {/* Reply-to indicator */}
          {post.replyTo && (
            <div style={{ fontSize:13, color:"var(--nrp-muted)", marginBottom:4 }}>
              Replying to <Link href={`/profile/${post.replyTo.author.handle}`} style={{ color:"var(--nrp-fg)", fontWeight:700, textDecoration:"none" }} onClick={e=>e.stopPropagation()}>@{post.replyTo.author.handle}</Link>
            </div>
          )}

          {/* Header */}
          <div style={{ display:"flex", alignItems:"center", gap:5, marginBottom:2, flexWrap:"wrap" }}>
            <Link href={`/profile/${post.author.handle}`} style={{ fontWeight:700, fontSize:15, textDecoration:"none", color:"var(--nrp-fg)" }} onClick={e=>e.stopPropagation()}>
              {post.author.name}
            </Link>
            {post.author.verified && (
              <svg width={15} height={15} viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.09 6.26L21 9l-5.14 4.74 1.04 6.28L12 18l-4.9 2.02 1.04-6.28L3 9l6.91-.74z"/><path d="M9 12l2 2 4-4" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" fill="none"/></svg>
            )}
            <span style={{ color:"var(--nrp-muted)", fontSize:15 }}>@{post.author.handle}</span>
            <span style={{ color:"var(--nrp-muted)" }}>·</span>
            <span style={{ color:"var(--nrp-muted)", fontSize:14 }}>{timeAgo(post.createdAt)}</span>
            {user?._id === post.author._id && (
              <button onClick={deletePost} style={{ marginLeft:"auto", background:"none", border:"none", color:"var(--nrp-muted)", cursor:"pointer", padding:4, display:"flex", borderRadius:"50%" }}
                onMouseEnter={e=>(e.currentTarget.style.color="#E0245E")} onMouseLeave={e=>(e.currentTarget.style.color="var(--nrp-muted)")}>
                <Trash2 size={15}/>
              </button>
            )}
          </div>

          {/* Content */}
          <div style={{ fontSize:15, lineHeight:1.55, marginBottom:8, wordBreak:"break-word" }}>
            <RichContent text={post.content}/>
          </div>

          {/* Media */}
          {post.mediaUrls && post.mediaUrls.length > 0 && (
            <div style={{ display:"grid", gridTemplateColumns:post.mediaUrls.length===1?"1fr":"1fr 1fr", gap:4, marginBottom:8, borderRadius:12, overflow:"hidden" }}
              onClick={e=>e.stopPropagation()}>
              {post.mediaUrls.map((url, i) =>
                post.mediaTypes?.[i] === "video"
                  ? <video key={i} src={url} controls style={{ width:"100%", maxHeight:280, objectFit:"cover", borderRadius:8 }}/>
                  : <img key={i} src={url} alt="" style={{ width:"100%", objectFit:"cover", maxHeight:280, borderRadius:8 }}/>
              )}
            </div>
          )}

          {/* Quote */}
          {post.quoteOf && (
            <div style={{ border:"1px solid var(--nrp-border)", borderRadius:12, padding:"10px 12px", marginBottom:8 }}
              onClick={e=>{ e.stopPropagation(); window.location.href=`/post/${(post.quoteOf as Post)._id}`; }}>
              <div style={{ display:"flex", gap:6, marginBottom:4, alignItems:"center" }}>
                <Avatar name={(post.quoteOf as Post).author.name} url={(post.quoteOf as Post).author.avatarUrl} size={18}/>
                <span style={{ fontWeight:700, fontSize:13 }}>{(post.quoteOf as Post).author.name}</span>
                <span style={{ color:"var(--nrp-muted)", fontSize:13 }}>@{(post.quoteOf as Post).author.handle}</span>
              </div>
              <div style={{ fontSize:14, color:"var(--nrp-muted)", lineHeight:1.4, wordBreak:"break-word" }}>
                {(post.quoteOf as Post).content.slice(0,140)}{(post.quoteOf as Post).content.length>140?"…":""}
              </div>
            </div>
          )}

          {/* Poll */}
          {post.poll && <Poll poll={post.poll} postId={post._id} voted={post.poll.voters?.includes(user?._id||"")}/>}

          {/* Actions */}
          <div style={{ display:"flex", gap:0, marginTop:4 }} onClick={e=>e.stopPropagation()}>
            <button className="action-btn reply" onClick={e=>{e.stopPropagation();onReply?.(post);}}>
              <MessageCircle size={17}/><span>{post.replyCount > 0 ? fmtCount(post.replyCount) : ""}</span>
            </button>

            <div style={{ position:"relative" }}>
              <button className={`action-btn repost${optimistic.reposted?" reposted":""}`} onClick={e=>{e.stopPropagation();setRepostMenu(m=>!m);}}>
                <Repeat2 size={17}/><span>{optimistic.repostCount > 0 ? fmtCount(optimistic.repostCount) : ""}</span>
              </button>
              {repostMenu && (
                <div style={{ position:"absolute", top:"100%", left:0, background:"var(--nrp-bg)", border:"1px solid var(--nrp-border)", borderRadius:12, zIndex:50, minWidth:160, boxShadow:"0 4px 24px rgba(0,0,0,0.3)" }}>
                  <div style={{ padding:"12px 16px", cursor:"pointer", fontSize:15 }} onMouseEnter={e=>(e.currentTarget.style.background="var(--nrp-hover)")} onMouseLeave={e=>(e.currentTarget.style.background="")} onClick={toggleRepost}>{optimistic.reposted?"Undo repost":"Repost"}</div>
                  <div style={{ padding:"12px 16px", cursor:"pointer", fontSize:15, borderTop:"1px solid var(--nrp-border)" }} onMouseEnter={e=>(e.currentTarget.style.background="var(--nrp-hover)")} onMouseLeave={e=>(e.currentTarget.style.background="")} onClick={e=>{e.stopPropagation();setRepostMenu(false);window.location.href=`/post/${post._id}?quote=1`;}}>Quote post</div>
                </div>
              )}
            </div>

            <button className={`action-btn like${optimistic.liked?" liked":""}`} onClick={toggleLike}>
              {optimistic.liked ? <Heart size={17} fill="currentColor"/> : <Heart size={17}/>}
              <span>{optimistic.likeCount > 0 ? fmtCount(optimistic.likeCount) : ""}</span>
            </button>

            <button className={`action-btn bookmark${optimistic.bookmarked?" bookmarked":""}`} onClick={toggleBookmark}>
              {optimistic.bookmarked ? <Bookmark size={17} fill="currentColor"/> : <Bookmark size={17}/>}
            </button>

            <button className="action-btn share" onClick={share}><Share size={17}/></button>
          </div>
        </div>
      </article>
    </Link>
  );
}

export type { Post };
