import axios from "axios";

const BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";

export const api = axios.create({ baseURL: `${BASE}/api`, withCredentials: true });

// Attach access token
api.interceptors.request.use((cfg) => {
  if (typeof window !== "undefined") {
    const token = localStorage.getItem("nrp_access");
    if (token && cfg.headers) cfg.headers.Authorization = `Bearer ${token}`;
  }
  return cfg;
});

// Auto-refresh on 401
api.interceptors.response.use(
  (r) => r,
  async (err) => {
    const original = err.config;
    if (err.response?.status === 401 && err.response?.data?.code === "TOKEN_EXPIRED" && !original._retry) {
      original._retry = true;
      try {
        const refresh = localStorage.getItem("nrp_refresh");
        if (!refresh) throw new Error("No refresh token");
        const { data } = await axios.post(`${BASE}/api/auth/refresh`, { refreshToken: refresh });
        localStorage.setItem("nrp_access",  data.access);
        localStorage.setItem("nrp_refresh", data.refresh);
        original.headers.Authorization = `Bearer ${data.access}`;
        return api(original);
      } catch {
        localStorage.removeItem("nrp_access");
        localStorage.removeItem("nrp_refresh");
        window.location.href = "/auth";
      }
    }
    return Promise.reject(err);
  }
);

export default api;
