import { io, Socket } from "socket.io-client";

let socket: Socket | null = null;

export function getSocket(token?: string): Socket {
  if (socket?.connected) return socket;

  socket = io(process.env.NEXT_PUBLIC_SOCKET_URL || "http://localhost:4000", {
    auth: { token: token || localStorage.getItem("nrp_access") || "" },
    transports: ["websocket", "polling"],
    autoConnect: true,
  });

  socket.on("connect",       () => console.log("🔌 Socket connected"));
  socket.on("disconnect",    () => console.log("🔌 Socket disconnected"));
  socket.on("connect_error", (e) => console.warn("Socket error:", e.message));

  return socket;
}

export function disconnectSocket() {
  socket?.disconnect();
  socket = null;
}

export { socket };
