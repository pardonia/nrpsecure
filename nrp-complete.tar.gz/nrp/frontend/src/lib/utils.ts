import { formatDistanceToNowStrict } from "date-fns";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function timeAgo(date: string | Date): string {
  return formatDistanceToNowStrict(new Date(date), { addSuffix: false })
    .replace(/ seconds?/, "s").replace(/ minutes?/, "m")
    .replace(/ hours?/, "h").replace(/ days?/, "d")
    .replace(/ weeks?/, "w").replace(/ months?/, "mo")
    .replace(/ years?/, "y");
}

export function fmtCount(n: number): string {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000)     return (n / 1_000).toFixed(1) + "K";
  return String(n || 0);
}

export function getAvatarFallback(name: string): string {
  return name?.slice(0, 2).toUpperCase() || "??";
}

export function getAvatarBg(handle: string): string {
  // Deterministic color from handle — stays black/white
  return "var(--nrp-fg)";
}

export function extractTags(text: string) {
  return (text.match(/#(\w+)/g) || []).map(t => t.slice(1).toLowerCase());
}

// E2EE helper (AES-GCM-256) — encrypt before sending to server
export async function encryptMessage(text: string): Promise<{ cipher: string; iv: string } | null> {
  try {
    const key = await crypto.subtle.generateKey({ name: "AES-GCM", length: 256 }, true, ["encrypt", "decrypt"]);
    const iv  = crypto.getRandomValues(new Uint8Array(12));
    const enc = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, new TextEncoder().encode(text));
    return {
      cipher: btoa(String.fromCharCode(...new Uint8Array(enc))),
      iv:     btoa(String.fromCharCode(...iv)),
    };
  } catch { return null; }
}

export function richText(content: string): { type: "text" | "tag" | "mention" | "link"; value: string }[] {
  const parts = content.split(/(#\w+|@\w+|https?:\/\/\S+)/g);
  return parts.map(p => {
    if (/^#\w+/.test(p)) return { type: "tag"     as const, value: p };
    if (/^@\w+/.test(p)) return { type: "mention" as const, value: p };
    if (/^https?:\/\//.test(p)) return { type: "link" as const, value: p };
    return { type: "text" as const, value: p };
  });
}
