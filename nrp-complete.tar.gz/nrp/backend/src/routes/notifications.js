const { Router } = require("express");
const { requireAuth } = require("../middleware/auth");
const { getNotifications, markRead, getUnreadCount } = require("../controllers/miscControllers");
const router = Router();
router.get("/",          requireAuth, getNotifications);
router.get("/unread",    requireAuth, getUnreadCount);
router.post("/read-all", requireAuth, markRead);
module.exports = router;
