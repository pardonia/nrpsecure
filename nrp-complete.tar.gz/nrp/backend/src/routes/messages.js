// messages.js
const { Router: R1 } = require("express");
const { requireAuth: ra } = require("../middleware/auth");
const { upload: up } = require("../config/cloudinary");
const mc = require("../controllers/messagesController");
const r1 = R1();
r1.get("/",                              ra, mc.getConversations);
r1.post("/conversation",                 ra, mc.getOrCreateConversation);
r1.get("/:conversationId",               ra, mc.getMessages);
r1.post("/:conversationId",              ra, up.single("media"), mc.sendMessage);
r1.delete("/:conversationId/:messageId", ra, mc.deleteMessage);
module.exports = r1;
