// ── auth.js ───────────────────────────────────────────────────
const { Router } = require("express");
const { body, query } = require("express-validator");
const validate = require("./validate");
const { requireAuth } = require("../middleware/auth");
const { authLimiter } = require("../middleware/rateLimit");
const c = require("../controllers/authController");

const router = Router();
router.post("/register", authLimiter,
  body("name").trim().notEmpty().isLength({ max: 50 }),
  body("handle").trim().notEmpty().matches(/^[a-z0-9_]+$/i).isLength({ min: 2, max: 20 }),
  body("email").isEmail().normalizeEmail(),
  body("password").isLength({ min: 8 }),
  validate,
  c.register);

router.post("/login", authLimiter,
  body("email").isEmail().normalizeEmail(),
  body("password").notEmpty(),
  validate,
  c.login);

router.post("/refresh",  body("refreshToken").notEmpty(), validate, c.refresh);
router.post("/logout",   requireAuth, c.logout);
router.post("/forgot-password", authLimiter, body("email").isEmail(), validate, c.forgotPassword);
router.post("/reset-password",
  body("token").notEmpty(),
  body("password").isLength({ min: 8 }),
  validate,
  c.resetPassword);
router.get("/verify-email", c.verifyEmail);
router.get("/me", requireAuth, c.me);

module.exports = router;
