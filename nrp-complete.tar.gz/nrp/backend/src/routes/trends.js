const { Router } = require("express");
const { getTrends, getTagPosts } = require("../controllers/miscControllers");
const router = Router();
router.get("/",         getTrends);
router.get("/:tag",     getTagPosts);
module.exports = router;
