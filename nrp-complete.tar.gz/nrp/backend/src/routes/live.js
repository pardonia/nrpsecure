const { Router } = require("express");
const { requireAuth } = require("../middleware/auth");
const { createLiveRoom, getLiveRooms, joinLiveRoom, endLiveRoom } = require("../controllers/miscControllers");
const router = Router();
router.get("/",             getLiveRooms);
router.post("/",            requireAuth, createLiveRoom);
router.post("/:id/join",   requireAuth, joinLiveRoom);
router.post("/:id/end",    requireAuth, endLiveRoom);
module.exports = router;
