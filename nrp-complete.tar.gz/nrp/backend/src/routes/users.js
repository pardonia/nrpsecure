const { Router } = require("express");
const { requireAuth, optionalAuth } = require("../middleware/auth");
const { upload } = require("../config/cloudinary");
const c = require("../controllers/usersController");

const router = Router();
router.get("/suggestions",              optionalAuth, c.getSuggestions);
router.get("/me",                       requireAuth,  async (req, res) => res.json({ user: req.user.toPublicJSON() }));
router.patch("/me",                     requireAuth, upload.fields([{ name: "avatar", maxCount: 1 }, { name: "cover", maxCount: 1 }]), c.updateProfile);
router.get("/:handle",                  optionalAuth, c.getProfile);
router.post("/:id/follow",              requireAuth,  c.toggleFollow);
router.get("/:handle/posts",            optionalAuth, c.getUserPosts);
router.get("/:handle/followers",        optionalAuth, c.getFollowers);
router.get("/:handle/following",        optionalAuth, c.getFollowing);

module.exports = router;
