const { Router } = require("express");
const { body } = require("express-validator");
const validate = require("./validate");
const { requireAuth, optionalAuth } = require("../middleware/auth");
const { postLimiter } = require("../middleware/rateLimit");
const { upload } = require("../config/cloudinary");
const c = require("../controllers/postsController");

const router = Router();
router.get("/feed",       optionalAuth, c.getFeed);
router.get("/bookmarks",  requireAuth,  c.getBookmarks);

router.post("/", requireAuth, postLimiter,
  upload.array("media", 4),
  body("content").trim().notEmpty().isLength({ max: 280 }),
  validate,
  c.createPost);

router.get("/:id",           optionalAuth, c.getPost);
router.delete("/:id",        requireAuth,  c.deletePost);
router.post("/:id/like",     requireAuth,  c.toggleLike);
router.post("/:id/repost",   requireAuth,  c.toggleRepost);
router.post("/:id/bookmark", requireAuth,  c.toggleBookmark);
router.post("/:id/vote",     requireAuth,  body("optionIndex").isInt({ min: 0, max: 3 }), validate, c.votePoll);

module.exports = router;
