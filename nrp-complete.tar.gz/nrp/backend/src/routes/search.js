const { Router } = require("express");
const { optionalAuth } = require("../middleware/auth");
const { search } = require("../controllers/miscControllers");
const router = Router();
router.get("/", optionalAuth, search);
module.exports = router;
