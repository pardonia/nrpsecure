const { Router } = require("express");
const { requireAuth } = require("../middleware/auth");
const { upload } = require("../config/cloudinary");
const { uploadLimiter } = require("../middleware/rateLimit");
const router = Router();

router.post("/", requireAuth, uploadLimiter, upload.single("file"), (req, res) => {
  if (!req.file) return res.status(400).json({ error: "No file uploaded" });
  const url = req.file.path || `${process.env.BACKEND_URL || "http://localhost:4000"}/uploads/${req.file.filename}`;
  res.json({ url, type: req.file.mimetype?.startsWith("video") ? "video" : "image" });
});

module.exports = router;
