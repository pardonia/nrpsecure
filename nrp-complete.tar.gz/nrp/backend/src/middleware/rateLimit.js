const rateLimit = require("express-rate-limit");

const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 min
  max: 500,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many requests, please slow down" },
  skip: (req) => req.path === "/health",
});

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  message: { error: "Too many auth attempts, try again in 15 minutes" },
});

const postLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 30,
  message: { error: "Too many posts, slow down" },
});

const uploadLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 100,
  message: { error: "Upload limit reached" },
});

module.exports = { apiLimiter, authLimiter, postLimiter, uploadLimiter };
