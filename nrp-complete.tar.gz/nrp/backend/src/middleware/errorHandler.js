function errorHandler(err, req, res, _next) {
  console.error(`[ERROR] ${req.method} ${req.path}:`, err.message);

  // Mongoose validation error
  if (err.name === "ValidationError") {
    const errors = Object.values(err.errors).map(e => e.message);
    return res.status(400).json({ error: "Validation failed", details: errors });
  }

  // Mongoose duplicate key
  if (err.code === 11000) {
    const field = Object.keys(err.keyValue || {})[0] || "field";
    return res.status(409).json({ error: `${field} already taken` });
  }

  // Multer file size
  if (err.code === "LIMIT_FILE_SIZE") {
    return res.status(413).json({ error: "File too large (max 50MB)" });
  }

  // Invalid ObjectId
  if (err.name === "CastError" && err.kind === "ObjectId") {
    return res.status(400).json({ error: "Invalid ID" });
  }

  // JWT errors
  if (err.name === "JsonWebTokenError") return res.status(401).json({ error: "Invalid token" });
  if (err.name === "TokenExpiredError")  return res.status(401).json({ error: "Token expired", code: "TOKEN_EXPIRED" });

  const status  = err.status || err.statusCode || 500;
  const message = err.expose || status < 500 ? err.message : "Internal server error";
  res.status(status).json({ error: message });
}

module.exports = errorHandler;
