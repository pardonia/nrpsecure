const { verifyAccess } = require("../utils/jwt");
const User = require("../models/User");

// Require valid JWT
async function requireAuth(req, res, next) {
  try {
    const header = req.headers.authorization;
    if (!header?.startsWith("Bearer ")) return res.status(401).json({ error: "No token provided" });
    const token = header.slice(7);
    const decoded = verifyAccess(token);
    const user = await User.findById(decoded.id).select("-password -refreshTokens");
    if (!user) return res.status(401).json({ error: "User not found" });
    req.user = user;
    // Update lastSeen (non-blocking)
    User.findByIdAndUpdate(user._id, { lastSeen: Date.now() }).catch(() => {});
    next();
  } catch (err) {
    if (err.name === "TokenExpiredError") return res.status(401).json({ error: "Token expired", code: "TOKEN_EXPIRED" });
    return res.status(401).json({ error: "Invalid token" });
  }
}

// Optional auth — attach user if token present, don't fail if not
async function optionalAuth(req, _res, next) {
  try {
    const header = req.headers.authorization;
    if (header?.startsWith("Bearer ")) {
      const token = header.slice(7);
      const decoded = verifyAccess(token);
      const user = await User.findById(decoded.id).select("-password -refreshTokens");
      if (user) req.user = user;
    }
  } catch {}
  next();
}

// Require admin
function requireAdmin(req, res, next) {
  if (!req.user?.isAdmin) return res.status(403).json({ error: "Admin only" });
  next();
}

module.exports = { requireAuth, optionalAuth, requireAdmin };
