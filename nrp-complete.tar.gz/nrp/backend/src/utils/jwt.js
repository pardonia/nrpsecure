const jwt = require("jsonwebtoken");

function signAccess(payload) {
  return jwt.sign(payload, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_ACCESS_EXPIRY || "15m",
  });
}

function signRefresh(payload) {
  return jwt.sign(payload, process.env.JWT_REFRESH_SECRET, {
    expiresIn: process.env.JWT_REFRESH_EXPIRY || "30d",
  });
}

function verifyAccess(token) {
  return jwt.verify(token, process.env.JWT_SECRET);
}

function verifyRefresh(token) {
  return jwt.verify(token, process.env.JWT_REFRESH_SECRET);
}

function issueTokens(userId) {
  const access  = signAccess({ id: userId });
  const refresh = signRefresh({ id: userId });
  return { access, refresh };
}

module.exports = { signAccess, signRefresh, verifyAccess, verifyRefresh, issueTokens };
