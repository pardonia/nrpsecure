require("dotenv").config();
const mongoose = require("mongoose");
const User     = require("../models/User");
const Post     = require("../models/Post");
const { Hashtag } = require("../models/index");

async function seed() {
  await mongoose.connect(process.env.MONGODB_URI || "mongodb://localhost:27017/nrp");
  console.log("Connected. Seeding…");

  await User.deleteMany({}); await Post.deleteMany({}); await Hashtag.deleteMany({});

  const users = await User.insertMany([
    { name: "Alexandra Chen", handle: "alexchen", email: "alex@nrp.dev", password: "password123", bio: "Building tomorrow's infrastructure.", verified: true, followersCount: 48200 },
    { name: "Marcus Webb",    handle: "marcuswebb", email: "marcus@nrp.dev", password: "password123", bio: "Broadcaster. Creator. Live or nothing.", followersCount: 4100 },
    { name: "Priya Nair",     handle: "priyanair", email: "priya@nrp.dev", password: "password123", bio: "Privacy researcher & cryptographer.", verified: true, followersCount: 31000 },
    { name: "Dev Collective",  handle: "devcol",   email: "dev@nrp.dev", password: "password123", bio: "Open source community.", verified: true, followersCount: 22000 },
  ]);

  // Hash passwords properly
  for (const u of users) {
    const fresh = await User.findById(u._id).select("+password");
    fresh.password = "password123";
    await fresh.save();
  }

  await Post.insertMany([
    { author: users[0]._id, content: "The future of decentralized communication is here. NRP is redefining how we connect. #NRP #TheNetwork #Privacy", likeCount: 847, repostCount: 203, replyCount: 91 },
    { author: users[1]._id, content: "Just went live on NRP for the first time. The video quality is unreal. #NRPLive #Streaming", likeCount: 312, repostCount: 88, replyCount: 47 },
    { author: users[2]._id, content: "Privacy matters. NRP's E2EE on DMs means your conversations stay yours. #E2EE #Privacy #NRP", likeCount: 1240, repostCount: 511, replyCount: 138 },
    { author: users[3]._id, content: "We migrated our entire community to NRP. The API is clean, webhooks reliable. #Dev #NRP #BuildInPublic", likeCount: 589, repostCount: 201, replyCount: 74 },
  ]);

  await Hashtag.insertMany([
    { tag: "nrp",          postCount: 4821, dailyCount: 480 },
    { tag: "thenetwork",   postCount: 3172, dailyCount: 310 },
    { tag: "e2ee",         postCount: 2244, dailyCount: 220 },
    { tag: "nrplive",      postCount: 1891, dailyCount: 189 },
    { tag: "buildinpublic",postCount: 1513, dailyCount: 151 },
    { tag: "privacy",      postCount: 1234, dailyCount: 120 },
    { tag: "dev",          postCount: 987,  dailyCount: 98  },
    { tag: "streaming",    postCount: 742,  dailyCount: 74  },
  ]);

  console.log("✅ Seed complete");
  process.exit(0);
}

seed().catch(err => { console.error(err); process.exit(1); });
