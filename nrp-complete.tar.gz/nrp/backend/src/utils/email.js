const nodemailer = require("nodemailer");

let transporter;

function getTransporter() {
  if (transporter) return transporter;
  transporter = nodemailer.createTransport({
    host:   process.env.SMTP_HOST || "smtp.gmail.com",
    port:   parseInt(process.env.SMTP_PORT || "587"),
    secure: process.env.SMTP_PORT === "465",
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  });
  return transporter;
}

const BASE_STYLE = `
  font-family: 'Courier New', monospace;
  background: #000;
  color: #fff;
  padding: 40px;
  max-width: 480px;
  margin: 0 auto;
  border: 1px solid #2F3336;
  border-radius: 12px;
`;

async function sendPasswordReset(email, name, resetUrl) {
  const t = getTransporter();
  await t.sendMail({
    from: process.env.EMAIL_FROM || "NRP <no-reply@nrp.app>",
    to:   email,
    subject: "Reset your NRP password",
    html: `
      <div style="${BASE_STYLE}">
        <h1 style="font-size:28px;letter-spacing:-1px;margin:0 0 24px;">NRP</h1>
        <p style="font-size:16px;margin-bottom:16px;">Hi ${name},</p>
        <p style="color:#71767B;margin-bottom:24px;">You requested a password reset. Click below to set a new password. This link expires in 1 hour.</p>
        <a href="${resetUrl}" style="display:block;background:#fff;color:#000;text-align:center;padding:14px;border-radius:9999px;font-weight:700;font-size:16px;text-decoration:none;margin-bottom:24px;">Reset Password</a>
        <p style="color:#71767B;font-size:13px;">If you didn't request this, ignore this email. Your password won't change.</p>
        <p style="color:#2F3336;font-size:12px;margin-top:24px;">© 2025 Network Relay Platform</p>
      </div>
    `,
  });
}

async function sendEmailVerification(email, name, verifyUrl) {
  const t = getTransporter();
  await t.sendMail({
    from: process.env.EMAIL_FROM || "NRP <no-reply@nrp.app>",
    to:   email,
    subject: "Verify your NRP email",
    html: `
      <div style="${BASE_STYLE}">
        <h1 style="font-size:28px;letter-spacing:-1px;margin:0 0 24px;">NRP</h1>
        <p style="font-size:16px;margin-bottom:16px;">Welcome to NRP, ${name}!</p>
        <p style="color:#71767B;margin-bottom:24px;">Click below to verify your email address.</p>
        <a href="${verifyUrl}" style="display:block;background:#fff;color:#000;text-align:center;padding:14px;border-radius:9999px;font-weight:700;font-size:16px;text-decoration:none;margin-bottom:24px;">Verify Email</a>
        <p style="color:#2F3336;font-size:12px;margin-top:24px;">© 2025 Network Relay Platform</p>
      </div>
    `,
  });
}

module.exports = { sendPasswordReset, sendEmailVerification };
