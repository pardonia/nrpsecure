const { Server } = require("socket.io");
const jwt = require("jsonwebtoken");

let io;

function initSocket(server) {
  io = new Server(server, {
    cors: {
      origin: process.env.FRONTEND_URL || "http://localhost:3000",
      credentials: true,
    },
    transports: ["websocket", "polling"],
  });

  // Auth middleware — verify JWT on socket connect
  io.use((socket, next) => {
    const token = socket.handshake.auth?.token || socket.handshake.headers?.authorization?.split(" ")[1];
    if (!token) return next(new Error("Authentication required"));
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      socket.userId = decoded.id;
      next();
    } catch {
      next(new Error("Invalid token"));
    }
  });

  io.on("connection", (socket) => {
    const userId = socket.userId;
    console.log(`🔌 Socket connected: ${userId}`);

    // Join personal room (for targeted notifications/DMs)
    socket.join(`user:${userId}`);

    // Join conversation rooms
    socket.on("join:conversation", (conversationId) => {
      socket.join(`conv:${conversationId}`);
    });

    socket.on("leave:conversation", (conversationId) => {
      socket.leave(`conv:${conversationId}`);
    });

    // Typing indicators
    socket.on("typing:start", ({ conversationId }) => {
      socket.to(`conv:${conversationId}`).emit("typing:start", { userId });
    });

    socket.on("typing:stop", ({ conversationId }) => {
      socket.to(`conv:${conversationId}`).emit("typing:stop", { userId });
    });

    // Live room viewer tracking
    socket.on("live:join", (roomName) => {
      socket.join(`live:${roomName}`);
      const count = io.sockets.adapter.rooms.get(`live:${roomName}`)?.size || 0;
      io.to(`live:${roomName}`).emit("live:viewers", count);
    });

    socket.on("live:leave", (roomName) => {
      socket.leave(`live:${roomName}`);
      const count = io.sockets.adapter.rooms.get(`live:${roomName}`)?.size || 0;
      io.to(`live:${roomName}`).emit("live:viewers", count);
    });

    socket.on("disconnect", () => {
      console.log(`🔌 Socket disconnected: ${userId}`);
    });
  });

  return io;
}

function getIO() {
  if (!io) throw new Error("Socket.io not initialized");
  return io;
}

// Helpers to emit from controllers
function emitToUser(userId, event, data)         { getIO().to(`user:${userId}`).emit(event, data); }
function emitToConversation(convId, event, data) { getIO().to(`conv:${convId}`).emit(event, data); }
function emitToAll(event, data)                  { getIO().emit(event, data); }

module.exports = { initSocket, getIO, emitToUser, emitToConversation, emitToAll };
