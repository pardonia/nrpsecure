const cloudinary = require("cloudinary").v2;
const multer = require("multer");
const path   = require("path");
const fs     = require("fs");
const { v4: uuidv4 } = require("uuid");

const USE_CLOUDINARY = !!(
  process.env.CLOUDINARY_CLOUD_NAME &&
  process.env.CLOUDINARY_API_KEY &&
  process.env.CLOUDINARY_API_SECRET
);

if (USE_CLOUDINARY) {
  cloudinary.config({
    cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
    api_key:    process.env.CLOUDINARY_API_KEY,
    api_secret: process.env.CLOUDINARY_API_SECRET,
  });
  console.log("☁️  Cloudinary configured");
} else {
  console.log("📁 Using local storage for uploads");
}

// ── Multer storage ────────────────────────────────────────────
let storage;

if (USE_CLOUDINARY) {
  const { CloudinaryStorage } = require("multer-storage-cloudinary");
  storage = new CloudinaryStorage({
    cloudinary,
    params: (req, file) => ({
      folder: "nrp",
      allowed_formats: ["jpg","jpeg","png","gif","webp","mp4","mov"],
      resource_type: file.mimetype.startsWith("video") ? "video" : "image",
      public_id: `${req.user?.id || "anon"}-${uuidv4()}`,
      transformation: file.fieldname === "avatar"
        ? [{ width: 400, height: 400, crop: "fill", gravity: "face" }]
        : file.fieldname === "cover"
        ? [{ width: 1500, height: 500, crop: "fill" }]
        : [{ quality: "auto:good", fetch_format: "auto" }],
    }),
  });
} else {
  const uploadDir = path.join(__dirname, "../../uploads");
  fs.mkdirSync(uploadDir, { recursive: true });
  storage = multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, uploadDir),
    filename: (_req, file, cb) => cb(null, `${uuidv4()}${path.extname(file.originalname)}`),
  });
}

const fileFilter = (_req, file, cb) => {
  const allowed = ["image/jpeg","image/png","image/gif","image/webp","video/mp4","video/quicktime"];
  allowed.includes(file.mimetype) ? cb(null, true) : cb(new Error("Invalid file type"), false);
};

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB
});

// Get public URL for local uploads
function getFileUrl(req, filename) {
  if (USE_CLOUDINARY) return filename; // Cloudinary returns full URL in path
  return `${process.env.BACKEND_URL || "http://localhost:4000"}/uploads/${filename}`;
}

async function deleteFile(publicId) {
  if (USE_CLOUDINARY && publicId) {
    try { await cloudinary.uploader.destroy(publicId); } catch {}
  }
  // Local: optionally delete file
}

module.exports = { upload, getFileUrl, deleteFile, USE_CLOUDINARY };
