const xss    = require("xss");
const User   = require("../models/User");
const Post   = require("../models/Post");
const { Notification } = require("../models/index");
const { emitToUser }   = require("../config/socket");
const { upload }       = require("../config/cloudinary");

// GET /api/users/:handle
async function getProfile(req, res, next) {
  try {
    const user = await User.findOne({ handle: req.params.handle.toLowerCase() });
    if (!user) return res.status(404).json({ error: "User not found" });
    const isFollowing = req.user ? user.followers.includes(req.user._id) : false;
    res.json({ user: { ...user.toPublicJSON(), isFollowing } });
  } catch (err) { next(err); }
}

// PATCH /api/users/me
async function updateProfile(req, res, next) {
  try {
    const { name, bio, location, website, handle } = req.body;
    const updates = {};
    if (name)     updates.name     = xss(name).slice(0, 50);
    if (bio)      updates.bio      = xss(bio).slice(0, 160);
    if (location) updates.location = xss(location).slice(0, 60);
    if (website)  updates.website  = xss(website).slice(0, 100);

    if (handle) {
      const slug = handle.toLowerCase().replace(/[^a-z0-9_]/g, "").slice(0, 20);
      const taken = await User.findOne({ handle: slug, _id: { $ne: req.user._id } });
      if (taken) return res.status(409).json({ error: "Handle already taken" });
      updates.handle = slug;
    }

    if (req.files?.avatar?.[0]) {
      updates.avatarUrl = req.files.avatar[0].path || `/uploads/${req.files.avatar[0].filename}`;
    }
    if (req.files?.cover?.[0]) {
      updates.coverUrl = req.files.cover[0].path || `/uploads/${req.files.cover[0].filename}`;
    }

    const user = await User.findByIdAndUpdate(req.user._id, updates, { new: true, runValidators: true });
    res.json({ user: user.toPublicJSON() });
  } catch (err) { next(err); }
}

// POST /api/users/:id/follow
async function toggleFollow(req, res, next) {
  try {
    const targetId = req.params.id;
    if (targetId === req.user._id.toString()) return res.status(400).json({ error: "Can't follow yourself" });

    const target = await User.findById(targetId);
    if (!target) return res.status(404).json({ error: "User not found" });

    const isFollowing = target.followers.includes(req.user._id);

    if (isFollowing) {
      await User.findByIdAndUpdate(targetId,      { $pull:  { followers: req.user._id }, $inc: { followersCount: -1 } });
      await User.findByIdAndUpdate(req.user._id,  { $pull:  { following: targetId },    $inc: { followingCount: -1 } });
    } else {
      await User.findByIdAndUpdate(targetId,     { $addToSet: { followers: req.user._id }, $inc: { followersCount: 1 } });
      await User.findByIdAndUpdate(req.user._id, { $addToSet: { following: targetId },    $inc: { followingCount: 1 } });
      const notif = await Notification.create({ recipient: targetId, actor: req.user._id, type: "follow" });
      emitToUser(targetId, "notification", notif);
    }

    res.json({ following: !isFollowing });
  } catch (err) { next(err); }
}

// GET /api/users/:handle/posts
async function getUserPosts(req, res, next) {
  try {
    const user = await User.findOne({ handle: req.params.handle.toLowerCase() });
    if (!user) return res.status(404).json({ error: "User not found" });

    const { cursor, limit = 20, tab = "posts" } = req.query;
    const q = { author: user._id, isDeleted: false };
    if (cursor) q._id = { $lt: cursor };
    if (tab === "posts")   q.replyTo = null;
    if (tab === "replies") q.replyTo = { $ne: null };
    if (tab === "media")   q.mediaUrls = { $not: { $size: 0 } };

    const posts = await Post.find(q)
      .populate([
        { path: "author", select: "name handle avatarUrl verified nrpPro" },
        { path: "replyTo", select: "author content", populate: { path: "author", select: "name handle" } },
        { path: "quoteOf", populate: { path: "author", select: "name handle avatarUrl verified" } },
      ])
      .sort({ createdAt: -1 })
      .limit(parseInt(limit));

    res.json({ posts: posts.map(p => p.toObject()), nextCursor: posts.length === parseInt(limit) ? posts[posts.length-1]._id : null });
  } catch (err) { next(err); }
}

// GET /api/users/:handle/followers
async function getFollowers(req, res, next) {
  try {
    const user = await User.findOne({ handle: req.params.handle.toLowerCase() })
      .populate("followers", "name handle avatarUrl verified nrpPro bio followersCount");
    if (!user) return res.status(404).json({ error: "User not found" });
    res.json({ users: user.followers });
  } catch (err) { next(err); }
}

// GET /api/users/:handle/following
async function getFollowing(req, res, next) {
  try {
    const user = await User.findOne({ handle: req.params.handle.toLowerCase() })
      .populate("following", "name handle avatarUrl verified nrpPro bio followersCount");
    if (!user) return res.status(404).json({ error: "User not found" });
    res.json({ users: user.following });
  } catch (err) { next(err); }
}

// GET /api/users/suggestions
async function getSuggestions(req, res, next) {
  try {
    const exclude = req.user ? [...(req.user.following || []), req.user._id] : [];
    const users = await User.find({ _id: { $nin: exclude } })
      .select("name handle avatarUrl verified nrpPro bio followersCount")
      .sort({ followersCount: -1 })
      .limit(6);
    res.json({ users });
  } catch (err) { next(err); }
}

module.exports = { getProfile, updateProfile, toggleFollow, getUserPosts, getFollowers, getFollowing, getSuggestions };
