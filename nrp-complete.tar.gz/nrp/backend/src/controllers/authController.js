const crypto = require("crypto");
const User   = require("../models/User");
const { issueTokens, verifyRefresh } = require("../utils/jwt");
const { sendPasswordReset, sendEmailVerification } = require("../utils/email");

// POST /api/auth/register
async function register(req, res, next) {
  try {
    const { name, handle, email, password } = req.body;

    // Check duplicates
    const existing = await User.findOne({ $or: [{ email }, { handle: handle.toLowerCase() }] });
    if (existing) {
      return res.status(409).json({
        error: existing.email === email ? "Email already registered" : "Handle already taken",
      });
    }

    const user = await User.create({ name, handle: handle.toLowerCase(), email, password });

    // Email verification token
    const verifyToken = crypto.randomBytes(32).toString("hex");
    user.emailVerifyToken = verifyToken;
    await user.save({ validateBeforeSave: false });

    const verifyUrl = `${process.env.FRONTEND_URL}/verify-email?token=${verifyToken}`;
    try { await sendEmailVerification(email, name, verifyUrl); } catch {}

    const { access, refresh } = issueTokens(user._id.toString());
    user.refreshTokens = [refresh];
    await user.save({ validateBeforeSave: false });

    res.status(201).json({
      user: user.toPublicJSON(),
      access,
      refresh,
      message: "Account created. Check your email to verify.",
    });
  } catch (err) { next(err); }
}

// POST /api/auth/login
async function login(req, res, next) {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email }).select("+password +refreshTokens");
    if (!user || !user.password) return res.status(401).json({ error: "Invalid credentials" });

    const ok = await user.comparePassword(password);
    if (!ok) return res.status(401).json({ error: "Invalid credentials" });

    const { access, refresh } = issueTokens(user._id.toString());
    user.refreshTokens = [...(user.refreshTokens || []).slice(-4), refresh]; // keep last 5
    await user.save({ validateBeforeSave: false });

    res.json({ user: user.toPublicJSON(), access, refresh });
  } catch (err) { next(err); }
}

// POST /api/auth/refresh
async function refresh(req, res, next) {
  try {
    const { refreshToken } = req.body;
    if (!refreshToken) return res.status(400).json({ error: "Refresh token required" });

    const decoded = verifyRefresh(refreshToken);
    const user    = await User.findById(decoded.id).select("+refreshTokens");
    if (!user || !user.refreshTokens?.includes(refreshToken)) {
      return res.status(401).json({ error: "Invalid refresh token" });
    }

    const { access, refresh: newRefresh } = issueTokens(user._id.toString());
    // Rotate refresh token
    user.refreshTokens = user.refreshTokens.filter(t => t !== refreshToken).concat(newRefresh);
    await user.save({ validateBeforeSave: false });

    res.json({ access, refresh: newRefresh });
  } catch (err) { next(err); }
}

// POST /api/auth/logout
async function logout(req, res, next) {
  try {
    const { refreshToken } = req.body;
    if (req.user && refreshToken) {
      const user = await User.findById(req.user._id).select("+refreshTokens");
      if (user) {
        user.refreshTokens = (user.refreshTokens || []).filter(t => t !== refreshToken);
        await user.save({ validateBeforeSave: false });
      }
    }
    res.json({ message: "Logged out" });
  } catch (err) { next(err); }
}

// POST /api/auth/forgot-password
async function forgotPassword(req, res, next) {
  try {
    const { email } = req.body;
    const user = await User.findOne({ email });
    // Always return 200 to prevent enumeration
    if (!user) return res.json({ message: "If that email exists, a reset link has been sent." });

    const token = crypto.randomBytes(32).toString("hex");
    user.passwordResetToken   = crypto.createHash("sha256").update(token).digest("hex");
    user.passwordResetExpires = Date.now() + 60 * 60 * 1000; // 1 hour
    await user.save({ validateBeforeSave: false });

    const resetUrl = `${process.env.FRONTEND_URL}/reset-password?token=${token}`;
    try {
      await sendPasswordReset(email, user.name, resetUrl);
    } catch (err) {
      user.passwordResetToken = undefined;
      user.passwordResetExpires = undefined;
      await user.save({ validateBeforeSave: false });
      return next(new Error("Failed to send reset email"));
    }

    res.json({ message: "If that email exists, a reset link has been sent." });
  } catch (err) { next(err); }
}

// POST /api/auth/reset-password
async function resetPassword(req, res, next) {
  try {
    const { token, password } = req.body;
    const hashed = crypto.createHash("sha256").update(token).digest("hex");

    const user = await User.findOne({
      passwordResetToken: hashed,
      passwordResetExpires: { $gt: Date.now() },
    }).select("+passwordResetToken +passwordResetExpires +refreshTokens");

    if (!user) return res.status(400).json({ error: "Token invalid or expired" });

    user.password             = password;
    user.passwordResetToken   = undefined;
    user.passwordResetExpires = undefined;
    user.refreshTokens        = []; // invalidate all sessions
    await user.save();

    res.json({ message: "Password reset successfully. Please log in." });
  } catch (err) { next(err); }
}

// GET /api/auth/verify-email?token=...
async function verifyEmail(req, res, next) {
  try {
    const { token } = req.query;
    const user = await User.findOne({ emailVerifyToken: token }).select("+emailVerifyToken");
    if (!user) return res.status(400).json({ error: "Invalid or expired verification link" });
    user.emailVerified    = true;
    user.emailVerifyToken = undefined;
    await user.save({ validateBeforeSave: false });
    res.json({ message: "Email verified successfully" });
  } catch (err) { next(err); }
}

// GET /api/auth/me
async function me(req, res) {
  res.json({ user: req.user.toPublicJSON() });
}

module.exports = { register, login, refresh, logout, forgotPassword, resetPassword, verifyEmail, me };
