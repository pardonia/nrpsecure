const xss    = require("xss");
const Post   = require("../models/Post");
const User   = require("../models/User");
const { Like, Repost, Bookmark, Notification, Hashtag } = require("../models/index");
const { emitToUser, emitToAll } = require("../config/socket");

const POST_POPULATE = [
  { path: "author", select: "name handle avatarUrl verified nrpPro" },
  { path: "replyTo", select: "author content", populate: { path: "author", select: "name handle" } },
  { path: "quoteOf", populate: { path: "author", select: "name handle avatarUrl verified" } },
];

async function attachInteractions(posts, userId) {
  if (!userId || !posts.length) return posts;
  const ids = posts.map(p => p._id);
  const [likes, reposts, bookmarks] = await Promise.all([
    Like.find({ user: userId, post: { $in: ids } }).select("post"),
    Repost.find({ user: userId, post: { $in: ids } }).select("post"),
    Bookmark.find({ user: userId, post: { $in: ids } }).select("post"),
  ]);
  const likedSet     = new Set(likes.map(l => l.post.toString()));
  const repostedSet  = new Set(reposts.map(r => r.post.toString()));
  const bookmarkedSet= new Set(bookmarks.map(b => b.post.toString()));
  return posts.map(p => ({
    ...p.toObject(),
    liked:      likedSet.has(p._id.toString()),
    reposted:   repostedSet.has(p._id.toString()),
    bookmarked: bookmarkedSet.has(p._id.toString()),
  }));
}

async function updateHashtags(tags) {
  for (const tag of tags) {
    await Hashtag.findOneAndUpdate(
      { tag },
      { $inc: { postCount: 1, dailyCount: 1 }, updatedAt: new Date() },
      { upsert: true, new: true }
    );
  }
}

// GET /api/posts/feed?tab=foryou&cursor=...&limit=20
async function getFeed(req, res, next) {
  try {
    const { tab = "foryou", cursor, limit = 20 } = req.query;
    const lim = Math.min(parseInt(limit), 50);
    const query = { isDeleted: false, replyTo: null };

    if (cursor) query._id = { $lt: cursor };

    if (tab === "following" && req.user) {
      query.author = { $in: [...(req.user.following || []), req.user._id] };
    }

    const posts = await Post.find(query)
      .populate(POST_POPULATE)
      .sort({ createdAt: -1 })
      .limit(lim);

    const withInteractions = await attachInteractions(posts, req.user?._id);
    const nextCursor = posts.length === lim ? posts[posts.length - 1]._id : null;

    res.json({ posts: withInteractions, nextCursor });
  } catch (err) { next(err); }
}

// POST /api/posts
async function createPost(req, res, next) {
  try {
    const { content, replyTo, quoteOf, poll } = req.body;
    const media = req.files || [];

    const sanitized = xss(content || "");
    if (!sanitized.trim()) return res.status(400).json({ error: "Content required" });
    if (sanitized.length > 280) return res.status(400).json({ error: "Too long (max 280)" });

    const mediaUrls  = media.map(f => f.path || `/uploads/${f.filename}`);
    const mediaTypes = media.map(f => f.mimetype?.startsWith("video") ? "video" : "image");

    let pollData = null;
    if (poll && poll.options?.length >= 2) {
      pollData = {
        options: poll.options.slice(0, 4).map(o => ({ label: xss(o.label), votes: 0 })),
        endsAt:  poll.duration ? new Date(Date.now() + poll.duration * 86400000) : null,
        totalVotes: 0,
        voters: [],
      };
    }

    const post = await Post.create({
      author: req.user._id,
      content: sanitized,
      replyTo: replyTo || null,
      quoteOf: quoteOf || null,
      mediaUrls,
      mediaTypes,
      poll: pollData,
    });

    // Update counters
    await User.findByIdAndUpdate(req.user._id, { $inc: { postsCount: 1 } });

    if (replyTo) {
      await Post.findByIdAndUpdate(replyTo, { $inc: { replyCount: 1 } });
      const parent = await Post.findById(replyTo).select("author");
      if (parent && parent.author.toString() !== req.user._id.toString()) {
        const notif = await Notification.create({ recipient: parent.author, actor: req.user._id, type: "reply", post: post._id });
        emitToUser(parent.author.toString(), "notification", notif);
      }
    }

    if (quoteOf) {
      await Post.findByIdAndUpdate(quoteOf, { $inc: { quoteCount: 1 } });
      const quoted = await Post.findById(quoteOf).select("author");
      if (quoted && quoted.author.toString() !== req.user._id.toString()) {
        const notif = await Notification.create({ recipient: quoted.author, actor: req.user._id, type: "quote", post: post._id });
        emitToUser(quoted.author.toString(), "notification", notif);
      }
    }

    // Hashtags
    if (post.hashtags?.length) await updateHashtags(post.hashtags);

    // Mention notifications
    if (post.mentions?.length) {
      const mentioned = await User.find({ handle: { $in: post.mentions } }).select("_id");
      for (const m of mentioned) {
        if (m._id.toString() !== req.user._id.toString()) {
          const notif = await Notification.create({ recipient: m._id, actor: req.user._id, type: "mention", post: post._id });
          emitToUser(m._id.toString(), "notification", notif);
        }
      }
    }

    const populated = await post.populate(POST_POPULATE);
    const withMeta  = { ...populated.toObject(), liked: false, reposted: false, bookmarked: false };

    // Emit to feed subscribers
    emitToAll("post:new", withMeta);

    res.status(201).json(withMeta);
  } catch (err) { next(err); }
}

// GET /api/posts/:id
async function getPost(req, res, next) {
  try {
    const post = await Post.findOne({ _id: req.params.id, isDeleted: false }).populate(POST_POPULATE);
    if (!post) return res.status(404).json({ error: "Post not found" });

    const replies = await Post.find({ replyTo: post._id, isDeleted: false })
      .populate(POST_POPULATE)
      .sort({ createdAt: 1 });

    const [withInteractions, repliesWithInteractions] = await Promise.all([
      attachInteractions([post], req.user?._id),
      attachInteractions(replies, req.user?._id),
    ]);

    // Increment view
    Post.findByIdAndUpdate(post._id, { $inc: { viewCount: 1 } }).catch(() => {});

    res.json({ post: withInteractions[0], replies: repliesWithInteractions });
  } catch (err) { next(err); }
}

// DELETE /api/posts/:id
async function deletePost(req, res, next) {
  try {
    const post = await Post.findOne({ _id: req.params.id, author: req.user._id });
    if (!post) return res.status(404).json({ error: "Post not found" });
    post.isDeleted = true;
    post.content   = "[deleted]";
    post.mediaUrls = [];
    await post.save();
    await User.findByIdAndUpdate(req.user._id, { $inc: { postsCount: -1 } });
    emitToAll("post:delete", { id: req.params.id });
    res.json({ message: "Post deleted" });
  } catch (err) { next(err); }
}

// POST /api/posts/:id/like
async function toggleLike(req, res, next) {
  try {
    const postId = req.params.id;
    const userId = req.user._id;
    const existing = await Like.findOne({ user: userId, post: postId });

    if (existing) {
      await existing.deleteOne();
      await Post.findByIdAndUpdate(postId, { $inc: { likeCount: -1 } });
      return res.json({ liked: false });
    }

    await Like.create({ user: userId, post: postId });
    await Post.findByIdAndUpdate(postId, { $inc: { likeCount: 1 } });

    const post = await Post.findById(postId).select("author");
    if (post && post.author.toString() !== userId.toString()) {
      const notif = await Notification.create({ recipient: post.author, actor: userId, type: "like", post: postId });
      emitToUser(post.author.toString(), "notification", notif);
    }

    res.json({ liked: true });
  } catch (err) { next(err); }
}

// POST /api/posts/:id/repost
async function toggleRepost(req, res, next) {
  try {
    const postId = req.params.id;
    const userId = req.user._id;
    const existing = await Repost.findOne({ user: userId, post: postId });

    if (existing) {
      await existing.deleteOne();
      await Post.findByIdAndUpdate(postId, { $inc: { repostCount: -1 } });
      return res.json({ reposted: false });
    }

    await Repost.create({ user: userId, post: postId });
    await Post.findByIdAndUpdate(postId, { $inc: { repostCount: 1 } });

    const post = await Post.findById(postId).select("author");
    if (post && post.author.toString() !== userId.toString()) {
      const notif = await Notification.create({ recipient: post.author, actor: userId, type: "repost", post: postId });
      emitToUser(post.author.toString(), "notification", notif);
    }

    res.json({ reposted: true });
  } catch (err) { next(err); }
}

// POST /api/posts/:id/bookmark
async function toggleBookmark(req, res, next) {
  try {
    const postId = req.params.id;
    const userId = req.user._id;
    const existing = await Bookmark.findOne({ user: userId, post: postId });

    if (existing) {
      await existing.deleteOne();
      await Post.findByIdAndUpdate(postId, { $inc: { bookmarkCount: -1 } });
      return res.json({ bookmarked: false });
    }

    await Bookmark.create({ user: userId, post: postId });
    await Post.findByIdAndUpdate(postId, { $inc: { bookmarkCount: 1 } });
    res.json({ bookmarked: true });
  } catch (err) { next(err); }
}

// GET /api/posts/bookmarks
async function getBookmarks(req, res, next) {
  try {
    const { cursor, limit = 20 } = req.query;
    const q = { user: req.user._id };
    if (cursor) q._id = { $lt: cursor };

    const bookmarks = await Bookmark.find(q)
      .populate({ path: "post", populate: POST_POPULATE })
      .sort({ createdAt: -1 })
      .limit(parseInt(limit));

    const posts = bookmarks.map(b => b.post).filter(Boolean);
    const withI = await attachInteractions(posts, req.user._id);
    res.json({ posts: withI, nextCursor: bookmarks.length === parseInt(limit) ? bookmarks[bookmarks.length-1]._id : null });
  } catch (err) { next(err); }
}

// POST /api/posts/:id/poll-vote
async function votePoll(req, res, next) {
  try {
    const { optionIndex } = req.body;
    const post = await Post.findById(req.params.id);
    if (!post?.poll) return res.status(400).json({ error: "No poll on this post" });
    if (post.poll.voters.includes(req.user._id)) return res.status(400).json({ error: "Already voted" });
    if (new Date(post.poll.endsAt) < new Date()) return res.status(400).json({ error: "Poll ended" });

    post.poll.options[optionIndex].votes++;
    post.poll.totalVotes++;
    post.poll.voters.push(req.user._id);
    await post.save();
    res.json({ poll: post.poll });
  } catch (err) { next(err); }
}

module.exports = { getFeed, createPost, getPost, deletePost, toggleLike, toggleRepost, toggleBookmark, getBookmarks, votePoll };
