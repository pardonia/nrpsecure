const { Conversation, Message } = require("../models/index");
const User = require("../models/User");
const { emitToConversation, emitToUser } = require("../config/socket");

// GET /api/messages — list conversations
async function getConversations(req, res, next) {
  try {
    const convos = await Conversation.find({ participants: req.user._id })
      .populate("participants", "name handle avatarUrl verified lastSeen")
      .populate({ path: "lastMessage", select: "content createdAt sender" })
      .sort({ lastMsgAt: -1 })
      .limit(50);

    const result = convos.map(c => {
      const other = c.participants.find(p => p._id.toString() !== req.user._id.toString());
      const unread = c.unreadCounts?.get?.(req.user._id.toString()) || 0;
      return { ...c.toObject(), other, unread };
    });

    res.json({ conversations: result });
  } catch (err) { next(err); }
}

// POST /api/messages/conversation — get or create DM with a user
async function getOrCreateConversation(req, res, next) {
  try {
    const { targetId } = req.body;
    if (targetId === req.user._id.toString()) return res.status(400).json({ error: "Can't DM yourself" });

    const target = await User.findById(targetId);
    if (!target) return res.status(404).json({ error: "User not found" });

    let convo = await Conversation.findOne({ participants: { $all: [req.user._id, targetId] } })
      .populate("participants", "name handle avatarUrl verified lastSeen");

    if (!convo) {
      convo = await Conversation.create({ participants: [req.user._id, targetId] });
      await convo.populate("participants", "name handle avatarUrl verified lastSeen");
    }

    const other = convo.participants.find(p => p._id.toString() !== req.user._id.toString());
    res.json({ conversation: { ...convo.toObject(), other } });
  } catch (err) { next(err); }
}

// GET /api/messages/:conversationId — load messages
async function getMessages(req, res, next) {
  try {
    const { conversationId } = req.params;
    const { cursor, limit = 50 } = req.query;

    const convo = await Conversation.findOne({ _id: conversationId, participants: req.user._id });
    if (!convo) return res.status(403).json({ error: "Access denied" });

    const q = { conversation: conversationId, deletedAt: null };
    if (cursor) q._id = { $lt: cursor };

    const messages = await Message.find(q)
      .populate("sender", "name handle avatarUrl")
      .sort({ createdAt: -1 })
      .limit(parseInt(limit));

    // Mark as read
    await Message.updateMany(
      { conversation: conversationId, sender: { $ne: req.user._id }, readBy: { $ne: req.user._id } },
      { $addToSet: { readBy: req.user._id } }
    );
    // Reset unread count
    convo.unreadCounts?.set(req.user._id.toString(), 0);
    await convo.save();

    res.json({ messages: messages.reverse(), nextCursor: messages.length === parseInt(limit) ? messages[0]?._id : null });
  } catch (err) { next(err); }
}

// POST /api/messages/:conversationId — send message
async function sendMessage(req, res, next) {
  try {
    const { conversationId } = req.params;
    const { content, contentIv } = req.body; // contentIv = AES-GCM IV for E2EE

    if (!content?.trim()) return res.status(400).json({ error: "Message required" });

    const convo = await Conversation.findOne({ _id: conversationId, participants: req.user._id });
    if (!convo) return res.status(403).json({ error: "Access denied" });

    const mediaUrl  = req.file ? (req.file.path || `/uploads/${req.file.filename}`) : null;
    const mediaType = req.file?.mimetype?.startsWith("video") ? "video" : req.file ? "image" : null;

    const msg = await Message.create({
      conversation: conversationId,
      sender:       req.user._id,
      content:      content.trim(),
      contentIv:    contentIv || null,
      mediaUrl,
      mediaType,
      readBy:       [req.user._id],
    });

    await msg.populate("sender", "name handle avatarUrl");

    // Update conversation metadata
    const otherIds = convo.participants.filter(p => p.toString() !== req.user._id.toString());
    convo.lastMessage = msg._id;
    convo.lastMsgAt   = new Date();
    for (const otherId of otherIds) {
      const key = otherId.toString();
      convo.unreadCounts?.set(key, (convo.unreadCounts?.get(key) || 0) + 1);
    }
    await convo.save();

    // Real-time delivery
    emitToConversation(conversationId, "message:new", msg);
    for (const otherId of otherIds) {
      emitToUser(otherId.toString(), "dm:notification", { conversationId, sender: { name: req.user.name, handle: req.user.handle } });
    }

    res.status(201).json({ message: msg });
  } catch (err) { next(err); }
}

// DELETE /api/messages/:conversationId/:messageId
async function deleteMessage(req, res, next) {
  try {
    const msg = await Message.findOne({ _id: req.params.messageId, sender: req.user._id });
    if (!msg) return res.status(404).json({ error: "Message not found" });
    msg.deletedAt = new Date();
    msg.content   = "[deleted]";
    await msg.save();
    emitToConversation(req.params.conversationId, "message:delete", { id: msg._id });
    res.json({ message: "Deleted" });
  } catch (err) { next(err); }
}

module.exports = { getConversations, getOrCreateConversation, getMessages, sendMessage, deleteMessage };
