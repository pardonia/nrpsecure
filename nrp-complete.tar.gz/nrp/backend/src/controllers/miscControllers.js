const { Notification, Hashtag, LiveRoom } = require("../models/index");
const User = require("../models/User");
const Post = require("../models/Post");

// ── NOTIFICATIONS ─────────────────────────────────────────────

async function getNotifications(req, res, next) {
  try {
    const { cursor, filter = "all", limit = 30 } = req.query;
    const q = { recipient: req.user._id };
    if (cursor) q._id = { $lt: cursor };
    if (filter === "mentions") q.type = "mention";
    if (filter === "verified") {
      const verified = await User.find({ verified: true }).select("_id");
      q.actor = { $in: verified.map(u => u._id) };
    }

    const notifs = await Notification.find(q)
      .populate("actor", "name handle avatarUrl verified")
      .populate("post", "content")
      .sort({ createdAt: -1 })
      .limit(parseInt(limit));

    res.json({ notifications: notifs, nextCursor: notifs.length === parseInt(limit) ? notifs[notifs.length-1]._id : null });
  } catch (err) { next(err); }
}

async function markRead(req, res, next) {
  try {
    await Notification.updateMany({ recipient: req.user._id, read: false }, { read: true });
    res.json({ message: "Marked all read" });
  } catch (err) { next(err); }
}

async function getUnreadCount(req, res, next) {
  try {
    const count = await Notification.countDocuments({ recipient: req.user._id, read: false });
    res.json({ count });
  } catch (err) { next(err); }
}

// ── SEARCH ────────────────────────────────────────────────────

async function search(req, res, next) {
  try {
    const { q, type = "posts", cursor, limit = 20 } = req.query;
    if (!q?.trim()) return res.json({ results: [] });

    const lim = Math.min(parseInt(limit), 50);

    if (type === "users") {
      const users = await User.find({ $text: { $search: q } })
        .select("name handle avatarUrl verified nrpPro bio followersCount")
        .limit(lim);
      return res.json({ results: users });
    }

    if (type === "hashtags") {
      const tags = await Hashtag.find({ tag: { $regex: q.replace(/^#/, ""), $options: "i" } })
        .sort({ postCount: -1 }).limit(lim);
      return res.json({ results: tags });
    }

    // Default: posts
    const query = { $text: { $search: q }, isDeleted: false };
    if (cursor) query._id = { $lt: cursor };
    const posts = await Post.find(query)
      .populate([
        { path: "author", select: "name handle avatarUrl verified nrpPro" },
        { path: "quoteOf", populate: { path: "author", select: "name handle avatarUrl" } },
      ])
      .sort({ createdAt: -1 })
      .limit(lim);

    res.json({ results: posts, nextCursor: posts.length === lim ? posts[posts.length-1]._id : null });
  } catch (err) { next(err); }
}

// ── TRENDS ────────────────────────────────────────────────────

async function getTrends(req, res, next) {
  try {
    const trends = await Hashtag.find({ postCount: { $gt: 0 } })
      .sort({ dailyCount: -1, postCount: -1 })
      .limit(20)
      .select("tag postCount dailyCount");
    res.json({ trends });
  } catch (err) { next(err); }
}

async function getTagPosts(req, res, next) {
  try {
    const { tag } = req.params;
    const { cursor, limit = 20 } = req.query;
    const q = { hashtags: tag.toLowerCase(), isDeleted: false };
    if (cursor) q._id = { $lt: cursor };
    const posts = await Post.find(q)
      .populate([
        { path: "author", select: "name handle avatarUrl verified nrpPro" },
        { path: "quoteOf", populate: { path: "author", select: "name handle avatarUrl" } },
      ])
      .sort({ createdAt: -1 })
      .limit(parseInt(limit));
    res.json({ posts, tag, nextCursor: posts.length === parseInt(limit) ? posts[posts.length-1]._id : null });
  } catch (err) { next(err); }
}

// ── LIVE ──────────────────────────────────────────────────────

async function createLiveRoom(req, res, next) {
  try {
    const { title } = req.body;
    if (!title?.trim()) return res.status(400).json({ error: "Title required" });

    const roomName = `nrp-${req.user.handle}-${Date.now()}`;
    let token = null;

    // Generate LiveKit token if configured
    if (process.env.LIVEKIT_API_KEY && process.env.LIVEKIT_API_SECRET) {
      try {
        const { AccessToken } = require("livekit-server-sdk");
        const at = new AccessToken(process.env.LIVEKIT_API_KEY, process.env.LIVEKIT_API_SECRET, {
          identity: req.user._id.toString(), ttl: "4h",
        });
        at.addGrant({ roomJoin: true, room: roomName, canPublish: true, canSubscribe: true });
        token = await at.toJwt();
      } catch (e) { console.warn("LiveKit token failed:", e.message); }
    }

    const room = await LiveRoom.create({
      host: req.user._id, title: title.trim(), roomName,
      status: "live", startedAt: new Date(),
    });

    await room.populate("host", "name handle avatarUrl");
    res.status(201).json({ room, token, livekitUrl: process.env.LIVEKIT_URL || null });
  } catch (err) { next(err); }
}

async function getLiveRooms(req, res, next) {
  try {
    const rooms = await LiveRoom.find({ status: "live" })
      .populate("host", "name handle avatarUrl verified")
      .sort({ startedAt: -1 });
    res.json({ rooms });
  } catch (err) { next(err); }
}

async function joinLiveRoom(req, res, next) {
  try {
    const room = await LiveRoom.findById(req.params.id);
    if (!room || room.status !== "live") return res.status(404).json({ error: "Room not live" });

    let token = null;
    if (process.env.LIVEKIT_API_KEY && process.env.LIVEKIT_API_SECRET) {
      try {
        const { AccessToken } = require("livekit-server-sdk");
        const at = new AccessToken(process.env.LIVEKIT_API_KEY, process.env.LIVEKIT_API_SECRET, {
          identity: req.user._id.toString(), ttl: "4h",
        });
        at.addGrant({ roomJoin: true, room: room.roomName, canPublish: false, canSubscribe: true });
        token = await at.toJwt();
      } catch (e) { console.warn("LiveKit token failed:", e.message); }
    }

    res.json({ room, token, livekitUrl: process.env.LIVEKIT_URL || null });
  } catch (err) { next(err); }
}

async function endLiveRoom(req, res, next) {
  try {
    const room = await LiveRoom.findOne({ _id: req.params.id, host: req.user._id });
    if (!room) return res.status(404).json({ error: "Room not found" });
    room.status  = "ended";
    room.endedAt = new Date();
    await room.save();
    res.json({ message: "Stream ended" });
  } catch (err) { next(err); }
}

module.exports = {
  getNotifications, markRead, getUnreadCount,
  search,
  getTrends, getTagPosts,
  createLiveRoom, getLiveRooms, joinLiveRoom, endLiveRoom,
};
