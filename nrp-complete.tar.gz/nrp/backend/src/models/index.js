const mongoose = require("mongoose");

// ── Like ──────────────────────────────────────────────────────
const likeSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  post: { type: mongoose.Schema.Types.ObjectId, ref: "Post", required: true },
}, { timestamps: true });
likeSchema.index({ user: 1, post: 1 }, { unique: true });
likeSchema.index({ post: 1 });
const Like = mongoose.model("Like", likeSchema);

// ── Repost ────────────────────────────────────────────────────
const repostSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  post: { type: mongoose.Schema.Types.ObjectId, ref: "Post", required: true },
}, { timestamps: true });
repostSchema.index({ user: 1, post: 1 }, { unique: true });
const Repost = mongoose.model("Repost", repostSchema);

// ── Bookmark ──────────────────────────────────────────────────
const bookmarkSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  post: { type: mongoose.Schema.Types.ObjectId, ref: "Post", required: true },
}, { timestamps: true });
bookmarkSchema.index({ user: 1, post: 1 }, { unique: true });
bookmarkSchema.index({ user: 1, createdAt: -1 });
const Bookmark = mongoose.model("Bookmark", bookmarkSchema);

// ── Notification ──────────────────────────────────────────────
const notificationSchema = new mongoose.Schema({
  recipient: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  actor:     { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  type:      { type: String, required: true, enum: ["like","repost","follow","mention","reply","quote","poll_end"] },
  post:      { type: mongoose.Schema.Types.ObjectId, ref: "Post" },
  read:      { type: Boolean, default: false },
}, { timestamps: true });
notificationSchema.index({ recipient: 1, read: 1, createdAt: -1 });
const Notification = mongoose.model("Notification", notificationSchema);

// ── Conversation ──────────────────────────────────────────────
const conversationSchema = new mongoose.Schema({
  participants: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  lastMessage:  { type: mongoose.Schema.Types.ObjectId, ref: "Message" },
  lastMsgAt:    { type: Date, default: Date.now },
  unreadCounts: { type: Map, of: Number, default: {} }, // userId -> count
}, { timestamps: true });
conversationSchema.index({ participants: 1 });
conversationSchema.index({ lastMsgAt: -1 });
const Conversation = mongoose.model("Conversation", conversationSchema);

// ── Message ───────────────────────────────────────────────────
const messageSchema = new mongoose.Schema({
  conversation: { type: mongoose.Schema.Types.ObjectId, ref: "Conversation", required: true },
  sender:       { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  content:      { type: String, required: true, maxlength: 4000 },
  contentIv:    { type: String }, // E2EE IV (base64)
  mediaUrl:     { type: String },
  mediaType:    { type: String },
  readBy:       [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  deletedAt:    { type: Date },
}, { timestamps: true });
messageSchema.index({ conversation: 1, createdAt: 1 });
const Message = mongoose.model("Message", messageSchema);

// ── Hashtag ───────────────────────────────────────────────────
const hashtagSchema = new mongoose.Schema({
  tag:       { type: String, required: true, unique: true, lowercase: true },
  postCount: { type: Number, default: 0 },
  dailyCount:{ type: Number, default: 0 }, // reset daily by cron
  updatedAt: { type: Date, default: Date.now },
}, { timestamps: false });
hashtagSchema.index({ postCount: -1 });
hashtagSchema.index({ dailyCount: -1 });
const Hashtag = mongoose.model("Hashtag", hashtagSchema);

// ── LiveRoom ──────────────────────────────────────────────────
const liveRoomSchema = new mongoose.Schema({
  host:        { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  title:       { type: String, required: true, maxlength: 100 },
  roomName:    { type: String, required: true, unique: true },
  status:      { type: String, enum: ["waiting","live","ended"], default: "waiting" },
  viewerCount: { type: Number, default: 0 },
  startedAt:   { type: Date },
  endedAt:     { type: Date },
}, { timestamps: true });
liveRoomSchema.index({ status: 1, startedAt: -1 });
const LiveRoom = mongoose.model("LiveRoom", liveRoomSchema);

module.exports = { Like, Repost, Bookmark, Notification, Conversation, Message, Hashtag, LiveRoom };
