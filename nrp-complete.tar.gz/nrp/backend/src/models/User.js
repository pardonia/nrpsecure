const mongoose = require("mongoose");
const bcrypt   = require("bcryptjs");

const userSchema = new mongoose.Schema({
  name:          { type: String, required: true, trim: true, maxlength: 50 },
  handle:        { type: String, required: true, unique: true, trim: true, lowercase: true, maxlength: 20, match: /^[a-z0-9_]+$/ },
  email:         { type: String, required: true, unique: true, trim: true, lowercase: true },
  password:      { type: String, select: false, minlength: 8 },
  bio:           { type: String, default: "", maxlength: 160 },
  location:      { type: String, default: "", maxlength: 60 },
  website:       { type: String, default: "", maxlength: 100 },
  avatarUrl:     { type: String, default: "" },
  coverUrl:      { type: String, default: "" },
  verified:      { type: Boolean, default: false },
  nrpPro:        { type: Boolean, default: false },
  isPrivate:     { type: Boolean, default: false },

  following:     [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  followers:     [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  blockedUsers:  [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],

  followingCount: { type: Number, default: 0 },
  followersCount: { type: Number, default: 0 },
  postsCount:     { type: Number, default: 0 },

  // Auth
  emailVerified:        { type: Boolean, default: false },
  emailVerifyToken:     { type: String, select: false },
  passwordResetToken:   { type: String, select: false },
  passwordResetExpires: { type: Date,   select: false },
  refreshTokens:        [{ type: String, select: false }],

  // OAuth
  googleId:  { type: String },
  githubId:  { type: String },

  lastSeen:  { type: Date, default: Date.now },
  joinedAt:  { type: Date, default: Date.now },
}, { timestamps: true });

// Index
userSchema.index({ handle: 1 });
userSchema.index({ email: 1 });
userSchema.index({ name: "text", handle: "text", bio: "text" });

// Hash password before save
userSchema.pre("save", async function (next) {
  if (!this.isModified("password") || !this.password) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

userSchema.methods.comparePassword = async function (candidate) {
  return bcrypt.compare(candidate, this.password);
};

userSchema.methods.toPublicJSON = function () {
  const obj = this.toObject();
  delete obj.password;
  delete obj.refreshTokens;
  delete obj.emailVerifyToken;
  delete obj.passwordResetToken;
  delete obj.passwordResetExpires;
  return obj;
};

module.exports = mongoose.model("User", userSchema);
