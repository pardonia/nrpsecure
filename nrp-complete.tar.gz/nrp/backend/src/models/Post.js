const mongoose = require("mongoose");

const pollOptionSchema = new mongoose.Schema({
  label: { type: String, required: true, maxlength: 60 },
  votes: { type: Number, default: 0 },
}, { _id: false });

const postSchema = new mongoose.Schema({
  author:    { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  content:   { type: String, required: true, maxlength: 280 },

  // Threading
  replyTo:   { type: mongoose.Schema.Types.ObjectId, ref: "Post", default: null },
  quoteOf:   { type: mongoose.Schema.Types.ObjectId, ref: "Post", default: null },
  thread:    [{ type: mongoose.Schema.Types.ObjectId, ref: "Post" }], // ancestor chain

  // Media
  mediaUrls:  [{ type: String }],
  mediaTypes: [{ type: String }], // "image" | "video" | "gif"

  // Poll
  poll: {
    options:    [pollOptionSchema],
    endsAt:     { type: Date },
    totalVotes: { type: Number, default: 0 },
    voters:     [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  },

  // Interaction counters (denormalised for speed)
  likeCount:     { type: Number, default: 0 },
  repostCount:   { type: Number, default: 0 },
  replyCount:    { type: Number, default: 0 },
  bookmarkCount: { type: Number, default: 0 },
  viewCount:     { type: Number, default: 0 },
  quoteCount:    { type: Number, default: 0 },

  // Extracted metadata (populated by post-save hook)
  hashtags:  [{ type: String }],
  mentions:  [{ type: String }], // handles without @

  isPinned:  { type: Boolean, default: false },
  isDeleted: { type: Boolean, default: false },
}, { timestamps: true });

// Indexes
postSchema.index({ author: 1, createdAt: -1 });
postSchema.index({ replyTo: 1 });
postSchema.index({ hashtags: 1, createdAt: -1 });
postSchema.index({ createdAt: -1 });
postSchema.index({ content: "text" });

// Extract hashtags + mentions before save
postSchema.pre("save", function (next) {
  if (this.isModified("content")) {
    this.hashtags = (this.content.match(/#(\w+)/g) || []).map(t => t.slice(1).toLowerCase());
    this.mentions = (this.content.match(/@(\w+)/g) || []).map(m => m.slice(1).toLowerCase());
  }
  next();
});

module.exports = mongoose.model("Post", postSchema);
