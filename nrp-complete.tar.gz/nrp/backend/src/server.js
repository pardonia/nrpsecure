require("dotenv").config();
const express    = require("express");
const http       = require("http");
const cors       = require("cors");
const helmet     = require("helmet");
const compression= require("compression");
const morgan     = require("morgan");
const mongoSanitize = require("express-mongo-sanitize");
const path       = require("path");

const connectDB  = require("./config/db");
const { initSocket } = require("./config/socket");
const { apiLimiter } = require("./middleware/rateLimit");
const errorHandler   = require("./middleware/errorHandler");

// Routes
const authRoutes    = require("./routes/auth");
const userRoutes    = require("./routes/users");
const postRoutes    = require("./routes/posts");
const messageRoutes = require("./routes/messages");
const notifRoutes   = require("./routes/notifications");
const searchRoutes  = require("./routes/search");
const trendRoutes   = require("./routes/trends");
const liveRoutes    = require("./routes/live");
const uploadRoutes  = require("./routes/upload");

const app    = express();
const server = http.createServer(app);

// ── Connect DB ────────────────────────────────────────────────
connectDB();

// ── Socket.io ─────────────────────────────────────────────────
const io = initSocket(server);
app.set("io", io);

// ── Core middleware ────────────────────────────────────────────
app.use(helmet({ crossOriginResourcePolicy: { policy: "cross-origin" } }));
app.use(compression());
app.use(cors({
  origin: process.env.FRONTEND_URL || "http://localhost:3000",
  credentials: true,
}));
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));
app.use(mongoSanitize());
app.use(morgan(process.env.NODE_ENV === "production" ? "combined" : "dev"));

// ── Static uploads ────────────────────────────────────────────
app.use("/uploads", express.static(path.join(__dirname, "../uploads")));

// ── Health check ──────────────────────────────────────────────
app.get("/health", (_req, res) => res.json({ status: "ok", ts: Date.now() }));

// ── API Routes ────────────────────────────────────────────────
app.use("/api", apiLimiter);
app.use("/api/auth",          authRoutes);
app.use("/api/users",         userRoutes);
app.use("/api/posts",         postRoutes);
app.use("/api/messages",      messageRoutes);
app.use("/api/notifications", notifRoutes);
app.use("/api/search",        searchRoutes);
app.use("/api/trends",        trendRoutes);
app.use("/api/live",          liveRoutes);
app.use("/api/upload",        uploadRoutes);

// ── 404 ───────────────────────────────────────────────────────
app.use((_req, res) => res.status(404).json({ error: "Route not found" }));

// ── Global error handler ──────────────────────────────────────
app.use(errorHandler);

// ── Start ─────────────────────────────────────────────────────
const PORT = process.env.PORT || 4000;
server.listen(PORT, () => {
  console.log(`\n🚀 NRP Backend running on port ${PORT}`);
  console.log(`   ENV: ${process.env.NODE_ENV}`);
  console.log(`   DB:  ${process.env.MONGODB_URI?.slice(0, 40)}…\n`);
});

module.exports = { app, server };
