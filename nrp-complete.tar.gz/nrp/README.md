# NRP — Network Relay Platform

> A market-ready, full-stack social media platform. Black & white aesthetic. Real-time everything. Privacy-first.

![NRP](https://img.shields.io/badge/NRP-Network%20Relay%20Platform-black?style=for-the-badge)
![License](https://img.shields.io/badge/license-MIT-white?style=for-the-badge)
![Node](https://img.shields.io/badge/Node-20+-black?style=for-the-badge)
![Next.js](https://img.shields.io/badge/Next.js-15-white?style=for-the-badge)

---

## Stack

| Layer       | Technology                                      |
|-------------|--------------------------------------------------|
| Frontend    | Next.js 15, React 18, TanStack Query, Zustand    |
| Backend     | Node.js 20, Express 5, MongoDB + Mongoose        |
| Auth        | JWT (access + refresh tokens), bcrypt, nodemailer|
| Realtime    | Socket.io (DMs, notifications, feed updates)     |
| Media       | Cloudinary (images/video) or local disk fallback |
| Live        | LiveKit (WebRTC broadcasting + 1:1 calls)        |
| Deployment  | Docker + docker-compose (Mongo, API, Web)        |

---

## Features

- ✅ JWT auth — register, login, refresh, password reset via email
- ✅ Posts — create, delete, reply, quote-repost, with images/video
- ✅ Rich text — clickable #hashtags and @mentions
- ✅ Feed — "For You" (algorithmic) + "Following" tabs
- ✅ Likes, reposts, bookmarks with optimistic UI
- ✅ Polls with live vote counts
- ✅ Follows / followers with suggestions
- ✅ Profile editing — avatar, cover, bio, location, website
- ✅ Direct Messages — real-time via Socket.io + E2EE placeholder
- ✅ 1:1 Video/Audio calls via LiveKit WebRTC
- ✅ NRP Live — broadcast streaming via LiveKit
- ✅ Notifications — real-time push via Socket.io
- ✅ Search — full-text posts, users, hashtags
- ✅ Trending hashtags
- ✅ Light / Dark (true black) mode toggle
- ✅ Rate limiting, input validation, helmet security headers
- ✅ Docker + docker-compose for one-command deploy
- ✅ Proper 404, error boundary, loading skeletons

---

## Quick Start

### 1. Clone & install

```bash
git clone https://github.com/yourname/nrp.git
cd nrp
cp .env.example .env        # fill in values
```

### 2. Docker (recommended — starts everything)

```bash
docker-compose up --build
# Open http://localhost:3000
```

### 3. Local dev (without Docker)

```bash
# Backend
cd backend && npm install && npm run dev   # :4000

# Frontend (new terminal)
cd frontend && npm install && npm run dev  # :3000
```

---

## Environment Variables

See `.env.example` for the full list. Required to get started:

| Variable | Description |
|---|---|
| `MONGODB_URI` | MongoDB connection string |
| `JWT_SECRET` | Long random secret for access tokens |
| `JWT_REFRESH_SECRET` | Separate secret for refresh tokens |
| `CLOUDINARY_CLOUD_NAME` | Cloudinary account (optional, falls back to local) |
| `CLOUDINARY_API_KEY` | Cloudinary key |
| `CLOUDINARY_API_SECRET` | Cloudinary secret |
| `SMTP_HOST` / `SMTP_USER` / `SMTP_PASS` | Email for password reset |
| `LIVEKIT_API_KEY` / `LIVEKIT_API_SECRET` | LiveKit for video (optional) |
| `NEXT_PUBLIC_API_URL` | Backend URL (default: http://localhost:4000) |

---

## Project Structure

```
nrp/
├── backend/
│   ├── src/
│   │   ├── models/          # Mongoose schemas
│   │   ├── routes/          # Express routers
│   │   ├── controllers/     # Business logic
│   │   ├── middleware/       # Auth, rate-limit, upload, validation
│   │   ├── utils/           # Email, JWT helpers
│   │   └── config/          # DB, Cloudinary, Socket.io
│   ├── Dockerfile
│   └── package.json
├── frontend/
│   ├── src/
│   │   ├── app/             # Next.js App Router pages
│   │   ├── components/      # UI components
│   │   ├── hooks/           # React Query hooks
│   │   ├── store/           # Zustand stores
│   │   └── lib/             # API client, utils
│   ├── Dockerfile
│   └── package.json
├── docker-compose.yml
├── .env.example
└── README.md
```

---

## Deployment

### Vercel + Railway (free tier)

1. Push to GitHub
2. Deploy `frontend/` on Vercel — set `NEXT_PUBLIC_API_URL` to your Railway URL
3. Deploy `backend/` on Railway — add all backend env vars + MongoDB Atlas URI

### VPS / Docker

```bash
docker-compose -f docker-compose.yml up -d
```

Nginx reverse-proxy config included in `docker-compose.yml`.

---

## License

MIT © 2025 Network Relay Platform
